function pvcPET = SFS_corr_model(PtImage,AImage,SAImage,mask,shift,flag)
% The function that correct the PET image using the information of the
% Anatomical associated image.
% INPUT
% PtIMage = PET
% AImage = Anatomical Image == MRI
% SAImage = Smoothed Anatomical Image to match with PET resolution
% mask = mask for all the images
% shift = number of voxels use for the shift
% flag = direction of shift: 1=x, 2=y, 3=z
% NOTES: all the images need to be in the space, defined by a 3D matrix
% with the same number of elements. For all the directions, the number of
% voxels needs to be EVEN!
% OUTPUT
% pvcPET = SuperPET

%% ********** Data Preparation **********
hdr=spm_read_hdr(AImage);                   % read MRI header
X = hdr.dime.dim(2);
Y = hdr.dime.dim(3);
Z = hdr.dime.dim(4);
MRI= spm_vol(AImage);

% zero padding for wavelet transfprm
for xpow = 6:9                              %xpow (64,128,256)
    if((X-2^xpow)<=0) Xpow = 2^xpow; Ypow = Xpow;break; end;
end
for zpow = 6:9                              %zpow (64,128,256)
    if((Z-2^zpow)<=0) Zpow = 2^zpow; break; end;
end

offset1 = floor((Zpow-Z)/2); offset2 = floor((Ypow-Y)/2); offset3 = floor((Xpow-X)/2);

hdr=spm_read_hdr(SAImage);                  % read smooth MRI header
MRIs= spm_vol(SAImage); 

hdr=spm_read_hdr(PtImage);                  % read PET 
PET= spm_vol(PtImage);                                   

MASK= spm_vol(mask);                        % read MASK header

a  = zeros(Xpow,Ypow,Zpow);                 % allocate space                            
b  = zeros(Xpow,Ypow,Zpow);                             
x  = zeros(Xpow,Ypow,Zpow);
m  = zeros(Xpow,Ypow,Zpow);

J = 2;       % wavelet filter parameters - level of wavelet resolution                               % 
[Faf,Fsf]   = FSfarras; % wavelet filter parameters - first stage filter: a= direct, s= inverse
[af,sf]     = dualfilt1; % wavelet filter parameters - second stage filter: a= direct, s= inverse


[xx,~]=spm_read_vols(PET(1));               % read PET image
[aa,~]=spm_read_vols(MRI(1));               % read MRI image
[bb,~]=spm_read_vols(MRIs(1));              % read smooth MRI image
[mm,~]=spm_read_vols(MASK(1));              % read MASK image

%% ********** IMAGE SHIFTING to CORRECT SPACE VARIANCE *********
switch flag
% x
    case 1
aa(shift+1:end,:,:) = aa(1:end-shift,:,:);
bb(shift+1:end,:,:) = bb(1:end-shift,:,:);
xx(shift+1:end,:,:) = xx(1:end-shift,:,:);
mm(shift+1:end,:,:) = mm(1:end-shift,:,:);

% y
    case 2
aa(:,shift+1:end,:) = aa(:,1:end-shift,:);
bb(:,shift+1:end,:) = bb(:,1:end-shift,:);
xx(:,shift+1:end,:) = xx(:,1:end-shift,:);
mm(:,shift+1:end,:) = mm(:,1:end-shift,:);

% z
    case 3
aa(:,:,shift+1:end) = aa(:,:,1:end-shift);
bb(:,:,shift+1:end) = bb(:,:,1:end-shift);
xx(:,:,shift+1:end) = xx(:,:,1:end-shift);
mm(:,:,shift+1:end) = mm(:,:,1:end-shift);
end

%% ********** WAVELET TRANSFORM **********

% zero PAD images in power of 2 matrices with data already shifted
for s3 = 1:Z
    ss3 = double(s3 + offset1);
    for s2 = 1:Y
        ss2 = double(s2+offset2);
        for s1 = 1:X
            ss1 = double(s1+offset3);
            a(ss1,ss2,ss3)=aa(s1,s2,s3);
            b(ss1,ss2,ss3)=bb(s1,s2,s3);
            x(ss1,ss2,ss3)=xx(s1,s2,s3);
            m(ss1,ss2,ss3)=mm(s1,s2,s3);
        end
    end
end

fprintf('%% ********** start wavelet transform ********** %%\n');
fprintf('processing PET images\n');
WPET =cplxdual3D(x,J,Faf,af);                          
fprintf('processing MRI images\n');
WMRI =cplxdual3D(a,J,Faf,af);                          
fprintf('processing smoothed MRI images\n');
WMRIs=cplxdual3D(b,J,Faf,af);  
fprintf('processing mask images \n');
Faf{1}(:) = 1;  Faf{2}(:) = 1;          % wavaler filter parameter for binary mask (in immagine binaria i parametri dei filtri vanno messi a 1)
af{1}(:) = 1;   af{2}(:) = 1;
Wmask=cplxdual3D(m,J,Faf,af); 
WPETcorr=WPET;
clear xx; clear mm;                                              
clear aa; clear bb;clear d;
fprintf('%% ********** end wavelet transform ********** %%\n');

%% Create regression line model from low resolution coefficients
j = J+1;                                  % resolution level 

% Create coefficients matrixes
[wX,wY,wZ]  = size(WPET{j}{1}{1}{1});
wQ          = 2*2*2;
WWPET       = zeros(wQ,wX*wY*wZ);
WWMRI       = zeros(wQ,wX*wY*wZ);
WWMRIs      = zeros(wQ,wX*wY*wZ);
WWmask      = zeros(wQ,wX*wY*wZ);
for s1 = 1:2
    for s2 = 1:2
        for s3 = 1:2
            offset1             = s1+(s2-1)*2+(s3-1)*4;
            wpet                = WPET{j}{s1}{s2}{s3};
            wmri                = WMRI{j}{s1}{s2}{s3};
            wmris               = WMRIs{j}{s1}{s2}{s3};
            wmask               = Wmask{j}{s1}{s2}{s3};
            
            WWPET(offset1,:)    = (wpet(:));
            WWMRI(offset1,:)    = (wmri(:));
            WWMRIs(offset1,:)   = (wmris(:));
            WWmask(offset1,:)   = (wmask(:));
        end
    end
end

WWnew_pet           = WWPET; 

% Scaling factor  (G* = global)
Gmri    = sum(abs(WWMRI(:)));       
Gmris   = sum(abs(WWMRIs(:)));
Rscale  = Gmri/Gmris;                   % Resolution scale factor
Gpet    = sum(abs(WWPET(:)).*Rscale);
Gscale  = Gpet/Gmri;                    % Global scale factor

% Multiply coefficients for scaling factors
idx                 = find(WWmask);
not_idx             = find(WWmask==0);
tmp_pet             = WWPET(idx).*Rscale;
tmp_mri             = WWMRI(idx).*Gscale;

% Regression Model from low res coeff
p_model         = polyfit(tmp_mri,tmp_pet,1);
line            = p_model(1)*tmp_mri + p_model(2); %global model - red line
RESres          = (tmp_pet - line);
SIGMAres        = mad(RESres)/0.6745;           % noice variance measure == is what remains constant across different resolution images
                                                % for inter resolution weight factor    

                                                % Regression model and correction coefficients
for s1 = 1:2
    for s2 = 1:2
        for s3 = 1:2
            k            = s1+(s2-1)*2+(s3-1)*4;
            idx         = find(WWmask(k,:));
            tmp_pet     = WWPET(k,idx).*Rscale;
            tmp_mri     = WWMRI(k,idx).*Gscale;            
            p           = polyfit(tmp_mri,tmp_pet,1);   % regression model
            line        = p(1).*tmp_mri + p(2);
            RESquad     = (tmp_pet - line);             % residual

            WWnew_pet(k,idx)= (p(1).*tmp_mri + p(2))+RESquad; % Corrected coeff
            
            wpet                = WPET{j}{s1}{s2}{s3};  % Masking
            wmask               = Wmask{j}{s1}{s2}{s3};
            idx_wmask_matrix    = find(WWmask(k,:));
            idx = find(wmask);
            wpet(idx) = WWnew_pet(k,idx_wmask_matrix);
            WPETcorr{j}{s1}{s2}{s3} = wpet;           
        end
    end
end

clear w* WW* idx tmp*

%% Regression model and correction for resolution Level 1 and 2
for j = 1:J
    % Create coefficients matrixes
    [wX,wY,wZ]  = size(WPET{j}{1}{1}{1}{1});
    wQ          = 2*2*2*7;
    WWPET       = zeros(wQ,wX*wY*wZ);
    WWMRI       = zeros(wQ,wX*wY*wZ);
    WWMRIs      = zeros(wQ,wX*wY*wZ);
    WWmask      = zeros(wQ,wX*wY*wZ);
    for s1 = 1:2
        for s2 = 1:2
            for s3 = 1:2
                for s4 = 1:7
                    offset1             = s1+(s2-1)*2+(s3-1)*4+(s4-1)*8;
                    wpet                = WPET{j}{s1}{s2}{s3}{s4};
                    wmri                = WMRI{j}{s1}{s2}{s3}{s4};
                    wmris               = WMRIs{j}{s1}{s2}{s3}{s4};
                    wmask               = Wmask{j}{s1}{s2}{s3}{s4};
                    WWPET(offset1,:)    = (wpet(:));
                    WWMRI(offset1,:)    = (wmri(:));
                    WWMRIs(offset1,:)   = (wmris(:));
                    WWmask(offset1,:)   = (wmask(:));
                    
                end
            end
        end
    end
    clear wpet wmri wnoise wmask
% Scaling factor
    
    Gmri    = sum(abs(WWMRI(:)));
    Gmris   = sum(abs(WWMRIs(:)));
    Rscale  = Gmri/Gmris;                   % Resolution scale factor
    Gpet    = sum(abs(WWPET(:)).*Rscale);
    Gscale  = Gpet/Gmri;                    % Global scale factor
    WWnew_pet = WWPET;
    
    for s1 = 1:2
        for s2 = 1:2
            for s3 = 1:2
                for s4 = 1:7
                    k                   = s1+(s2-1)*2+(s3-1)*4+(s4-1)*8;
                    idx                 = find(WWmask(k,:));
                    vect_pet            = WWPET(k,idx).*Rscale;
                    vect_mri            = WWMRI(k,idx).*Gscale;
                    vect_mri(vect_mri>max(vect_pet)) = 0; 
                    vect_mri(vect_mri<min(vect_pet)) = 0;
                    
                    a                   = vect_mri.*vect_pet;
                    idx_neg             = find(a<0); %delete negative quadrants
                    
                    tmp_mri             = vect_mri;
                    tmp_pet             = vect_pet;
                    
                    tmp_pet(idx_neg)    = 0;
                    tmp_mri(idx_neg)    = 0;
                    
                    p                   = polyfit(tmp_mri,tmp_pet,1); % regression model - blue line
                    line                = p(1).*tmp_mri + p(2);
                    line2               = p_model(1).*tmp_mri + p_model(2);
                    RESquad             = (tmp_pet - line);           % residual
                    SIGMAquad           = mad(RESquad)/0.6745;
                    RESweight           = SIGMAquad/SIGMAres;         % Inter resolution weight factor

                    line2 = line2 + RESquad.*RESweight;               % Corrected coeff
                    
                    WWnew_pet(k,idx)    = line2; 
                    
                    wpet                = WPET{j}{s1}{s2}{s3}{s4};    % Masking
                    wmask               = Wmask{j}{s1}{s2}{s3}{s4};
                    idx_wmask_matrix    = find(WWmask(k,:));
                    idx = find(wmask);
                    wpet(idx) = WWnew_pet(k,idx_wmask_matrix);
                    WPETcorr{j}{s1}{s2}{s3}{s4} = wpet;
                    
                end
            end
        end
    end
    
    
end

%% ********** INVERSE WAVELET TRANSFORM ********
fprintf('%% ********** start inverse wavelet transform ********** %%\n');
pvcPET              = icplxdual3D(WPETcorr,J,Fsf,sf);
fprintf('%% ********** end inverse wavelet transform ********** %%\n');
pvcPET(pvcPET<0)    = 0;

offset1 = ((Zpow-Z)/2); offset2 = ((Ypow-Y)/2); offset3 = ((Xpow-X)/2); %Remove padding
for s3 = 1:Z
    ss3 = double(s3 + offset1);
    for s2 = 1:Y
        ss2 = double(s2+offset2);
        for s1 = 1:X
            ss1 = double(s1+offset3);
            yy(s1,s2,s3)=pvcPET(ss1,ss2,ss3);
        end
    end
end
pvcPET = yy;
switch flag %Go back from shift
    % x
    case 1
        pvcPET(1:end-shift,:,:) = pvcPET(shift+1:end,:,:);
    % y
    case 2
        pvcPET(:,1:end-shift,:) = pvcPET(:,shift+1:end,:);
    % z
    case 3
        pvcPET(:,:,1:end-shift) = pvcPET(:,:,shift+1:end);
end
clc
end
