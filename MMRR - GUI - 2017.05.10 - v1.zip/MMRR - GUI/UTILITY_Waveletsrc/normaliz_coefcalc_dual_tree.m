

N = 2^7;
M = 2^6;
%N = 2^9; 
L = 4;
x = zeros(N,N,M);

%[Fsf,Faf] = FSfarras;
[Fsf,Faf]  = AntonB;
[sf,af] = dualfilt1;

W_zero = cplxdual3D(x, L, Faf, af);

figure(1), clf
nor = [];

for scale = 1:L
    no = length(W_zero{scale}{1}{1}{1}{1})/2;
    for part = 1:2
    	for dir = 1:2
		 for dir2 = 1:2
       		for dir3 = 1:7
            	W = W_zero; 
    		    W{scale}{part}{dir}{dir2}{dir3}(no,no) = 1;
		        y = icplxdual3D(W, L, Fsf, sf);
        		nor{scale}{part}{dir}{dir2}{dir3} = sqrt(sum(sum(y.^2)));
		%sqrt(sum(sum(y.^2)))
		end
      end
	 end
    end
end

save nor_dualtree nor

