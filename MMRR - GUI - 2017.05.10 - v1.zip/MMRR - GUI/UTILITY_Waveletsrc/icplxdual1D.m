function y = icplxdual1D(w, J, Fsf, sf)

% Inverse Dual-Tree Complex 1D Discrete Wavelet Transform
% 
% USAGE:
%   y = icplxdual1D(w, J, Fsf, sf)
% INPUT:
%   w - wavelet coefficients
%   J - number of stages
%   Fsf - synthesis filters for final stage
%   sf - synthesis filters for preceeding stages
% OUTPUT:
%   y - output array
% See cplxdual2D
%
% WAVELET SOFTWARE AT POLYTECHNIC UNIVERSITY, BROOKLYN, NY
% http://taco.poly.edu/WaveletSoftware/

for j = 1:J
        [w{j}{1}{1} w{j}{2}{2}] = pm(w{j}{1}{1},w{j}{2}{2});
        [w{j}{1}{2} w{j}{2}{1}] = pm(w{j}{1}{2},w{j}{2}{1});
end

y = zeros(size(w{1}{1}{1})*2);
for m = 1:2
lo = w{J+1}{m};
for j = J:-1:2
lo = sfb(lo, w{j}{m}, sf{m});
end
lo = sfb(lo, w{1}{m}, Fsf{m});
y = y + lo;
end

% normalization
y = y/2;

