function [W]= normcoef(W,L,nor)


for scale = 1:L
    for part = 1:2
	  for dir = 1:2
	  	for dir2 = 1:2
       		for dir3 = 1:7
%			W{scale}{part}{dir}{dir2}{dir3} = W{scale}{part}{dir}{dir2}{dir3}/nor{scale}{part}{dir}{dir2}{dir3};
  			W{scale}{part}{dir}{dir2}{dir3} = W{scale}{part}{dir}{dir2}{dir3};
        end    
        end
	end
    end
end
