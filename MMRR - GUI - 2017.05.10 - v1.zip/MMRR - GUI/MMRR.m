function varargout = MMRR(varargin)
% MMRR MATLAB code for MMRR.fig
%      MMRR, by itself, creates a new MMRR or raises the existing
%      singleton*.
%
%      H = MMRR returns the handle to a new MMRR or the handle to
%      the existing singleton*.
%
%      MMRR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MMRR.M with the given input arguments.
%
%      MMRR('Property','Value',...) creates a new MMRR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MMRR_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MMRR_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MMRR

% Last Modified by GUIDE v2.5 22-Mar-2016 11:02:59

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MMRR_OpeningFcn, ...
                   'gui_OutputFcn',  @MMRR_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MMRR is made visible.
function MMRR_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MMRR (see VARARGIN)

clc
bckgnd=[1,.694,.392];
set(handles.GUI,'Color',bckgnd)
set(handles.axes1,'visible','off')
set(handles.axes2,'visible','off')
set(handles.axes3,'visible','off')
set(handles.axes4,'visible','off')
set(handles.start_button,'enable','off')
set(handles.save_button,'enable','off')
set(handles.load_pet,'userdata',0)
set(handles.load_mri,'userdata',0)
set(handles.load_mask,'userdata',0)
set(handles.panel,'visible','off')
L=imread('mmrr_logo.png');
imshow(L,'parent',handles.logo)
setAllowAxesZoom(zoom,handles.logo,false);
setAllowAxesPan(pan,handles.logo,false);


%%%% ADD PACKAGES
%Required packages: SPM8, NIFTI, WAVELSTRC
%Successfully test with Matlab 2012b

handles.currentFolder = pwd;
addpath(genpath(handles.currentFolder));
%addpath(genpath('/data/group/pet/software/spm8/')); %TO BE MODIFIED WITH SPM8 PACKAGE

% Choose default command line output for MMRR
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MMRR wait for user response (see UIRESUME)
% uiwait(handles.GUI);


% --- Outputs from this function are returned to the command line.
function varargout = MMRR_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



%% --- Executes on button press in load_pet.
function load_pet_Callback(hObject, eventdata, handles)
% hObject    handle to load_pet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cla(handles.axes1)
set(handles.axes1,'visible','off')
if get(handles.GUI,'Userdata')==2  % step 0:loading phase, step 1:after main code run, step 2:finished and saved
    wipe(hObject,handles); %wipe plots
    set(handles.GUI,'userdata',0);
elseif get(handles.GUI,'Userdata')==1
    wipe(hObject,handles); %wipe plots
    set(handles.GUI,'userdata',0);
    set(handles.panel,'visible','off')
    set(handles.save_button,'enable','off')
end
set(handles.pet_file,'string','PET image: ');
set(hObject,'userdata',0)
set(handles.start_button,'enable','off')
[handles.PET_File, handles.PET_Path] = uigetfile('*.nii','Select PET images file');
if handles.PET_File~=0
    handles.PET = load_nii([handles.PET_Path,'/',handles.PET_File]);
    set(hObject,'userdata',1)
    %set(handles.pet_file,'string',['PET image: ',handles.PET_Path,'/',handles.PET_File])
    set(handles.pet_file,'string',['PET image: ',handles.PET_File])
    handles.I{1}=handles.PET.img(:,:,round(end/2));
    imagesc(handles.I{1},'parent',handles.axes1)
    axis(handles.axes1,'off','image')
    text(1,1,'PET image','parent',handles.axes1,'color','w','fontsize',15)
    colormap(handles.axes1,'jet')
    axes(handles.axes1);freezeColors
    pause(.01)
end
if get(hObject,'userdata')*get(handles.load_mask,'userdata')*get(handles.load_mri,'userdata')==1
    handles=ready(hObject, eventdata, handles);
end
% Update handles structure
guidata(hObject, handles);


%% --- Executes on button press in load_mri.
function load_mri_Callback(hObject, eventdata, handles)
% hObject    handle to load_mri (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cla(handles.axes2)
set(handles.axes2,'visible','off')
if get(handles.GUI,'Userdata')==2  % step 0:loading phase, step 1:after main code run, step 2:finished and saved
    wipe(hObject,handles);
    set(handles.GUI,'Userdata',0)
elseif get(handles.GUI,'Userdata')==1
    wipe(hObject,handles); %wipe plots
    set(handles.GUI,'userdata',0);
    set(handles.panel,'visible','off')
    set(handles.save_button,'enable','off')
end
set(handles.mri_file,'string','MRI image: ');
set(hObject,'userdata',0)
set(handles.start_button,'enable','off')
[handles.MRI_File, handles.MRI_Path] = uigetfile('*.nii','Select MRI images file');
if handles.MRI_File~=0
    handles.MRI = load_nii([handles.MRI_Path,'/',handles.MRI_File]);
    [handles.nx,handles.ny,handles.nz] = size(handles.MRI.img);
    set(hObject,'userdata',1)
    %set(handles.mri_file,'string',['MRI image: ',handles.MRI_Path,'/',handles.MRI_File])
    set(handles.mri_file,'string',['MRI image: ',handles.MRI_File])
    handles.I{2}=handles.MRI.img(:,:,round(end/2));
    imagesc(handles.I{2},'parent',handles.axes2)
    axis(handles.axes2,'off','image')
    text(1,1,'MRI image','parent',handles.axes2,'color','w','fontsize',15)
    colormap(handles.axes2,'gray')
    axes(handles.axes2);freezeColors
    pause(.01)
end
if get(hObject,'userdata')*get(handles.load_mask,'userdata')*get(handles.load_pet,'userdata')==1
    handles=ready(hObject, eventdata, handles);
end
% Update handles structure
guidata(hObject, handles);

    
%% --- Executes on button press in load_mask.
function load_mask_Callback(hObject, eventdata, handles)
% hObject    handle to load_mask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cla(handles.axes3)
set(handles.axes3,'visible','off')
if get(handles.GUI,'Userdata')==2  % step 0:loading phase, step 1:after main code run, step 2:finished and saved
    wipe(hObject,handles); %wipe plots
    set(handles.GUI,'Userdata',0)
elseif get(handles.GUI,'Userdata')==1
    wipe(hObject,handles); %wipe plots
    set(handles.GUI,'userdata',0);
    set(handles.panel,'visible','off')
    set(handles.save_button,'enable','off')
end
set(handles.mask_file,'string','MASK image: ')
set(hObject,'userdata',0)
set(handles.start_button,'enable','off')
[handles.MASK_File, handles.MASK_Path] = uigetfile('*.nii','Select MASK images file');
if handles.MASK_File~=0
    handles.MASK = load_nii([handles.MASK_Path,'/',handles.MASK_File]);
    idxMASK = find(handles.MASK.img>0); % MAKE THE MASK BINARY
    handles.MASK.img = zeros(size(handles.MASK.img));
    handles.MASK.img(idxMASK) = 1;
    set(hObject,'userdata',1)
    %set(handles.mask_file,'string',['MASK image: ',handles.MASK_Path,'/',handles.MASK_File])
    set(handles.mask_file,'string',['MASK image: ',handles.MASK_File])
    handles.I{3}=handles.MASK.img(:,:,round(end/2));
    imagesc(handles.I{3},'parent',handles.axes3,[0 1])
    axis(handles.axes3,'off','image')
    text(1,1,'MASK image','parent',handles.axes3,'color','w','fontsize',15)
    colormap(handles.axes3,'gray')
    axes(handles.axes3);freezeColors
    pause(.01)
end
if get(hObject,'userdata')*get(handles.load_mri,'userdata')*get(handles.load_pet,'userdata')==1
    handles=ready(hObject, eventdata, handles);
end
% Update handles structure
guidata(hObject, handles);


function handles=ready(hObject, eventdata, handles)
handles.MRI.img = double(handles.MRI.img).*handles.MASK.img;
if strcmp(handles.PET_Path,handles.MRI_Path)~=1 || strcmp(handles.PET_Path,handles.MASK_Path)~=1
    disp('The three loaded images are in different folders, results will be saved in the PET image folder')
end
handles.saveFolder=handles.PET_Path;
set(handles.start_button,'enable','on')

%% --- Executes on button press in START.
function start_button_Callback(hObject, eventdata, handles)
% hObject    handle to start_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.start_button,'enable','off')
set(handles.load_pet,'enable','off')
set(handles.load_mri,'enable','off')
set(handles.load_mask,'enable','off')

[nx,ny,nz] = size(handles.MRI.img);
handles.nz=nz;
%%% FILTER
filter_param.nx = nx;
filter_param.nz = nz;
filter_param.FOV = nx;
filter_param.zfilter = 4;
filter_param.postFilterFWHM = 4;
MRIs = handles.MRI;
MRIs.img = petrecon_postfilter(MRIs.img,filter_param);
dim = size(handles.PET.img);

% Correct for odd number of voxel in one of the 3 dimensions
if mod(dim(1),2)
handles.PET.img = handles.PET.img(1:end-1,:,:);
handles.PET.hdr.dime.dim(2)=dim(1)-1;
handles.MRI.img = handles.MRI.img(1:end-1,:,:);
handles.MRI.hdr.dime.dim(2)=dim(1)-1;
MRIs.img = MRIs.img(1:end-1,:,:);
MRIs.hdr.dime.dim(2)=dim(1)-1;
handles.MASK.img = handles.MASK.img(1:end-1,:,:);
handles.MASK.hdr.dime.dim(2)=dim(1)-1;
end
if mod(dim(2),2)
handles.PET.img = handles.PET.img(:,1:end-1,:);
handles.PET.hdr.dime.dim(3)=dim(2)-1;
handles.MRI.img = handles.MRI.img(:,1:end-1,:);
handles.MRI.hdr.dime.dim(3)=dim(2)-1;
MRIs.img = MRIs.img(:,1:end-1,:);
MRIs.hdr.dime.dim(3)=dim(2)-1;
handles.MASK.img = handles.MASK.img(:,1:end-1,:);
handles.MASK.hdr.dime.dim(3)=dim(2)-1;
end
if mod(dim(3),2)
handles.PET.img = handles.PET.img(:,:,1:end-1);
handles.PET.hdr.dime.dim(4)=dim(3)-1;
handles.MRI.img = handles.MRI.img(:,:,1:end-1);
handles.MRI.hdr.dime.dim(4)=dim(3)-1;
MRIs.img = MRIs.img(:,:,1:end-1);
MRIs.hdr.dime.dim(4)=dim(3)-1;
handles.MASK.img = handles.MASK.img(:,:,1:end-1);
handles.MASK.hdr.dime.dim(4)=dim(3)-1;
handles.nz=dim(3)-1;
end

% Save copy of the original images

PtImage = fullfile(handles.PET_Path,[handles.PET_File(1:end-4),'_LowResolution.nii']);
save_nii(handles.PET,PtImage);
AImage = fullfile(handles.MRI_Path,[handles.MRI_File(1:end-4),'_MMRR.nii']);
save_nii(handles.MRI,AImage);
SAImage = fullfile(handles.MRI_Path,[handles.MRI_File(1:end-4),'_MMRR_SMOOTH.nii']);
save_nii(MRIs,SAImage);
mask = fullfile(handles.MASK_Path,[handles.MASK_File(1:end-4),'_MASK.nii']);
save_nii(handles.MASK,mask)

cd(handles.saveFolder)

set(handles.prog1,'visible','on')
set(handles.prog2,'visible','on')
set(handles.prog3,'visible','on')
set(handles.prog4,'visible','on')

%%% RUN
%RUN the code 4 times by shifting the image from 0 to 3 voxels along z-direction to remove artefacts
%due to the wavelet transforms
colormap('jet')
set(handles.status_text,'string',['Running main program - step 1/4...',char(10),'Command window displays the status of the current step']);
pause(.01)
handles.pvcPET_0 = SFS_corr_model(PtImage,AImage,SAImage,mask,0,1); 
set(handles.prog1,'BackgroundColor',[0.043 0.518 0.78]);
imagesc(handles.pvcPET_0(:,:,round(end/2)),'parent',handles.axes1)
axis(handles.axes1,'off','image')
text(1,1,'run 1','parent',handles.axes1,'color','w','fontsize',15)
set(handles.status_text,'string',['Running main program - step 2/4...',char(10),'Command window displays the status of the current step']);
pause(.01)
handles.pvcPET_1 = SFS_corr_model(PtImage,AImage,SAImage,mask,1,3);
set(handles.prog2,'BackgroundColor',[0.043 0.518 0.78]);
imagesc(handles.pvcPET_1(:,:,round(end/2)),'parent',handles.axes2)
axis(handles.axes2,'off','image')
text(1,1,'run 2','parent',handles.axes2,'color','w','fontsize',15)
set(handles.status_text,'string',['Running main program - step 3/4...',char(10),'Command window displays the status of the current step']);
pause(.01)
handles.pvcPET_2 = SFS_corr_model(PtImage,AImage,SAImage,mask,2,3);
set(handles.prog3,'BackgroundColor',[0.043 0.518 0.78]);
imagesc(handles.pvcPET_2(:,:,round(end/2)),'parent',handles.axes3)
axis(handles.axes3,'off','image')
text(1,1,'run 3','parent',handles.axes3,'color','w','fontsize',15)
set(handles.status_text,'string',['Running main program - step 4/4...',char(10),'Command window displays the status of the current step']);
pause(.01)
handles.pvcPET_3 = SFS_corr_model(PtImage,AImage,SAImage,mask,3,3); 
set(handles.prog4,'BackgroundColor',[0.043 0.518 0.78]);
imagesc(handles.pvcPET_3(:,:,round(end/2)),'parent',handles.axes4)
axis(handles.axes4,'off','image')
text(1,1,'run 4','parent',handles.axes4,'color','w','fontsize',15)

pause(.01)
clc
cd(handles.currentFolder)

set(handles.prog1,'visible','off')
set(handles.prog2,'visible','off')
set(handles.prog3,'visible','off')
set(handles.prog4,'visible','off')

set(handles.panel,'visible','on')

%%% Select the subplot with NO artefacts
handles.pvc_tot = handles.pvcPET_0; %Initialize as the one with no translation
slice = round(handles.nz/2);
imagesc(handles.pvcPET_1(:,:,slice),'parent',handles.axes1)
axis(handles.axes1,'off','image')
text(1,1,'A','parent',handles.axes1,'color','w','fontsize',20)
imagesc(handles.pvcPET_1(:,:,slice+1),'parent',handles.axes2)
axis(handles.axes2,'off','image')
text(1,1,'B','parent',handles.axes2,'color','w','fontsize',20)
imagesc(handles.pvcPET_1(:,:,slice+2),'parent',handles.axes3)
axis(handles.axes3,'off','image')
text(1,1,'C','parent',handles.axes3,'color','w','fontsize',20)
imagesc(handles.pvcPET_1(:,:,slice+3),'parent',handles.axes4)
axis(handles.axes4,'off','image')
text(1,1,'D','parent',handles.axes4,'color','w','fontsize',20)

set(handles.status_text,'string','Select appropriate shifted image from the panel below');
set(handles.GUI,'userdata',1); % step 0:loading phase, step 1:after main code run, step 2:finished and saved

set(handles.load_pet,'enable','on')
set(handles.load_mri,'enable','on')
set(handles.load_mask,'enable','on')

% Update handles structure
guidata(hObject, handles);


%% --- Executes on button press in save_button.
function save_button_Callback(hObject, eventdata, handles)
% hObject    handle to save_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

x=get(handles.panel,'userdata');
set(handles.panel,'visible','off')
slice = round(handles.nz/2);
%RESAMPLING IMAGES TO REMOVE RINGING
if x == 1, tmp = slice:-4:1; start = min(tmp); end
if x == 2, tmp = slice+1:-4:1; start = min(tmp); end
if x == 3, tmp = slice+2:-4:1; start = min(tmp); end
if x == 4, tmp = slice+3:-4:1; start = min(tmp); end
zmax=handles.nz;
while(mod(zmax-start,4)~=0)
    zmax=zmax-1;
end
handles.pvc_tot(:,:,start:4:zmax) = handles.pvcPET_1(:,:,start:4:handles.nz);
if x == 1, tmp = slice-1:-4:1; start = min(tmp); end
if x == 2, tmp = slice:-4:1; start = min(tmp); end
if x == 3, tmp = slice+1:-4:1; start = min(tmp); end
if x == 4, tmp = slice+2:-4:1; start = min(tmp); end
zmax=handles.nz;
while(mod(zmax-start,4)~=0)
    zmax=zmax-1;
end
handles.pvc_tot(:,:,start:4:zmax) = handles.pvcPET_2(:,:,start:4:handles.nz);
if x == 1, tmp = slice-2:-4:1; start = min(tmp); end
if x == 2, tmp = slice-1:-4:1; start = min(tmp); end
if x == 3, tmp = slice:-4:1; start = min(tmp); end
if x == 4, tmp = slice+1:-4:1; start = min(tmp); end
zmax=handles.nz;
while(mod(zmax-start,4)~=0)
    zmax=zmax-1;
end
handles.pvc_tot(:,:,start:4:zmax) = handles.pvcPET_3(:,:,start:4:handles.nz);

%%% SAVE OUTPUT
cd(handles.saveFolder)
set(handles.status_text,'string','Saving results...');
% mask = load_nii('MASK.nii');
% PET = load_nii('PET_vt_scanner.nii');
PET = handles.PET;
MASK = handles.MASK;
PVC = PET;
PET.img = double(PET.img).*double(MASK.img);
PVC.img = handles.pvc_tot.*double(MASK.img);
max_scale = max(max(PVC.img(:,:,slice)));
%%%%%%%%%%%%%%%%%%%%----------- PLOTS -----------%%%%%%%%%%%%%%%%%%%%%%%%%%
cla(handles.axes4)
set(handles.axes4,'visible','off')

imagesc(handles.MRI.img(:,:,slice),'parent',handles.axes1)
axis(handles.axes1,'off','image')
caxis(handles.axes1,[0 max(max(handles.MRI.img(:,:,slice)))]);
colormap(handles.axes1,'gray')
text(1,1,'MR','parent',handles.axes1,'color','w','fontsize',15)
axes(handles.axes1);freezeColors
% a=colorbar('SouthOutside');cbfreeze(a);

imagesc(PET.img(:,:,slice),'parent',handles.axes2)
axis(handles.axes2,'off','image')
caxis(handles.axes2,[0 max_scale]);
colormap(handles.axes2,'jet'),
text(1,1,'Standard PET','parent',handles.axes2,'color','w','fontsize',15)
axes(handles.axes2);freezeColors
% b=colorbar('SouthOutside');cbfreeze(b);

imagesc(MASK.img(:,:,slice),'parent',handles.axes3)
axis(handles.axes3,'off','image')
caxis(handles.axes3,[0 1]);
colormap(handles.axes3,'gray'), 
text(1,1,'MASK','parent',handles.axes3,'color','w','fontsize',15)
axes(handles.axes3);freezeColors
% c=colorbar('SouthOutside');cbfreeze(c);

imagesc(PVC.img(:,:,slice),'parent',handles.axes4)
axis(handles.axes4,'off','image')
caxis(handles.axes4,[0 max_scale]);
colormap(handles.axes4,'jet'), 
text(1,1,'High Resolution PET','parent',handles.axes4,'color','w','fontsize',15)
axes(handles.axes4);freezeColors
% c=colorbar('SouthOutside');cbfreeze(c);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
save_nii(PVC,[fullfile(handles.PET_Path,handles.PET_File(:,1:end-4)),'_MMRR.nii'])

cd(handles.currentFolder)
set(handles.GUI,'Userdata',2);
set(handles.save_button,'enable','off')
set(handles.load_pet,'enable','on')
set(handles.load_mri,'enable','on')
set(handles.load_mask,'enable','on')
set(handles.start_button,'enable','on')
set(handles.status_text,'string','Process completed');
credits_ButtonDownFcn(handles.credits, eventdata, handles);




% --- Executes on button press in check1.
function check1_Callback(hObject, eventdata, handles)
% hObject    handle to check1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of check1
set(hObject,'Value',1);
set(handles.panel,'userdata',1);
set(handles.check2,'Value',0);
set(handles.check3,'Value',0);
set(handles.check4,'Value',0);
set(handles.save_button,'enable','on')
guidata(hObject, handles);

% --- Executes on button press in check2.
function check2_Callback(hObject, eventdata, handles)
% hObject    handle to check2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of check2
set(hObject,'Value',1);
set(handles.panel,'userdata',2);
set(handles.check1,'Value',0);
set(handles.check3,'Value',0);
set(handles.check4,'Value',0);
set(handles.save_button,'enable','on')
guidata(hObject, handles);

% --- Executes on button press in check3.
function check3_Callback(hObject, eventdata, handles)
% hObject    handle to check3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of check3
set(hObject,'Value',1);
set(handles.panel,'userdata',3);
set(handles.check1,'Value',0);
set(handles.check2,'Value',0);
set(handles.check4,'Value',0);
set(handles.save_button,'enable','on')
guidata(hObject, handles);

% --- Executes on button press in check4.
function check4_Callback(hObject, eventdata, handles)
% hObject    handle to check4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of check4
set(hObject,'Value',1);
set(handles.panel,'userdata',4);
set(handles.check1,'Value',0);
set(handles.check2,'Value',0);
set(handles.check3,'Value',0);
set(handles.save_button,'enable','on')
guidata(hObject, handles);

function wipe(hObject,handles)
cla(handles.axes1)
set(handles.axes1,'visible','off')
cla(handles.axes2)
set(handles.axes2,'visible','off')
cla(handles.axes3)
set(handles.axes3,'visible','off')
cla(handles.axes4)
set(handles.axes4,'visible','off')
set(handles.status_text,'string','');
guidata(hObject, handles);


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over credits.
function credits_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to credits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject,'string','User Interface by Alberto Pellizzon')
pause(3)
set(hObject,'string','Elisabetta Grecchi - March 2016')
