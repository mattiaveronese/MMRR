% PURPOSE:  construct a reconParams structure from a PET dicom image header
%
% USAGE: 
%   reconParams=petrecon_reconParamsFromDicomHdr(dicomHdr);
% or
%   reconParams=petrecon_reconParamsFromDicomHdr(reconParams, dicomHdr);
%
% Inputs:
%	dicomHdr: header from PET image, read with pet-dicom-dict.txt
%       reconParams: optional argument. structure with options for petrecon3d_ng et al
% Outputs:
%       reconParams: updated (or created) structure
% WARNING:
% Not all parameters are set, but an attempt is made to set
% whatever is written to the dicom header by the pettoolbox.

% Copyright (c) 2008-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%  09Apr2008: Kris Thielemans
%  Created
%
% Modifications:
%   Tim Deller 01 Dec 2008
%      - Updated to work with the newly declared pet-dicom-dict.txt fields
%      - Cleaned up indenting
%   Kris Thielemans Mar 2010
%      - initialise xTarget and yTarget taking HF or FF patient orientation into account
%      - make nx and double to avoid problems in petrecon3d_ng with sqrt statements
%      - removed voxelSize field in output
%      - set reconParams.decayFlag from dicomHdr.DecayCorrection
%      - add 2 argument usage to allow updating an existing reconParams

