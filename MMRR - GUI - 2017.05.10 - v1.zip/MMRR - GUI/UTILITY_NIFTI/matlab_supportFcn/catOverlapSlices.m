%  catOverlapSlices.m
%   This function performs a weighted addition of overlapped 
%   2D sinograms
%
%   Syntax:
%       sino = catOverlapSlices(sino, sinoOverlapSlices, acqParams)
%       sino = catOverlapSlices(sino, sinoOverlapSlices, acqParams, wcc)
%
%   Inputs:
%       sino                -   3D array of overlapped sinogram slices
%                               from frame N. (These would be the slices 1
%                               to reconParams.overlap)
%       sinoOverlapSlices   -   3D array of overlapped sinogram slices
%                               from frame N-1. (These would be the slices
%                               acqParams.nZ-reconParams.overlap+1 to acqParams.nZ)
%       acqParams           -   Structure defining projPlane dimension
%                               (See ir2d.m for definition)
%       wcc                 -   Well counter calibration factors. This is a
%                               vector of acqParams.nZ factors. This is an 
%                               optional parameter, if not specified slices 
%                               are weighted equally
%
%   Outputs:
%       sino                -   3D array of overlapped sinogram slices
%                               after overlap correction

% Copyright (c) 2004-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   10/25/2004   Written by RMM

