% find x/yOffset and rotate from l/pTarget and Vqc parameters
% USAGE:
%  reconParams=petrecon_setXYOffset(reconParams, rdf);
% SYNOPSIS
%  lTarget and pTarget are in the patient coordinate system. This function translates these
%  to the scanner coordinate system. Default lTarget and pTarget are zero.
% INPUTS: 
%   reconParams: structure with parameters for the reconstruction. 
%     This function only uses the following fields lTarget, pTarget.
%     If these are not present, this function checks xTarget, yTarget for historical 
%     reasons.
%   rdf : RDF header (used for Vqc and patient orientation)
% OUTPUT:
%   reconParams: structure with additional (or updated) fields xOffset, yOffset, rotate

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%  Original version: Ravindra Manjeshwar/Steve Ross
%  Kris Thielemans August 2009
%    Moved code from petrecon3d_ng.m etc into separate function
%  Kris Thielemans March 2010
%    Added l/pTarget

