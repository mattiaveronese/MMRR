% Initialize recon parameters structure required for petrecon2d functions.
%
% FILE NAME: petrecon2d_params.m
%
% DEVELOPER: Steve Ross
%
% PURPOSE:  Initialize recon parameters structure required for petrecon2d functions.
%
% INPUT:  none

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:


%INPUT FILENAMES
reconParams.dir=['/mnt/usb/2DIR/']; % needs trailing slash. Can be './' for current directory
reconParams.rawFromDicom = 1;  %Set to 1 if reading files from dicom
reconParams.writeDicomImage = 1;  %Set to 1 if reading files from dicom
reconParams.dicomImageSeriesDesc = ['Offline_2D']; % No spaces allowed. Will also be
                                                   % used as directoryname
reconParams.dicomImageSeriesNum = 806;

if (reconParams.rawFromDicom == 0)
	reconParams.inputFilename=[reconParams.dir 'ex2d.rdf.decomp'];
	reconParams.pifaFilename=[reconParams.dir 'quant2.PIFA'];
	reconParams.normFilename=[reconParams.dir 'norm2d.rdf']'; % Set to RDF file with norm info
	reconParams.overlap=0;
	reconParams.nFrames=1;
end
reconParams.imOutFilename= [reconParams.dir 'ir2d'];  %floating point output filename

%RECON CORRECTION PARAMETERS. These flags indicate whether corrections will be generated. Not if they will be applied in recon.   
reconParams.irReconPreprocessFlag = 1;	  %Set to 0 to skip generation of all corrections.
% flags per 'correction'. Note that if you put them to 0, they will not be generated in this run
% although the recon will likely need them
reconParams.randomsFlag=1;  %  1: RFS    2: Delays
reconParams.deadtimeFlag=1;  
reconParams.normalizationFlag = 1;
reconParams.scatterFlag = 1;
reconParams.attenuationFlag = 1;
reconParams.decayFlag = 1;
reconParams.CTACSinoFlag = 0;
reconParams.PIFAfromCTFlag = 0;         %Set to 1 to generate PIFAs from CT images (most common)
reconParams.PIFAfromProductFlag = 1;    %Set to 1 to generate PIFAs from product PIFA files (AAAA*_)


%PREPROCESS OUTPUT FILENAMES
reconParams.emFilename      = [reconParams.dir 'gnd_tsr.vp'];
reconParams.scatterFilename = [reconParams.dir 'gnd_s.vp'];
reconParams.randomsFilename = [reconParams.dir 'gnd_r.vp'];
reconParams.keyholeFilename = [reconParams.dir 'keyhole.vp'];
reconParams.acfFilename     = [reconParams.dir 'ctac2d.vp'];

%OSEM RECONSTRUCTION CORRECTION PARAMETERS
reconParams.reconFlag = 1;      %0: No Recon  1: IR Recon  2:
reconParams.scatterCorrFlag = 2;        % scatter correction 0: No correction, 1: Pre correction 2: loop correction
reconParams.randomsCorrFlag = 2;        % randoms correction 0: No correction, 1: Pre correction 2: loop correction
reconParams.acfCorrFlag = 2;            % attenuation correction 0: No correction, 1: Pre correction 2: loop correction
reconParams.radialRepositionFlag = 1;

%RECONSTRUCTION TARGETING PARAMETERS
reconParams.FOV=700.;
reconParams.xTarget = 0;		%Units: mm
reconParams.yTarget = 0;		%Units: mm
reconParams.nx = 128;
reconParams.ny = 128;

%OSEM SETTING AND FILTER SETTINGS
reconParams.reconType = 'OSEM';         % Options are 'OSEM' or 'RAMLA'
reconParams.numSubsets = 28;            % Has to be a factor of the number of angles
reconParams.numIterations = 2;              % Number of iterations
reconParams.startSubset = 1;            % Start subset
reconParams.startIteration = 1;         % Start iteration
reconParams.keepSubsetUpdates = 0;      % Store intermediate results after each subset
reconParams.keepIterationUpdates = 1;   % Store intermediate results after each iteration
reconParams.postFilterFWHM = 0;         % FWHM for gaussian post filter, Units: mm
reconParams.loopFilterFWHM = 0;         % FWHM for gaussian loop filter, Units: mm
reconParams.zfilter = 0;                % Center weighted for 3-point center weighted averager.
reconParams.irRatioClipValue=1.0E-10;
reconParams.norm2dclipvalue=100.;      % Used in petrecon2d.m (but not petrecon2d_ng.m) for thresholding: maximum value for efficiencies  (efficiencies should be ~1)
