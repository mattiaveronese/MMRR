%  sinogramRadCoords.m
%
%  This program computes the radial position of sinogram elements per
%  the detector model described in "Improved Radial Repositioning..." 
%  by C. W Stearns (ASL Technical Report 92-54).  Optionally produces
%  the crystal-crystal boundary positions (needed by the native geometry
%  projectors.
%
%  Syntax:  
%       rn = sinogramRadCoords(nu,nXtals,alpha,beta,ringDia)
%       [rn,bounds] = sinogramRadCoords(nu,nXtals,alpha,beta,ringDia)
%   
%   Inputs:
%       nu          Number of sinogram row elements
%       nXtals      Number of crystals per block
%       alpha       Inter-crystal pitch angle (radians)
%       beta        Inter-blockpitch angle (radians)
%       ringDia     Ring diameter
%   Outputs:
%       rn          Sinogram position array (nXtals-by-nu)
%       bounds      Sinogram element boundary array (nXtals-by-(nu+1))
%
%   Typical usage with acquisition data structures:
%     rn = sinogramRadCoords(acqParams.nU,scanner.radialCrystalsPerBlock,...
%                       scanner.interCrystalPitch,scanner.interBlockPitch,...
%                       scanner.effectiveRingDiameter);
%   Note that projectors such as tof*DD3D require the transpose of the
%     bounds array

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   Routine created 15Jan2007 from geoCorrection.m by CWS.



