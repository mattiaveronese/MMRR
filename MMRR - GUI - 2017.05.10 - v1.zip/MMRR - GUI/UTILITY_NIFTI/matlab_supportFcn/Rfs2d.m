%FILE NAME: Rfs2d.m
%
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: Execute randon correction for singles in 2D   
%
%-----------------------------------------------------------------------
% PURPOSE: Identify the X & Y location of metallic fillings and estimated 
%          its radious and area.
% Params:   singles         Input, Single data store in variable 
%           acceptance      Input, Axial Acceptance
%           timingwindow    Input, Nano-Seconds
%           scantime        Input, Depends on the Scan, Seconds
%           debug           Input,
%           randoms         Output, 
% 
%     Ex: rdfs2d=Rfs2d(ex2d,singles2D,5,9*1.302083*0.988426*1.0,120,0);
%         rdfs2d=Rfs2d(ex2d,singles2D,[],[],[],0);
%----------------------------------------------------------------------

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

