% FILE NAME: convertLutToBlockMap.m
%
%FILE NAME: convertLutToBlockMap.m
%
%ORIGINAL C CODE: William Braymer & Peter Crandall & Peri Arul
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: This function converts the X LUT's from being crystal maps to 
% block maps for use in deadtime correction the status. 
%
%-----------------------------------------------------------------------
% PURPOSE: This function converts the X LUT's from being crystal maps to 
% block maps for use in deadtime correction the status.
%
% Params:   samples                 Input, number of samples
%           projections             Input, number of projections
%           radialCrystalsPerUnit   Input, radial crystals per unit
%           xLuts                   Input, sinogram crystal coordinate maps
%           xLuts                   Output,
%
%   Ex: xLuts=convertLutToBlockMap(header.nx,header.nz,radialCrystalsPerUnit,xLuts);
%----------------------------------------------------------------------

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:


