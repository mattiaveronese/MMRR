%FILE NAME: createXLuts.m
%
%ORIGINAL C CODE: William Braymer & Peter Crandall
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: Build sinogram crystal coordinate maps    
%-----------------------------------------------------------------------
% PURPOSE: This function creates loo-up-tables that map the combined
%  index of v-theta (PET 3D raw data organization, range 0-264, or 
%  0-306), to axial ring nubers (range 0-17).
%  See ASL Technical Report 94-11, C.W. Stearns.
%
% Params:   nVTheta         Input, number of samples
%           nZ              Input, number of projections
%           zLuts           Output, 
%
%   Ex: zLuts=createZLuts(header.ny,axialCrystalsPerUnit*axialUnitsPerModule*...
%                     axialModulesPerSystem);
%----------------------------------------------------------------------

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:


