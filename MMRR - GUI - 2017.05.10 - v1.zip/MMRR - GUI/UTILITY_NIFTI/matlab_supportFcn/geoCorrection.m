%  geoCorrection.m
%
%  This program perfoms radial repositioning of emission sinograms or 
%  3D projection planes. 
%  Implementation based on "Improved Radial Repositioning" C. W Stearns 
%  ASL Technical Report 92-54  
%
%  Syntax:  
%       geoCorrSino = geoCorrection(sino,scanner,acqParams);
%       geoCorrSino = geoCorrection(sino,scanner,acqParams, rrSamples);
%   
%   Inputs:
%       sino        -   Sinogram or projection plane before radial
%                       repositioning
%       scanner     -   scanner detector geometry
%       acqParams   -   Structure defining projPlane dimension
%                              (See ir3d.m for definition)
%       rrSamples   -   Number of radial repositioned bins. This is 
%                       optional parameter - if not specified it is computed
%
%   Outputs:
%       geoCorrSino   - Radial repositioned sinogram or projection plane

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

