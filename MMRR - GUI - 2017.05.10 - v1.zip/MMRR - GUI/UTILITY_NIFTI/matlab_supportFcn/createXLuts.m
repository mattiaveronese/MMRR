%FILE NAME: createXLuts.m
%
%ORIGINAL C CODE: William Braymer & Peter Crandall
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: Build sinogram crystal coordinate maps    
%-----------------------------------------------------------------------
% PURPOSE: Build sinogram crystal coordinate maps. Each index pair ( one 
%  index from each map for a sinogram element ) indentifies the crystals 
%  ( within a ring ) which are in coincidence for that element of the 
%  sinogram.
%
% Params:   samples         Input, number of samples
%           projections     Input, number of projections
%           crystalsPerRing Input, crystals per ring
%           xLuts           Output, 
%
%   Ex:xLuts=createXLuts(header.nx, header.nz, ...
%                     radialCrystalsPerUnit * radialUnitsPerModule...
%                     * radialModulesPerSystem);
%----------------------------------------------------------------------

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:


