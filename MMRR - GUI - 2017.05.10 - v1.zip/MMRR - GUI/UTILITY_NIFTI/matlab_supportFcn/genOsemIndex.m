% FILE NAME: genOsemIndex.m
% =================================================%
% 
%  genOsemIndex generates the sequence of subsets for 
%  ordered subsets algorithms.
%  The sequence contains the index of the first angle 
%  for each subset. 
%  Implementation based on product C-code and its 
%   IDL version written by Steve Ross
%
%   Syntax:
%       iangset = genOsemIndex(numSubsets,nPhi)
%
%   Inputs:
%       numSubsets  -   number of subsets (N)
%       nPhi        -   total number of angles
%
%   Outputs:
%       iangset     -   ordered sequence of subsets

% Copyright (c) 2004-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   06/26/2004   Written by RMM
%   07/19/2004   Changed genOsemIndex to give subset indices
%                from 0 to N-1 instead of 1 to N

