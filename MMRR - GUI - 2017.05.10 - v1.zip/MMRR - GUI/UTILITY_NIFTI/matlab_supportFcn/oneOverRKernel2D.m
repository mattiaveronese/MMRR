% compute 1/r kernel for 2D convolution
% FILE NAME: oneOverRKernel2D.m
%
% DEVELOPER: Kris Thielemans
%
% PURPOSE:  This function computes a 2D 1/r kernel (in space), avoiding the
% singularity by (analytically) convolving it with a 2D Gaussian.
% This kernel can be used to do 2D forward-backprojection by convolution.
%
% USAGE:
%   kernel=oneOverRKernel2D(kernelSize, sigma);
% INPUTS:
%   kernelSize: either a vector giving x and y size, or a scalar, in which case x and y size are set equal
%   sigma: either a vector giving x and y sigma of the Gaussian, or a scalar, in which case x and y sigma are set equal
%       sigma defaults to 1/log(8), giving a Gaussian of FWHM 1

% Copyright (c) 2008-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

