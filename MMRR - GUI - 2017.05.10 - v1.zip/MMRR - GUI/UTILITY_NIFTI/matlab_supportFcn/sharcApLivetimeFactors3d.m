%FILE NAME: sharcApLivetimeFactors3d.m
%
%ORIGINAL C CODE: Scott Schubert
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: This function should be called once per frame before calling
%  sharcAp3dDeadtime().The output livetime factors from livetimeFactors3d()
%  are then passed to sharcAp3dDeadtime().
%
%MODIFICATION HISTORY:
%
%-----------------------------------------------------------------------
% PURPOSE: This function calculates the 3D livetime factors used by
% sharcAp3dDeadtime() to correct a uv-plane for deadtime.  The 3D livetime
% factors are the slice-independent coincidence livetime LTC(i,j) and the
% pileup livetime LTP(i,z) described in equations (4) and (5) of "3D
% Deadtime: Algorithm Report", 4/15/94, S. Schubert.
% See "3D Deadtime: Algorithm Report", 4/15/94, S. Schubert.
%
% Params:   axialUnitsPerModule         Input,
%           radialUnitsPerModule        Input,
%           axialModulesPerSystem       Input,
%           radialModulesPerSystem      Input,
%           axialCrystalsPerUnit        Input,
%           intCorrectionConstant       Input,
%           muxCorrectionConstant       Input,
%           timingCorrectionConstant    Input,
%           pileupCorrectionConstants   Input,
%           unitIntDeadTimeData         Input,
%           unitMuxDeadTimeData         Input,
%           sorterInputCoincCount       Input,
%           sorterOverrunLosses         Input,
%           coincProcessorLosses        Input,
%           asicCorrectionFactors       Input,
%           outData                     Output,
%
%     Ex: deadTimeData=sharcApLivetimeFactors3d(axialUnitsPerModule,...
%               radialUnitsPerModule,axialModulesPerSystem,...
%               radialModulesPerSystem,axialCrystalsPerUnit,...
%               intCorrectionConstant,muxCorrectionConstant,...
%               timingCorrectionConstant,pileupCorrectionConstants,...
%               unitIntDeadTimeData,unitMuxDeadTimeData,...
%               sorterInputCoincCount,sorterOverrunLosses,...
%               coincProcessorLosses,asicCorrectionFactors);
%-------------------------------------------------------------------------%
% VARIABLE CORRELATION BETWEEN MATLAB AND C CODE
%-------------------------------------------------------------------------%
% sharcApLivetimeFactors3d(                         sharcApLivetimeFactors3d(
% sysGeometry.axialBlocksPerModule,                 s32 axialUnitsPerModule,
% sysGeometry.radialBlocksPerModule,                s32 radialUnitsPerModule,
% sysGeometry.axialModulesPerSystem,                s32 axialModulesPerSystem,
% sysGeometry.radialModulesPerSystem,               s32 radialModulesPerSystem,
% sysGeometry.axialCrystalsPerBlock,                s32 axialCrystalsPerUnit,
% &(pDeadtimeStruct->intCorrFactor3d),              f32 *intCorrectionConstant,
% &(pDeadtimeStruct->muxCorrFactor3d),              f32 *muxCorrectionConstant,
% &(pDeadtimeStruct->timingCorrFactor3d),           f32 *timingCorrectionConstant,
% pDeadtimeStruct->pileupFactors3d,                 f32 *pileupCorrectionConstants,
% pIntDeadtime,                                     f32 *unitIntDeadTimeData,
% pMuxDeadtime,                                     f32 *unitMuxDeadTimeData,
% &(pDeadtimeStruct->exSorterInputCoincCount[0]),   float *sorterInputCoincCount,
% &(pDeadtimeStruct->exSorterOverrunLosses[0]),     float *sorterOverrunLosses,
% &(pDeadtimeStruct->exCoincProcessorLosses[0]),    float *coincProcessorLosses,
% pDeadtimeStruct->asicCorrFactors3d,               f32 *asicCorrectionFactors,
% m_ppDeadtimeWorkBuff[0],                          f32 *workBuff, float[ulBlocksPerSystem + ulBlocksPerSystem + (ulBlocksPerSystem * ulBlocksPerSystem) + (ulModulesPerSystem * ulModulesPerSystem)]
% &(pDeadtimeStruct->livetimeFactorStatus),         s32 *errorStatus,
% m_pLivetimeCoincidence,                           f32 *livetimeCoincidence,
% m_pLivetimePileup);                               f32 *livetimePileup
%
% @sharcApLivetimeFactors3d
%
%   Outputs:  errorStatus:          status:  sharcCmpLivetimeStatusEnum
%             livetimeCoincidence:	336x336 array of coincidence livetime products
%             livetimePileup:  		336x18 array of pileup livetime
%   NOTE:  livetimeCoincidence, livetimePileup are actually livetime corrections
%          (1/livetime), so they can be applied as multiplications.
%   NOTE:  workBuff, livetimeCoincidence, livetimePileup are malloc()/free() by caller.
%   NOTE:  the unitIntDeadTimeData is modified by this routine (sorted into ring-major order).
%-------------------------------------------------------------------------%

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:


