%FILE NAME: Deadtime2D.m
%
%ORIGINAL CODE: William Braymer & Peter Crandall
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: Execute 2D Deadtime Correction   
%
%MODIFICATION HISTORY:
% mod to use slice number to select appropriate slice correction factor
%
%-----------------------------------------------------------------------
% PURPOSE: Generate deadtime correction for a single slice.
% Params:   sinoIn          Input, raw data pre deadtime, vector format ([nx*ny,1])  
%           header          Input, header information
%           configuration   Input, system configuration
%           deadTimeData    Input, deatime information from exterior
%                                  functions, sharcApLivetimeFactors 
%                                  (unitLiveTimeProduct,unitIntDeadTimeData)
%           xLuts           Input, sinogram crystal coordinate maps
%           sinoOut         Output,corrected raw data
% 
%     Ex: sinoOut=Deadtime2D(sinoIn,header,[],deadTimeData,xLuts);
%-------------------------------------------------------------------------%
% VARIABLE CORRELATION BETWEEN MATLAB AND C CODE
%-------------------------------------------------------------------------%
% inBuff;                       pSino
% sinoSize;                     m_pParamStruct->numberSamples*m_pParamStruct->numberProjections,
% sliceNumber;                  sliceNumber
% dataType;                     IgJobPacket[uiSliceIndex].cmpPacketDataType
% axialCrystalsPerUnit;         sysGeometry.axialCrystalsPerBlock
% axialUnitsPerModule;          sysGeometry.axialBlocksPerModule
% axialModulesPerSystem;        sysGeometry.axialModulesPerSystem
% radialCrystalsPerUnit;        sysGeometry.radialCrystalsPerBlock
% radialUnitsPerModule;         sysGeometry.radialBlocksPerModule
% radialModulesPerSystem;       sysGeometry.radialModulesPerSystem
% sorterInputCoincCount;        &(pDeadtimeStruct->exSorterInputCoincCount[fileNumber])
% sorterOverrunLosses;          &(pDeadtimeStruct->exSorterOverrunLosses[fileNumber])
% coincProcessorLosses;         &(pDeadtimeStruct->exCoincProcessorLosses[fileNumber])
% hrPileupFactors;              pDeadtimeStruct->pileupFactors2dHr
% hsPileupFactors;              pDeadtimeStruct->pileupFactors2dHs
% crossRingWeightingFactors;    pDeadtimeStruct->crossRingWeightingFactors
% unitLiveTimeProduct;          m_ppUnitLiveTimeProductBuff[fileNumber]
% unitIntDeadTimeData;          exUnitIntDeadtimeBuff
% deadTimeCalcBuffer;           m_ppExUnitMuxDeadtimeBuff[uiBufferIndex]
% asicChipCorrectionSino;       m_pexCpmAsicCorrSinoBuff
% indexSino1;                   m_pLutX1
% indexSino2;                   m_pLutX2
% workBuff1;                    m_ppDTWorkBuffer1[uiBufferIndex]
% workBuff2;                    m_ppDTWorkBuffer2[uiBufferIndex]
% workBuff3;                    m_ppDTWorkBuffer3[uiBufferIndex]
% outBuff;                      pSino
%--------------------------------------------------------------------------
% VARIABLE DECLARATION
%--------------------------------------------------------------------------

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.


