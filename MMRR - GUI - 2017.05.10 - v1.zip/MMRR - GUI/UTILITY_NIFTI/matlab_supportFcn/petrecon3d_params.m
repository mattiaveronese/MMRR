% Initialize recon parameters structure required for petrecon3d functions.
%
% FILE NAME: petrecon3d_params.m
%
% DEVELOPER: Steve Ross
%
% PURPOSE:  Initialize reconParams structure required for  petrecon functions.
%
% INPUT:  none

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:


%% RECONSTRUCTION PARAMETERS
reconParams.FOV                 = 700;     % Units: mm
reconParams.xTarget             = 0;	   % Units: mm
reconParams.yTarget             = 0;	   % Units: mm
reconParams.nx                  = 128;
reconParams.ny                  = 128;

reconParams.numSubsets          = 32;      % Has to be a factor of the number of angles
reconParams.numIterations       = 2;         
reconParams.postFilterFWHM      = 0;       % FWHM for gaussian post filter, Units: mm
reconParams.loopFilterFWHM      = 0;       % FWHM for gaussian loop filter, Units: mm
reconParams.zfilter             = 0;       % Center weighted for 3-point center weighted averager.

%% INPUT/OUTPUT FILENAMES AND INFORMATION
reconParams.dir          = [pwd filesep];  % Needs the trailing fileseparator. 
                                           %    OK to be './' for current directory
reconParams.rawFromDicom = 1;              % Set to 1 if reading files from dicom
                                           % See notes in reconstruction program if using non-DICOM
                                           %    data source.
if (reconParams.rawFromDicom == 0)
	reconParams.inputFilename  = [reconParams.dir 'offcent.rdf.decomp'];
	reconParams.pifaFilename   = [reconParams.dir 'pifa.oc'];
	reconParams.normFilename   = [reconParams.dir 'norm3d'];    % Set to RDF file with norm info
	reconParams.overlap        = 0;
	reconParams.nFrames        =  1;
end

reconParams.writeDicomImage      = 1;              % Set to 1 if writing dicom files
reconParams.dicomImageSeriesDesc = 'Offline_3D';   % No spaces allowed. Will also be
                                                   % used as directory name
reconParams.dicomImageSeriesNum  = 821;

reconParams.cleanupIntermediateFiles = 0; % Set to higher values to remove intermediate files such as
                                          % VOLPET sinograms
                                          % Maximum value is 4, which removes (nearly?) all files.
                                          
%% CORRECTION OPTIONS
% Which corrections (and methods, if options exist)
reconParams.randomsFlag            = 1; % 1: RFS    2: Delays
reconParams.normalizationFlag      = 1;
reconParams.deadtimeFlag           = 2;  % Set to 0 for no deadtime ; 1 for old deadtime ; 2 for dt and crystal pile up correction
                                         % deadtimeFlag needs to be set to 1 for pre rev 6.1 and 7.1 rdf versions
                                         % and 2 for more recent data
reconParams.scatterFlag            = 2;	% Set to 1 for 2DSuperSlices in MBSC, set to 2 for 3DSuperslices 
reconParams.globalScatterCap       = 0; % CT/PET Motion compensation. 0: No scatter tail caps; >0: Global Scale Cap (eg, 1.5)
reconParams.attenuationFlag        = 1; % See "Attenuation source options", below
reconParams.decayFlag              = 1;
reconParams.processPrompts         = 1; % For non-native geometry only.
reconParams.radialRepositionFlag   = 1; % For non-native geometry only.
reconParams.detectorResponseFlag   = 0; % Set to 1 to invoke detector response in reconstruction (native geometry only)
% When to apply corrections
reconParams.randomsCorrFlag        = 2; % randoms correction 0: No correction, 1: Pre correction 2: loop correction
reconParams.scatterCorrFlag        = 2; % scatter correction 0: No correction, 1: Pre correction 2: loop correction
reconParams.acfCorrFlag            = 2; % attenuation correction 0: No correction, 1: Pre correction 2: loop correction
% Attenuation source options (if AC is used, one of these must be selected)
reconParams.CTACSinoFlag           = 0; % Set to use old style CTAC Sinograms (prePIFA)
reconParams.PIFAfromCTFlag         = 1; % Set to 1 to generate PIFAs from CT images (most common)
reconParams.PIFAfromProductFlag    = 0; % Set to 1 to generate PIFAs from product PIFA files (AAAA*_)
%reconParams.CTACconvFile           ='ctacConvScale.cfg' ;  % DST DSTE DRX DVCT 
reconParams.CTACconvFile           ='ctacConvScale_rev5.cfg' ;  % D600 D690 
%% OSEM SETTINGS AND FILTER SETTINGS (less commonly changed)
reconParams.startSubset          = 1;   % Start subset
reconParams.startIteration       = 1;   % Start iteration
reconParams.keepSubsetUpdates    = 0;   % Store intermediate results after each subset
reconParams.keepIterationUpdates = 1;   % Store intermediate results after each iteration

reconParams.norm3dclipvalue      = 10.; % Used in petrecon3d.m (but not petrecon3d_ng.m) for thresholding: 
                                        %    maximum value for efficiencies  (efficiencies should be near 1)
% PSF (a.k.a. SharpIR) parameters
reconParams.detectorResponseAxialFlag   = 1;    % Only used if detectorResponseFlag = 1 
reconParams.detectorResponseAxialFactor = 4; 
reconParams.detectorResponseFile        = 'detectorResponseMatrix.XR.mat';

%% INTERMEDIATE FILE OUTPUT FILENAMES
reconParams.emFilename        = [reconParams.dir 'gnd_tsr.vp'];
reconParams.scatterFilename   = [reconParams.dir 'gnd_s.vp'];
reconParams.scatterFilename3D = [reconParams.dir 'gnd_s3d.vp'];
reconParams.randomsFilename   = [reconParams.dir 'gnd_r.vp'];
reconParams.keyholeFilename   = [reconParams.dir 'keyhole.vp'];
reconParams.acfFilename       = [reconParams.dir 'ctac3d.vp'];
reconParams.multFilename      = [reconParams.dir 'multMatrix.vp'];
reconParams.normProcFilename  = [reconParams.dir 'norm3d.proc.vp'];
reconParams.normdeadFilename  = [reconParams.dir 'normdead.vp'];
reconParams.wcc3dFilename     = [reconParams.dir 'wcc3d'];
reconParams.geoCalFilename    = [reconParams.dir 'geoCal3d'];
reconParams.imOutFilename     = [reconParams.dir 'ir3d'];  %floating point output filename


