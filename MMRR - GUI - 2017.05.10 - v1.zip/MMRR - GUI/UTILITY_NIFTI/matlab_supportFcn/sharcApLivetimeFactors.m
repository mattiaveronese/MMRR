%FILE NAME: sharcApLivetimeFactors.m
%
%ORIGINAL C CODE: Scott Schubert
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: This function should be called once per frame before calling
%  sharcAp3dDeadtime().The output livetime factors from livetimeFactors3d()
%  are then passed to sharcAp3dDeadtime().
%
%--------------------------------------------------------------------------
% PURPOSE: Calculate initial live time product factors and output to
% unitLiveTimeProduct:
%   unitLiveTimeProduct(i,j) =
%  	{ 1 - Kint * unitIntDeadTimeData(i,j) } *
%  	{ 1 - Kmux * sum over k ( unitMuxDeadTimeData( i, k not equal j ) ) } *
%  	{ 1 - Kt * unitIntDeadTimeData(i,j) }
%
%   Sort unitLiveTimeProduct(unit,module) to unitLiveTimeProduct(unit,ring)
%   Sort unitIntDeadTimeData(unit,module) to unitIntDeadTimeData(unit,ring)
%
% Params:   axialUnitsPerModule         Input,
%           radialUnitsPerModule        Input,
%           axialModulesPerSystem       Input,
%           radialModulesPerSystem      Input,
%           intCorrectionConstant       Input,
%           muxCorrectionConstant       Input,
%           timingCorrectionConstant    Input,
%           unitIntDeadTimeData         Input,
%           unitMuxDeadTimeData         Input,
%           outData                     Output,
%
%     Ex: deadTimeData=sharcApLivetimeFactors(axialUnitsPerModule,...
%                      radialUnitsPerModule,axialModulesPerSystem,...
%                      radialModulesPerSystem,intCorrectionConstant,...
%                      muxCorrectionConstant,timingCorrectionConstant,...
%                      unitIntDeadTimeData,unitMuxDeadTimeData);
%--------------------------------------------------------------------------

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

