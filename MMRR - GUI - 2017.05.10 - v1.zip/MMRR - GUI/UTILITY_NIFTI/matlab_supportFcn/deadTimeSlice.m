%FILE NAME: deadTimeSlice.m
%
%ORIGINAL CODE: William Braymer & Peter Crandall
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: Execute 2D Deadtime Slice Calculation   
%
% PURPOSE: Generate deadtime correction for a single slice.
% Params:   ring1               Input, ring number
%           ring2               Input, ring number
%           radialUnitsPerRing  Input, radial units per ring
%           deadTimeCalcBuffer  Input, deatime calculation buffer data
%           xLuts               Input, sinogram crystal coordinate maps x-axis
%           workBuffer          Input, temporal work buffer
%           outBuff             Output,corrected raw data
% 
%     Ex: outBuff = deadTimeSlice( ringNumber - 1, ringNumber, sinoSize,...
%                       radialUnitsPerRing,deadTimeCalcBuffer, xLuts,...
%                       workBuffer1);

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:


% Set pointers to start of deadtime data for each ring */
% ringPtr's are only pointers so they a to be converted into a index to 
% deadTimeCalcBuffer. 
% Original C Code:
% 	ringPtr1 = deadTimeCalcBuffer + ( ring1 * radialUnitsPerRing );
% 	ringPtr2 = deadTimeCalcBuffer + ( ring2 * radialUnitsPerRing );
%
%   ringPtr = are only index that point to the deadtime data 
%
%   disp 'deadTimeSlice'
%   Retrieve data points from deatime data to build sinograms

