% utility function that makes PIFAs (used by petrecon*)
%
% DEVELOPER: Steve Ross, Tim Deller and many others
%
% PURPOSE:  This is an (internal) function used by the petrecon*
% wrappers to generate PIFA files, depending on flags and
% settings in reconParams
% USAGE:
%  reconParams=petrecon_makePIFAs(reconParams);
%
% This function will overwrite reconParams.pifaFilename if
% reconParams.PIFAfromCTFlag or reconParams.PIFAfromProductFlag is
% set. Otherwise, it will set it to reconParams.inputFilename,
% unless pifaFilename existed already.
%
%
% CALLS:
%  CTACproc, sortPIFA

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

