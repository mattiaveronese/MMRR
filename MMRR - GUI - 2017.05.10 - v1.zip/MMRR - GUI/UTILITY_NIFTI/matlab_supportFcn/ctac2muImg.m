%  This function generates a map of linear attenuation coefficients from a 2D CTAC dataset through filtered back-projection
%
%   Syntax:
%       muImg = ctac2muImg(ctac2d, scanner, acqParams, pifa);
%       muImg = ctac2muImg(ctac2d, scanner, acqParams, pifa, xOffset,yOffset, rotation);
%
%   Inputs:
%       ctac2d              -   CTAC sinograms
%                               ctac2d = exp(-mu*x);
%       scanner             -   Structure with scanner parameters
%       acqParams           -   Structure defining projPlane dimension
%       pifa            -       Structure defining PIFA image dimension
%                               optional parameter
%       xOffset             -   offset images along x-axis by xOffset, Units: mm
%       yOffset             -   offset images along y-axis by yOffset, Units: mm
%       rotation            -   The angle of the first projection. This is
%                               an optional parameter, if unspecified it is
%                               set to 0.
%
%   Outputs:
%       muImg               -   3D image set of linear attenuation
%                               co-efficients at 511 KeV in units of 1/mm

% Copyright (c) 2004-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   11/17/2004   Written by RMM
%   Aug/2009   RMM and KT
%                      Fix ramp filter

% If pifa is not passed, recon muImg on 700mm FOV
