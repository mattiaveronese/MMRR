% scanner geometry and sinogram parameters for the XA (a.k.a. Discovery 600) scanner.
% Sets scanner and acqParams structure with default values.

% Copyright (c) 2009-2011 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   30 Apr 2009 Created from KHscanner.m

% Scanner parameters
%====================
