%  convSino2ProjPlanes.m
%
%  This program converts a sinogram into a 3D projection plane
%  by based on inverse SSRB formulation
%
%  Syntax:  
%       projPlane = convSino2ProjPlanes(sinogram,acqParams)
%   
%   Inputs:
%       sinogram    -   sinogram data
%       acqParams   -   Structure defining sinogram/projPlane
%                       dimensions. (See ir3d.m for definition)
%
%   Outputs:
%       projPLane   -   3D projection planes data set

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

