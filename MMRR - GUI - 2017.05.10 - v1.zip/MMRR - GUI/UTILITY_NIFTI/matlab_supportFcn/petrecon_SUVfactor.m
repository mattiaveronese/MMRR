% Compute SUVbm factor from GE Dicom image header
% USAGE:
%   SUVbmFactor=petrecon_SUVfactor(hdr)
% INPUTS:
%   hdr: DICOM header, read with pet-dicom-dict.txt
% OUTPUT:
%  SUVbmFactor: factor to multiply an image reconstructed with the pettoolbox to get SUV units

% Copyright (c) 2008-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   DEVELOPER: Kris Thielemans
%   HISTORY: 


