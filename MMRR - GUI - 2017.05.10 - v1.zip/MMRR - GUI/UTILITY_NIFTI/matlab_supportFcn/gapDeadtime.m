%FILE NAME: gapDeadtime.m
%
%ORIGINAL CODE: William Braymer & Peter Crandall
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: Execute 2D Gap Deadtime Calculation   
%
%-----------------------------------------------------------------------
% PURPOSE: Generate deadtime correction for a single slice.
% Params:   ringNumber          Input, ring number  
%           scale               Input, calculated scale factor
%           sinoSize            Input, sino size
%           radialUnitsPerRing  Input, radial units per ring
%           deadTimeCalcBuffer  Input, deadtime calculation buffer
%           xLuts               Input, sinogram crystal coordinate maps x-axis
%           workBuffer1         Input, work buffer
%           outBuff             Output, corrected raw data
% 
%     Ex: workBuff1=gapDeadtime(ringNumber,weight0,sinoSize,radialUnitsPerRing,
% 					 deadTimeCalcBuffer,xLuts,workBuff1);
%--------------------------------------------------------------------------

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

%   disp 'gapDeadtime'

%   Gap Deadtime =  Scale X ( L1 X R2 + L2 X R1 )

