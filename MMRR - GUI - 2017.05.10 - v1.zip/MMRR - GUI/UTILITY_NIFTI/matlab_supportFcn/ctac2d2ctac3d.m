% FILE NAME: ctac2d2ctac3d.m
% =================================================%
%
%  ctac2d2ctac3d.m
%  This function generates true 3D CTAC from 2D CTAC
%  A filtered back projection image is generated from the 2D CTAC followed
%  by a 3D forward projection operation to generate 3D CTACs
%
%   Syntax:
%       [ctac3d, muImg] = ctac2d2ctac3d(ctac2d, acqParams);
%       [ctac3d, muImg] = ctac2d2ctac3d(ctac2d, acqParams, imParams);
%       [ctac3d, muImg] = ctac2d2ctac3d(ctac2d, acqParams, [], xOffset, yOffset, rotation);
%       [ctac3d, muImg] = ctac2d2ctac3d(ctac2d, acqParams, imParams, xOffset, yOffset, rotation);
%
%   Inputs:
%       muImg               -   3D image set of linear attenuation
%                               co-efficients at 511 KeV in units of 1/mm
%       acqParams           -   Structure defining projPlane dimension
%                               (See ir3d.m for definition)
%       imParams            -   Structure defining image dimension
%                               (See ir3d.m for definition). This is
%                               optional parameter
%       xOffset             -   offset images along x-axis by xOffset, Units: mm
%       yOffset             -   offset images along y-axis by yOffset, Units: mm
%       rotation            -   The angle of the first projection. This is
%                               an optional parameter, if unspecified it is
%                               set to 0.
%
%   Outputs:
%       ctac3d              -   CTAC projection plane
%                               ctac3d = exp(-mu*x);
%       muImg              -    Attenuation map computed from 2D CTAC

% Copyright (c) 2004-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   11/17/2004   Written by RMM

% If imParams is not passed, recon muImg on 700mm FOV
