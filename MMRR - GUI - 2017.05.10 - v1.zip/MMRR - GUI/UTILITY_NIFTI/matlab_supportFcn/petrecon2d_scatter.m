% FILE NAME: petrecon2d_scatter.m
%
% DEVELOPER: Steve Ross
%
% PURPOSE:  This function calls 3d Model Based Scatter routines to generate a 3d 
%	scatter estimate. The function initializes the structure mbscParams based on 
%	settings consistant with the product implementation. Scanner specific parameters 
%	are derived based on rdf.nx (nU). 
%	This code was built off mbsc.m.
%
%	Inputs: sinorr:  radial repositioned sinogram (typically corrected for randoms, dt, norm).
%		pifa:  pifa structure generated from readPIFA.m (requires header only,not data).
%		rdf:   rdf structure generated from readHLRDF
%		acqParams: acqParams structure generated from petrecon_acqParams
%		scanner:  scanner structure genenerated from petrecon_scanner

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:


