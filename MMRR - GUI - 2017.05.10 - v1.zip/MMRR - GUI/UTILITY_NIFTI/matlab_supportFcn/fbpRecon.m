% FILE NAME: fbpRecon.m
%
% Filtered Back-projection Reconstruction
%
%  Written by:
%		Ravindra Manjeshwar
%		GE Corporate Research and Development

% Copyright (c) 2001-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%		03/20/2001	Implemented FBP
%		03/23/2001	Made pixel size in reconstructed image a parameter
%       04/21/2005  Added rotation parameter
%       05/15/2008  Accept window and windowParams as input

