% FILE NAME: invGeoCorrection.m
%
%  This program perfoms inverse radial repositioning of emission sinograms or 
%  3D projection planes. 
%  Implementation based on "Improved Radial Repositioning" C. W Stearns 
%  ASL Technical Report 92-54  
%
%  Syntax:  
%       geoCorrSino = geoCorrection(sino,scanner,acqParams);
%       geoCorrSino = geoCorrection(sino,scanner,acqParams,extrapolateValue);
%   
%   Inputs:
%       sino        -   Sinogram or projection plane before radial
%                       repositioning
%       scanner     -   scanner detector geometry
%       acqParams   -   Structure defining projPlane dimension
%                              (See ir3d.m for definition)
%       extrapolateValue - out of range values that need extrapolation are set to this
%                          value. By default it will be set to NaN
%       rrSamples   -   Number of radial repositioned bins. This is 
%                       optional parameter - if not specified it is computed
%                       (REMOVED)
%
%
%   Outputs:
%       geoCorrSino   - Radial repositioned sinogram or projection plane

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%       TD, 9/6/06 -  Replace structure field names:
%           scanner.ringDia -> scanner.effectiveRingDiameter
%           scanner.numRadBlockXtals -> scanner.radialCrystalsPerBlock
%       TD, 9/6/06 -  rrSamples = size(sino,1); - doesn't need to be
%           calculated
%       CWS, 1/15/07 Removed internal subroutine sinogramRadCoords, modified
%            call to match parameters of external routine.
%       RMM, 1/10/08 Option to reset NaN values to  extrapolateValue
%                    Removed rrSamples

