% a helper function to set default parameters for the detectorResponse modelling
% USAGE
%  reconParams = petrecon_detectorResponseParams(reconParams, scanner);
% INPUT
%  reconParams: usual structure as used by petrecon3d_ng etc
%  scanner:     as returned by e.g. petrecon_scanner (we just use the "name" field here)
% OUTPUT
%  reconParams:  updated with the following defaults:
%   detectorResponseFlag=0;
%   if (~detectorResponseFlag)
%      detectorResponseFile=sprintf('detectorResponseMatrix.%s.mat', scanner.name(2:end));
%      detectorResponseAxialFlag=1;
%      detectorResponseAxialFactor=4;
%   end

% Copyright (c) 2010-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%  Sep2010 Kris Thielemans
%   Created
% CVS Version info: $Revision: 1.2 $, $Date: 2010/10/04 22:14:14 $

