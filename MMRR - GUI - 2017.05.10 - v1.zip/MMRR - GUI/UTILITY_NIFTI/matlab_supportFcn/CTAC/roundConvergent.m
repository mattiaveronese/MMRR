% roundConvergent
%   This tool is created to compute convergent rounding without the use of
%   the fixed-point toolbox.
%   Convergent rounding rounds halves to the nearest even integer.
%
% Input:
%   scalar or matrix numbers
%
% Output:
%   convergent rounded answer
%
% Example:
%   
% >> x = -1.5:0.25:1.5            
% 
% x =
% 
%   Columns 1 through 7
% 
%    -1.5000   -1.2500   -1.0000   -0.7500   -0.5000   -0.2500         0
% 
%   Columns 8 through 13
% 
%     0.2500    0.5000    0.7500    1.0000    1.2500    1.5000
% 
% >> roundedX = roundConvergent(x)
% 
% roundedX =
% 
%     -2    -1    -1    -1     0     0     0     0     0     1     1     1     2
%
%

% Copyright (c) 2010-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   Created by Tim Deller, 05-April-2010

% Find the indices of elements that are rounded in the wrong direction:
