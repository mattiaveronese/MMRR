% makes an attenuation map in the form of a PIFA structure from CT data
%
% FILE NAME: makePIFA.m
%
% DEVELOPER: AL
%
% syntax :
%   PIFA=makePIFA(PETloc,CTDC ,LUT,FWHM_Targ,terse) ;
%
%   makes an attenuation map in the form of a PIFA structure
%   at slice locations corresponding to the PET slice locations
%   in the order given by the PET location order
%   by reading the CT images  listed in CTDC   
%   and using all CT images which overlap the PET slices
%   OPTIONAL PARAMETERS:
%        'acqc'     followed by ACQC axial shift in mm
% 
%   INPUTS:
%           PETloc   PET slice locations
%           CTDC     CT filenames
%           LUT       to convert HU to attenuation
%           FWHM_Targ  FWHM mm of ouput pifa 
%   OUTPUTS:
%        pifa structure with  header info - see code below        
%        pifa.data  contains attenuation map  128x128xnumPETslices 
%       
%       
% Assume all CTs have same kV  and FOV 
%       LUT has already been made by buildLUT
%       dicom dictionary has been set for CT images

% Copyright (c) 2009-2011 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%       15 Dec 2009  CWS added support for acqcS
%       19 Oct 2009 J Lanning  Modified to better match product
%       22 March 2010 A Lonn   Re-orientation according to Chuck
%       7 March 2011  A Lonn Changed precision of CT DICOM rescaling ..
%                   ..  from int16 (as product) to single (more general )  

%  NOTE: if there are no overlapping CT slices at the end of the axial FOV 
%  they will be replicated from the nearest CT 
%  IF acqcS is non-zero AND the gap is less than acqmm 
%  Otherwise they will be set to the first value in the LUT
