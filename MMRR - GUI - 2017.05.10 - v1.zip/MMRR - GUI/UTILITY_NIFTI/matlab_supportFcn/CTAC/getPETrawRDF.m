% FILE NAME: getPETrawRDF.m
%
% SYNTAX :PETloc=getPETrawRDF(PETdir, petfilemask) ;
% USEAGE :PETloc=getPETrawRDF('.', 'rdf.*') ;          
%
%  This function gets the PET slice location information
%  from the given PET Raw  RDF file
%      
%  INPUTS: 
%           PETdir     :Path to directory containing PET raw
%           petfilemask: Filename mask to list PET raw in above
% 
%   OUTPUTS:
%         PETloc structure containing  - for each PET raw -
%             rawname: PET raw file name with  no directory path
%             numslices: number of slices
%          start_frame: signed Patient location of start frame
%   frame_of_reference: 64 char locaiton UID
%                  loc: PET slice locations [1 x nZ single]
%         

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%        DEVELOPER: AL
%        20-Apr-2010 - TD - Modifications for 10x10

