% FILE NAME: getPETrawDICOM.m
%
% DEVELOPER: AL
% 
% ===============================================================
%
% SYNTAX :PETloc=getPETrawDICOM(PETdir, petfilemask) ;
% USEAGE :PETloc=getPETrawDICOM('.', '*RPDC*') ;          
%         
%
%  This function gets the PET slice location information
%  from the given PET DICOM Raw file
%      
%  INPUTS: 
%           PETdir     :Path to directory containing PET DICOM raw
%           petfilemask: Filename mask to list PET raw in above
%                     
%   OUTPUTS:
%         PETloc structure containing  - for each PET raw -
%             rawname: PET raw file name with  no directory path
%             numslices: typically 47
%          start_frame: signed Patient location of start frame
%   frame_of_reference: 64 char locaiton UID
%                  loc: PET slice locations [1x47 single]
%         
%        Rev 2 AL 

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%    01 Dec 2008, TWD:
%       - Replaced the Private field (0021,1001) with its newly updated Dicom
%       tag names in pet-dicom-dict.txt, which is TypeOfRawData

