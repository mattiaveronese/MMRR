% FILE NAME: buildLUT.m
%
% syntax :
%          LUTparams = buildLUT(CTKV,CTCON,ctacconvscalefile, %s )
%
%  This function reads in the CTAC conversion parameters 
%      
%   INPUTS:
%           CTKV    CT KVp, 80 100 120 140 
%           CTCON   CT Contrast ==1 ; 0 non contrast
%           ctacconvscalefile  filename for ctacConvScale.cfg
%          contains Threshold, Intercept and Slope for for numseg
%   OUTPUTS:
%         returns LUTparams (3 , numseg)   containg 
%         Threshold, Intercept and Slope for numseg  
%       LUT.floor= LUTparams(1,1) ;
%       LUT.ceil =  LUTparams(1,numSeg ) ;
%       LUTlength= LUT.ceil  - LUT.floor ;
%       LUT.table=zeros(1,LUTlength,'single') loaded with LUT
%       
%       CTAC factors are  per cm 
%       output PIFA has attenuation per mm
%     

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% DEVELOPER: AL
%     02/20/07 - Fixed a bug for 80 kV scans


