% FILE NAME: CTACproc.m
%
% DEVELOPER: AL
% =============================================================
%
%  This function makes a PIFA file  for each raw PET matching the mask
%   Using all the CT images which overlap the PET slice locations
%
% 	SYNTAX :
%err=CTACproc(petrawdir, petfilemask,CTACdir,CTmask,PIFAdir,varargin)
%   EXAMPLES
%       make PIFA from raw rdf with all files in current dir
%       err=CTACproc('.','rdf*','.','*CTDC*','.')
%       make PIFA  from raw DICOM   note you need the 'dicom' flag   
%       err=CTACproc('.','*RPDC*','.','*CTDC*','.','dicom')    
%      
%   INPUTS:     
%      petrawdir path to PET RAW 
%      petfilemask   mask to list PET raw in above
%      CTACdir   path to CT images 
%      CTmask   mask to list CT images in  above
%      PIFAdir  path to pifa directory for output
%
%   OUTPUTS:
%          err returns number of elments in last pifa 128*128*47
%          PIFA file  is written to pifa directory
%          PIFA filename is <petfilename>.pifa
%         can be read back with readPIFA.m
%   OPTIONAL PARAMETERS:
%        'dicom'    PET is DICOM raw file - default is rdf  
%        'ctacfilt' followed by a string numeric fraction sets the 
%                   FWHM in mm of the final pifa
%        'acqc'     followed by ACQC axial shift in mm
%        'convfile' followed by name of ctac conversion file
%   ASSUMPTIONS:
%       Assume all CTs have same kV  and FOV
%   PRE-REQUISITES:
%       the ctacscale file used in buildLUT must exist on the MATLAB path 
%       the PET and CT DICOM dictionaries must exist on the MATLAB path

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%       AL 27Sep2010 Accept CTAC conversion filename from params 
%        or use default 'ctacConvScale.cfg'

% set defaults
