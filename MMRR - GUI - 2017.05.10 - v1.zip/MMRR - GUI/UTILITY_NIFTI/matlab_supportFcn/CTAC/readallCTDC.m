% read DICOM header info from CT image files
%  syntax: CTDC = readCTDC( CTACdir, CTmask, terse, readextrainfo )
%
%   INPUTS
%    CTACdir : directory where the CT images are 
%    CTmask : typically '*CTDC*'
%    terse : determines print-out of some diagnostics. Set to 0 for
%            no print-out, 3 for most.
%    readextrainfo : optional argument, set to 0 or 1 as a bool
%            value (defaults to 0). If 1, will store extra timing
%            info in the structure. Mainly useful for CINE-CT.
%
%   OUTPUT
%       CTDC   :   
%          Structure with header info, sorted in Slice Location order
%          (and then MidScanTime if readextrainfo==1)
%    CALLS : 
%           dicominfo

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   AL - Created
%   TD - Mar 05 2007 -
%      Cleaned up a couple un-used lines
%      Called dicominfo with dictionary reference (because this errors in
%          some versions of Matlab and is unneccesary)
%   KT - July 18 2007
%      Added error checking to skip files that are not dicom
%      Added readextrainfo for CINE-CT processing
%      Removed 'clear' statements as they are unnecessary for local
%      variables

