% FILE NAME: petrecon3d_scatter.m
%
% DEVELOPER: Steve Ross
%
% PURPOSE:  This function calls 3d Model Based Scatter routines to generate a 3d
%	scatter estimate. The function initializes the structure mbscParams based on
%	settings consistant with the product implementation. Scanner specific parameters
%	are derived based on rdf.nx (nU).
%	This code was built off mbsc.m.
%
%	Inputs: 
%       emis3drr:   radial repositioned sinogram (typically corrected for randoms, dt, norm).
%       ctac3d:     radially repositioned 3D CTAC
%       pifa:       pifa structure generated from readPIFA.m (requires header only,not data).
%       geoCal:     geoCal correction factors (329x8 for DSTE) 
%       rdf:        rdf structure generated from readHLRDF
%       acqParams:  acqParams structure generated from petrecon_acqParams
%       scanner:    scanner structure genenerated from petrecon_scanner
%       globalScatterCap: Maximum value for scatter tail scaling
%

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   06/19/2008  RMM     
%           (1) Added geoCalFactors as input parameter. The estimated
%               scatter sinograms are now multiplied by the mean, radially
%               repositioned geoCal correction factors prior to tail-scaling
%           (2) Added  mbscParams.fitType to allow for tail-scaling or
%               least-squares (LS) tail-fitting, set default to LS-tail-fitting
%           (3) Set mbscParams.isRb from rdf structure to handle 
%               LS-tail-fitting for Rb studies
%           (4) Added mbscParams.emisImgFilterType = 'hanning' 
%               and  mbscParams.emisImgFilterFWHM = 18.0
%               to smooth emission images for noise control
%           (5) Accept emisMask from calcSinoTail3d.m and multiply 
%               emission image with emisMask (to zero activity outside the 
%               body) prior to SSS
%           (6) Sub-sampling emission image in all 3 dimensions
%               128 x 128 x 47)--> (32 x 32 x 4) and passing dsEmisImg to 
%               CalcScatterSino3D()
%   06/20/2008  RMM     
%           (1) Build dsAcqParams and dsImParams here and pass to CalcScatterSino3D()
%               changed call to CalcScatterSino3D()
%           (2) Accept downSampled Scatter sinogram from CalcScatterSino3D()
%               and upsample here
%           (3) Convolution model to generate multiples moved here from
%               CalcScatterSino3D()
%   02/23/2009  CWS
%           Modified "rubidium correction" to include other "dirty isotopes Br-76, I-122 and
%           I-124 per FCTge44708
%   11/19/2009  Hua Q - Added global scaling calculations
%   12/01/2009  TD - Added globalScatterCap parameter to be passed to
%               lsTailFitScatter2emis3d
%   12/09/2009  KT - changed calling sequence to lsTailFitScatter2emis3d to pass mbscParams
%   12/15/2009  CWS - Added deadtime-dependent changes to deff term.
%   03/03/2010  CWS - Moved parameter setup to petrecon3d_scatterParams.m
%   09/23/2010  CWS - Modified to use Hua Qian's  Siddon & scatter C++ routines

%% MBSC Parameters
