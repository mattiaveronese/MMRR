% FILE NAME: dsSinoUpsample3d.m
%
% DEVELOPER: Ravi Manjeshwar
%
% PURPOSE:  This function upsamples the scatter estimate from CalcScatterSino3D()
% to full resolution in either 2D or in 3D
%
% INPUTS: 
%       dsSino:         Estimated scatter sinogram
%       scanner:        scanner structure genenerated from petrecon_scanner
%       acqParams:      acqParams structure genenerated from petrecon_acqParams
%		dsAcqParams:    dsAcqParams structure generated in petrecon3d_scatter3d
%                       contains parameters for down-sampled sinograms
%		dsImParams:     dsImParams structure generated in petrecon3d_scatter3d
%                       contains parameters for down-sampled image
%       total_slices:	Number of slices to upsample. Typically only 2D 
%                       upsampling is performed on all but the last iteration 
%                       of MBSC
%       rotate:         z-axis roll obtained from rdf header
%
% OUTPUTS: 
%       usSino:         upsampled scatter sinogram

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   2005        RMM     First written
%  Edited 20Feb2007 cws to clean up "odd" and "even" data specifications
%  Edited 04Feb2008 cws to convert all iterations except the last to 1D
%                        interpolation along in-plane estimates only.
%  06/21/2008   RMM     Removed redundant input parameters, passing in 
%                       dsAcqParams and dsImParams 
%  08/18/2008   RMM     changed variable names z_Us11, z_Ds to usZpos and
%                       dsZpos, respectively

% Set up for Upsample in axial direction
