% FILE NAME: lsTailFitScatter2emis3d.m
%
% DEVELOPER: Ravi Manjeshwar
%
% PURPOSE:  This function scales estimated scatter sinogram based on a
% least-squares fit to the tails of the emission data
%
% INPUTS: 
%    scatter3d:      Estimated scatter sinogram
%    emis3d:         3D emission sinograms
%    sinoTails:      Left and right indices of sinogram tails for each
%                    projection 
%                    Dimensions: (2 acqParams.nV acqParams.nPhi)
%    acqParams:      acqParams structure generated from petrecon_acqParams
%    total_slices:   Number of slices to perform the tail-fit on.
%                    Typically only 2D tail fit is performed on all but 
%                    the last iteration of MBSC
%    mbscParams:     structure with the following fields
%       skipSupport:    Number of first and last radial bins to ignore from
%                       the tails. 
%       isRb:           To handle 3rd Gamma isotopes, if 
%                       isRb=1, LS tail-fit performed with y = Ax + B.
%                       isRb=0, LS tail-fit performed with y = Ax. (FDG)
%       regularize:     Logical option for tail filtering (regularization)
%       weight:         Center weight in 3-point-averager for tail filtering
%       scaleMaxThres:  Maximum value for scatter tail scaling (optional)
%       scaleMinThres:  Minimum value for scatter tail scaling (optional)
%
% OUTPUTS: 
%       scatter3d:      Tail-scaled scatter sinogram

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   2006        RMM     First written
%   06/19/2008  SDW/RMM 
%                       (1) Added isRb as input parameter to handle 3rd gamma
%                       (2) Implemented (Y = Ax+B) fit based on SDW implementation
%   06/19/2008  RMM     Added documentation 
%   06/28/2008  RMM     Added the option to filter tailscale factors to regularize
%                       This was available (with a different implementation)
%                       for tail-scaling
%   12/01/2009  TD      Added globalScatterCap (optional input)
%   21/09/2009  KT      Pass parameters as a structure, and add minimum threshold
%                       Regularize also when processing 2D scale factors
%   01/06/2010  TD      Modified global scatter cap to also apply to the A
%                       values for dirty tracers. (Previously, the global
%                       scatter cap only applied to clean tracers.)
%   01/07/2010  TD      Same change as yesterday for mbscParams.scaleMinThres

