% FILE NAME: calcSinoTails3d.m
%
% DEVELOPER: Ravi Manjeshwar
%
% PURPOSE:  This function estimates the body contour in the attenuation
% image and determines the correcponding left and right indices of sinogram 
% tails for each CTAC projection 
%
% INPUTS: 
%       ctac3d:         Estimated scatter sinogram
%		muImg:          3D emission sinograms
%       scanner:        scanner structure genenerated from petrecon_scanner
%       acqParams:      acqParams structure genenerated from petrecon_acqParams
%       pifa:           pifa structure generated from readPIFA.m (requires
%                       header only,not data).
%       mbscParams:     mbscParams structure (parameters for MBSC) generated
%                       in petrecon3d_scatter3d
%       rdf:            rdf structure generated from readHLRDF
%       
% OUTPUTS: 
%       sinoTails:      Left and right indices of sinogram tails for each
%                       projection 
%                       Dimensions: (2 acqParams.nV acqParams.nPhi)
%       mask_r:         Binary volume with patient mask
%

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   2005        RMM     First written
%   05/16/2008  RMM     Pass binary mask image as output parameter
%   12/15/2009  RMM     Add RT table rods removal algorithm
%   01/14/2010  TWD     Modify RT table rods removal algorithm to use
%                       the 2D bwlabel function rather than 3D bwlabeln.
%                       Also, slightly widen the pixel count window.
%

