%
% THIS FILE HAS BEEN MADE OBSOLETE BY THE DEVELOPMENT OF CalcSingleScatter3D.m, WHICH
% CALLS C++ ROUTINES FOR SIDDON PROJECTORS AND THE SCATTER ENGINE.  THIS CODE MATCHES
% THE OUTPUT OF CalcSingleScatter3D.m v1.3 ON 25 FEB 2011, BUT THERE IS NO GUARANTEE
% IT WILL BE MAINTAINED BEYOND THAT DATE.


% FILE NAME: CalcScatterSino3D.m
%
% DEVELOPER: Maria Iatrou / Ravi Manjeshwar
%
% PURPOSE:  This function runs the core of the 3D single scatter
% simulation.  It accepts down emission and attenuation images and returns
% estimated scatter sinograms
%
% NOTE: As of 04Feb2008, only the in-plane (pink and blue photons in the same
%   superslice) calculations are required for all scatter iterations before
%   the last one.  This code, however, still performs the full 3D scatter
%   estimate for all pink-blue superslice permutations in every iteration
%   (the pink photon superslice number is vectorized into the code).  As such,
%   while the ultimate scatter estimate should match product, certain
%   intermediate variables will not match their counterparts in the product
%   code.
%
%	Inputs: 
%       dsEmisImg:      Down-sampled emission image
%		dsMuImg:        Down-sampled mu (attenuation co-efficients) image
%       dsMuImgPaths:   Look-up table of line integrals from each
%                       down-sampled mu image voxel to each detector in the
%                       down-sampled ring (4 x 64 x 32 x 32 x 4)
%       scanner:        scanner structure genenerated from petrecon_scanner
%       mbscParams:     mbscParams structure (parameters for MBSC) generated
%                       in petrecon3d_scatter3d
%		dsAcqParams:    dsAcqParams structure generated in petrecon3d_scatter3d
%                       contains parameters for down-sampled sinograms
%		dsImParams:     dsImParams structure generated in petrecon3d_scatter3d
%                       contains parameters for down-sampled image
%
%

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%  2006         First written
%  12 Feb 2007  CWS used "which" to pick up DEff file from MATALB  path.
%  23 Feb 2007  RMM fixed bug that resulted in scatter sinograms
%                   being shifted by one row
%  26 Feb 2007  RMM made changes to conform to universal PET conventions
%  21 May 2008  MI/RMM  
%       (1) changes to include solid angle from emission voxel to unscattered 
%           detector and beam divergence (fractional emission counts that are 
%           incident on scatter voxel and detected in the unscattered detector. 
%           Solid Angle and beam divergence added as R_square_scatter_d1
%       (2) Renamed R2_square to R_square_scatter_d2
%       (3) Cleaned up processing sequence to minimize the number of permute
%           operations
%   19 Jun 2008 RMM changed input from emisImg (128,128,4) to dsEmisImg (32,32,4)
%   20 Jun 2008 RMM 
%       (1) moved upsampling of single scatter sinograms to petrecon3d_scatter3d
%       (2) accept dsAcqParams and dsImParams as input parameters instead
%           of building it
%   14 Sep 2009 CWS
%       Added count-rate-dependent dEff support

