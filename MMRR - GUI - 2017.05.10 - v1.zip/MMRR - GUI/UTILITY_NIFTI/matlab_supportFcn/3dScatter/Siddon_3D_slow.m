% ==================================================================%
% Copyright (c) 2005 General Electric Company. All rights reserved.
%
% This code is only made available outside the General Electric Company
% pursuant to a signed Research Agreement between the Company and the
% institution to which the code is made available. The code and all
% derivative works thereof are subject to the non-disclosure terms of
% said Research Agreement.
%
% FILE NAME: Siddon_3d.m
% History Written by Maria Iatrou 2006 to be used in 3D scatter estimation
%
% 21st Feb, 2007    RMM  Modified Siddon to work with transposed images
%                        (Owing to MATLAB v IDL discrepancies, old version
%                         was working with image in 'IJ' space as opposed
%                         to 'XY' space
% 20th June 2008   RMM    Accepting dsAcqParams and dsImParams as input
%                         instead of building it 

% Setup downsampled detector geometry
