% FILE NAME: petrecon3d_scatterParams.m
%
% DEVELOPER: Chuck Stearns
%
% PURPOSE:  This function sets up[ structures used by the MBSC
% implementation in nonTOF or TOF reconstructions.
%
%	Inputs: 
%       pifa:       pifa structure generated from readPIFA.m (requires header only,not data).
%       rdf:        rdf structure generated from readHLRDF
%       acqParams:  acqParams structure generated from petrecon_acqParams
%       scanner:    scanner structure genenerated from petrecon_scanner
%       globalScatterCap: Maximum value for scatter tail scaling

% Copyright (c) 2010-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   03/03/2010  CWS     
%           Built from petrecon3d_scatter3d

%% MBSC Parameters
