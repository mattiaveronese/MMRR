% FILE NAME: filterScatterTailFactors.m
%
% DEVELOPER: Ravi Manjeshwar
%
% PURPOSE:  This function filters the scatter tail scale factors
%
% INPUTS:
%       scatTailFactors:    scatter tail scale factors
%		acqParams:          acqParams structure generated from petrecon_acqParams
%       weight:             central weight of the center weighted 3 point averager
%
% OUTPUTS:
%       filScatTailFactors: filtered scatter tail scale factors
%

% Copyright (c) 2008-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   06/28/2008  RMM     First written - borrowed heavily from calcEmisTailCounts
%   11/24/2010  TWD     Modified for limited axial acceptance

