% FILE NAME: CalcSingleScatter3D.m
%
% DEVELOPER:  Hua Qian
%
% PURPOSE:  This is a wrapper function for the core 3D single scatter 
% simulation.  It accepts down emission and attenuation images and returns
% estimated scatter sinograms. This function is an alternative to the
% CalcScatterSino3D.m 
%
%	Inputs: 
%       dsEmisImg:      Down-sampled emission image
%		dsMuImg:        Down-sampled mu (attenuation co-efficients) image
%       dsMuImgPaths:   Look-up table of line integrals from each
%                       down-sampled mu image voxel to each detector in the
%                       down-sampled ring (4 x 64 x 32 x 32 x 4)
%       scanner:        scanner structure genenerated from petrecon_scanner
%       mbscParams:     mbscParams structure (parameters for MBSC) generated
%                       in petrecon3d_scatter3d
%		dsAcqParams:    dsAcqParams structure generated in petrecon3d_scatter3d
%                       contains parameters for down-sampled sinograms
%		dsImParams:     dsImParams structure generated in petrecon3d_scatter3d
%                       contains parameters for down-sampled image
%       DetEffLUT:      detector energy efficiency look up table (412 x 41)
%                       with 412 energy bins and 41 Phi bins.
%
%    Output:
%       dsSingleScatSino A down-sampled scatter sinogram in (Z1,u,phi,Z2)
%                        format

% Copyright (c) 2010-2011 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%  26 Feb 2010 HQ 
%  21 Feb 2011 CWS - added provision for offset of image stack (for OOF)

