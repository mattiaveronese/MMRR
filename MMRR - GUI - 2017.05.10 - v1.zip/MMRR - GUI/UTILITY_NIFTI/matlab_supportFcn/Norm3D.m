%FILE NAME: Norm3D.m
%
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: Execute Norm correction in 3D   
%-----------------------------------------------------------------------
% PURPOSE: Execute 3D norm correction in pre-norm 3D raw data..
% Params:   inBuff          Input,  
%           geo             Input,  
%           xtals           Input,   
%           timingwindow    Input, nanoSeconds
%           outBuff         Output, 
%
%
%-------------------------------------------------------------------------%
% VARIABLE CORRELATION BETWEEN MATLAB AND C CODE
%-------------------------------------------------------------------------%
% sharcAp3dNormalization(
% pCorr,                                                *inBuff, /* Data to be normalized */
% m_pParamStruct->rawData.number_u,                     nU, /* Size of Udimension */
% m_pParamStruct->rawData.number_v_theta,               nVTheta,	/* Size of combined v theta */
% uiPhiIndex,                                           phi,	/* current projection being processd */
% pNormEfficiencyBuff,                                  *xstlEffBuff,	/*crystal effciency */
% m_pParamStruct->crystalsPerRing,                      nX, /* crystals around the ring */
% m_pParamStruct->axialCrystals,                        nZ, /* crystals axially through ring */
% m_pNormGeomFactors,                                   *geomBuff, /*geometry factors */
% m_pParamStruct->rawData.number_u,                     nR, /* dim 1 of geometry factors */
% 1,           /* Geom factors is 249 * 1 * 6 */        nTheta, /* dim 2 geometry factors */ /* 1 or 553 */
% apCfg.norm3dGeometryPeriod,                           period,
% m_pParamStruct->crystalsPerRing,                      nRadialCrystals
%  (long *)m_ppDeadtimeWorkBuff[uiBufferIndex] );       *scratchBuff
%-------------------------------------------------------------------------%

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

