% scanner geometry and sinogram parameters for the XR (a.k.a. Discovery 690) scanner.
% Sets scanner and acqParams structure with default values.

% Copyright (c) 2006-2011 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   21/07/2006   Written by RMM
%   26/02/2007   Updated by CWS to reflect KH performance


% Scanner parameters
%====================
