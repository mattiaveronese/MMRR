%FILE NAME: Deadtime3D.m
%
%ORIGINAL CODE: William Braymer & Peter Crandall
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: This function applies the 3D deadtime correction to a single
%  projection plane of data.  This function implements equations (6)
%  and (7) of "3D Deadtime: Algorithm Report".
%
% PURPOSE: Generate deadtime correction for a single slice.
% Params:   sinoIn          Input, raw data pre deadtime, vector format ([nx*ny,1])
%	    phi	            Input, index number of phi angle (need to decrement by 1)
%           header          Input, header information
%           configuration   Input, system configuration
%           deadTimeData    Input, deatime information from exterior
%                                  functions, sharcApLivetimeFactors3d
%                                  (unitLiveTimeProduct,unitIntDeadTimeData)
%           xLuts           Input, sinogram crystal coordinate maps
%           zLuts           Input, array containing ring number of 1st/2nd
%                                  detector that contributes to (u,v)
%                                  (created by createZLuts())
%           sinoOut         Output,corrected raw data
%
%     Ex: sinoOut=Deadtime3D(sinoIn,header,[],deadTimeData,xLuts,zLuts);

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   02/21/07 - Tim Deller
%              a) un-hardcoded the length of workBuff from 1014755 to
%                  (SIZEOF_UVBLOCKLUT1+SIZEOF_UVBLOCKLUT2+SIZEOF_INDEXUV+SIZEOF_
%                  LTPILEUPUV+SIZEOF_LTPILEUPUV)/4
%              b) commented-out (with 5 percent signs) lines and variables that
%                   were never used.
%              c) adjusted indentations for the file
%                   NOTE: diff -B -b --ignore-all-space --ignore-blank-lines
%                   will show differences ignoring whitespace, etc.
%
%-----------------------------------------------------------------------

%-------------------------------------------------------------------------%
% VARIABLE CORRELATION BETWEEN MATLAB AND C CODE
%-------------------------------------------------------------------------%

%Decrement phi by 1 (code was based off C)
