% compute Gaussian kernel for 2D convolution
% FILE NAME: gaussianKernel2D.m
%
% DEVELOPER: Kris Thielemans
%
% PURPOSE:  This function computes a 2D Gaussian kernel (normalized to 1). It
% gives identical results to 
%   kernel=fspecial('gaussian',kernelSize,sigma);
% but doesn't require the Image Processing Toolbox
%	
% USAGE:
%   kernel=gaussianKernel2D(kernelSize, sigma);
% INPUTS:
%   kernelSize: either a vector giving x and y size, or a scalar, in which case x and y size are set equal
%   sigma: either a vector giving x and y sigma, or a scalar, in which case x and y sigma are set equal

% Copyright (c) 2008-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:


% TEST
% kernelSize=[5,70];sigma=5.5;
% max(max(gaussianKernel2D(kernelSize,[sigma,sigma])-fspecial('gaussian',kernelSize,sigma)))<1e-5



