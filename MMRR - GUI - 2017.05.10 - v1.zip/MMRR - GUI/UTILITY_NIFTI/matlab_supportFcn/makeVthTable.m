% vthtable = makeVthTable(rows)
%
% Create a VTheta-to-crystal-row translation table for a GE PET scanner.
%
% Input:
%   rows      Number of crystal rows (24 for Discovery family)
%
% Output:
%   vthtable  Nvth-by-2 array of crystal indices corresponding to each
%                 row of the projection plane set (Nvth=rows^2-(rows-1)).
%
% Notes:
%    1. The two output columns correspond to the "low" and "high"
%       crystal address (or "little" and "big") for most of the data set.
%    2. The input and output values are suitable for MATLAB computations,
%       meaning that the input rows are numbered beginning with 1, and the
%       crystal values are also numbered from 1 through "rows".
%
% See "GE PET Image and Sinogram Coordinates" report for more details on
% the crystal translation algorithm.

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:


