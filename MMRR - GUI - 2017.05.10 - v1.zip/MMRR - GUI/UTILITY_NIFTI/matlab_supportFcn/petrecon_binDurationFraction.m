% find the fraction of the acquisition time in the current gate from an RDF header
% This computes accumBinDuration/frameDuration with a work-around for ungated data 
% where the current system does not fill in accumBinDuration.
% Author: Kris Thielemans

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

