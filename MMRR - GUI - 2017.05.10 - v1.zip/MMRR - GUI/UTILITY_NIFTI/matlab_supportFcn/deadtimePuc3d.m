% FILE NAME: deadtimePuc3d.m
%
% DEVELOPER: Albert Lonn
%
% PURPOSE:  
% This module performs the function of the previous
% sharcApLivetimeFactors3d 
% in computing the live time factors 
% and also the  deadtime3d in computing the 3D deadtime correction
% in addition to the previous correction factors, this include 
% crystal-based pile up correction

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% 22 May 08   AL  Added redundant deadtime factors for future use.
%  2 Jul 08   AL  Add coincidence loss; future came earlier than expected

