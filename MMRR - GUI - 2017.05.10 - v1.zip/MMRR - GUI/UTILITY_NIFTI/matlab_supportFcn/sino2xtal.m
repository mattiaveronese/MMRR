%FILE NAME: sino2xtal.m
%
%DEVELOPER: Chuck Stearns   27 Feb 1992
%
%PURPOSE: Compute crystal indices (returned in 2-element
% 	integer array) for the (r,th) location in the sinogram.  
%
%  NOTE:Results are given on the range [0,Nx-1], per the standard
%       numbering convention for crystals, meaning that a user must
%       add "1" before using this as an index into a MATLAB array.
%
% 	Chuck's standard disclaimer: This program was written to support my 
% 	research needs, and not as product code.  Therefore, while I have some 
% 	confidence that it performs its intended function, all permutations of 
% 	options and error conditions have NOT rigorously tested.  The program
% 	is available within GEMS on an "as is" basis.
%
%                                             numbering convention.
% Params:   r               Input,
%           th              Input,
%           sinogram        Input,
%           x               Output,   

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%       04/20/06    Luis E. Jimenez         Adapt code to work in matlab
%       10/19/06    Chuck Stearns           Changed code to conform to [0,Nx-1]

