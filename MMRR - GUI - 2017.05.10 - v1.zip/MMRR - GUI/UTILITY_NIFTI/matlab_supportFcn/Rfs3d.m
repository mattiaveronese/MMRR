%FILE NAME: Rfs3d.m
%
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: Execute random correction from singles in 3D   
%
%-----------------------------------------------------------------------
% PURPOSE: To perform Randoms From Singles (RFS) calculation.
% 
%                      Adv      RW  Lite   HRS
% elements per row     283     249   259   367
% 3D sinograms       265/307   553   553   553
% transaxial angles    336     210   192   315
% detector rings        18      24    24    24
%
% Params:   singlesFile     Input, filename that contains singles data
%                              (might be empty)
%           twoTau          Input, calculated timing window (nanoseconds)
%           duration        Input, frame duration (seconds)
%           singles         Input, variable that contain singles data
%           numberR         R-dimension size of 3D sinogram
%           numberVth       Theta-dimension size of 3D sinogram
%           numberPhi       Phi-dimension size of 3D sinogram
%           numberRings     Number of crystal rings
%           directonly      Input, 
%           randoms         Output, 
%
% Note: Either "singlesFile" or "singles" should be empty:  []
%----------------------------------------------------------------------

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%  10/19/2006   Chuck Stearns   Modified call to sino2xtal to
%                               account for change in its output
%                               conventions.
%  12/29/2008   Tim Deller      Changed the indexing method for speed
%                               improvements (from 25 sec to 1.9 sec for DSTE)

