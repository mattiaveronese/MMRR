% FILE NAME: tof_gui.m
%
% DEVELOPER: Tim Deller
%
%
% PURPOSE:
% This function sets up the GUI for the Matlab reconstruction processing and
% returns the reconstruction parameters.
%
% INPUT:  a) OPTIONAL: reconParams - (partially initialized - this code will
%            modify the reconParams structure to add or change the settings
%            affected by the GUI)
%
% OUTPUT: reconParams structure
%

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History: GUI developed for the Mayo TOF concept car.
%           12/21/2006 - TD - Initial creation
%           01/22/2007 - TD - Initial CVS commit
%           02/01/2007 - TD - Added Unlist time radio buttons
%           02/01/2007 - TD - Added panels and grouped the GUI accordingly;
%                             i.e., added the uipanel commands.
%           02/19/2007 - TD - Added option to use only a portion of list data


% The code is divided into several major portions, each denoted in the code
% below. The overview is:
%
% Part I -
% Set up gui. This includes creating the figure, creating all of the
% interface controls, and assigning default values.
%
% Part II -
% Set up the callbacks to do error checking and to modify other fields when
% necessary (used only to modify the post filter value).
%
% Part III -
% Create the "Submit" callback. This callback has three parts:
%   a) Double-check to make sure that the inputs are valid.
%   b) Extract all information into a structure from the GUI (done
%      simultaneously with (a))
%   c) Call the reconstruction with the parameters defined in the GUI.
%

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Part I
% Set up gui. This includes creating the figure, creating all of the
% interface controls, and assigning default values.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

