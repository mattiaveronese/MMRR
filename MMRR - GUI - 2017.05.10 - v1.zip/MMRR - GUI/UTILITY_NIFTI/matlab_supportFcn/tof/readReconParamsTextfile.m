% This function reads the reconParams file that was output by the TOF processing
% and re-creates the reconParams struct.
%
% IF YOU ARE GETTING ERRORS: This is probably because the data type is
% incorrect. The reconParams text file prints as plain text for all fields. To
% regain the original datatype (numeric versus char), this function simply tests
% for compatibility with str2num. There is a possibility that this will not work
% correctly, and it could create an error down the line. (For example, if the
% dicomImageSeriesDesc happens to only be a number.) In this case, I'd recommend
% hard-coding the desired datatype for each field individually at the end of
% this function.
%
% Example usage:
%  reconParams = readReconParamsTextfile('/media/disk-1/karen/2007-06-12_tofrecons/reconParams')

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% Written by:
%  Tim Deller, 07/12/2007
% Edited 24 April 2008 to add/replace  values to an existing structure

