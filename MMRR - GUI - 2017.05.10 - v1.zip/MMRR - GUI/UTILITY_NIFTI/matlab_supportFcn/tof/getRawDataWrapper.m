% FILE NAME: getRawDataWrapper.m
%
% PURPOSE:
% This function sets up the call to retrieve the raw data from the host
%
% INPUTS:  data_dir - should be reconParams.dir
%          ip_address - ip address or hostname of the console
%          perl_path - path of data transfer Perl scripts
%
% OUTPUT:  status - output of data transfer script

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% DEVELOPER: Tim Deller
%           01/22/2007 - Initial CVS commit
%     2007-Feb-27 Major overhaul of code (TD)

% set defaults for no input parameters
