function reconImg=petrecon_tof(varargin)
% FILE NAME: petrecon_tof.m
%
%
% PURPOSE:  This is the main wrapper program for 3D TOF reconstruction.
%
% INPUTS:  By default, the script will run in "Mayo Mode" for use with the
% concept car. Several parameters may be modified.
%
% HELP:
%     For help contents, call:
%         petrecon_tof('-help')
%

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% DEVELOPER: Tim Deller
%            Based on non-TOF code from Steve Ross
% MODIFICATIONS (Highlights--see OpenGE for full details):
%     2007-Jan-22 Initial commit (CTAC processing and scatter not yet complete)
%     2007-Feb-19 Added variety of input parameter functionality
%     2007-Mar-18 RMM  Calls to petrecon3d_tofScatter3d.m
%     2007-Mar-26 RMM  Correct for singles rate for partially unlisted events
%                       based on decay rate of the radio-isotope. This is the first
%                       order correction. A second order correction based on the
%                       temporally varying deadtime of the scanner needs to be
%                       applied
%     2007-Apr-02 RMM   Proper handling of unlist start and unlist end times
%     2007-Apr-19 CWS  Added 'skip_rdf_write' option, and some other support
%                       for PC MATLAB operation (Linux-compiled C routines unavailable)
%     2007-July   KL   Added several options for command line input.
%     2007-Sep-27 CWS  Added "add_unlist_options" as a pass-through for new
%                         options for kh2vptof.c (like gating).
%     2008-June-21 RMM  
%                       (1) Save geocal factors for use inside petrecon3d_tofScatter3d.m
%                       (2) Change output of petrecon3d_tofScatter3d.m from
%                           just the scatter scale factors to a structure
%                           mbscParams4recon that includes the scatter scale
%                           factors and other parameters required by tof_osem
%                       (3) Change in call line to tof_osem to accept
%                           mbscParams4recon
%                       (4) 
%     2008-July-22 RMM  Storing nontofScatter3d soon after petrecon3d_tofScatter3d
%                       for keyhole recon instead of recreating it from the
%                       tofScatter. Comment out call to readScatterNonTOF
%     2008-July-23 RMM  mbscParams4recon for each frame is written to disk 
%                       and read in before tofosem. Need to write this (or
%                       hold in memory since it contains the
%                       scatTailFactors for each frame
%     2008-July-23 RMM/CWS  
%                       Average geocalFactors is added as a field to mscParams4recon
%                       and passed to tofosem. 
%     2009-Feb-23  TD   modified z-filtering to un-bias outside slice
%     2009-Apr-07  MWD  Consolidated all inputs to a single file named
%                       petrecon_tof_params.m. Eliminated need for GUI,
%                       getGUIParams.m, optional call arguments,
%                       config_file.txt, readReconParamsTextfile. Added
%                       writeMatlabStructure.m function to write
%                       Recon_Params text file. Softcoded a check to see if
%                       PIFA file exists. Added code to delete large
%                       temporary files created during the reconstruction.
%     2009-July-21 MWD  Added durationMultFactorArray and
%                       decayMultFactorArray to osem3d_ng calls.
%     2009-July-30 MWD  Added writeIterDicom call to allow user to save
%                       DICOM images after each iteration.
%     2009-Dec-02  TD   Added parameter passing for globalScatterCap
%     2010-Feb-03 SGR	Reduced number of calls to tofosem from 4 to 1 (eliminated
%						calls in check for keyhole and scatter)
%						Changed API to tofosem (pass reconParams, acqParams, scanner structures)
%						Replaced reconParams.nz with acqParams.nZ for overlap calculations
%						Check for file existance on Scatter and Deadtime calculations
%						Set deleteTemp to 0 by default
%     2010-Mar-09  CWS  Updates to support 10x10 geometry, time mashing.
%     2010-Oct-05  SGR  Modified PIFA processing to use petrecon_makePIFAs(). 

tic
deleteTemp=0; %Set to delete intermediate files 


%% Help information (need to do this in this form for deployed version)
if ~isempty(varargin) && ...
        (strcmpi(varargin{1}, 'help') || strcmpi(varargin{1}, '-help'))
    disp('PETRECON_TOF - reconstruct TOF data');
    disp(' ');
    disp('Copy petrecon_tof_params.m in current working directory.');
    disp('Modify parameters above dashed line in petrecon_tof_params.m');
    disp('The parameters below the dashed line are rarely modified.');
    disp('The current working directory should have dicom and CTAC');
    disp('directories, and also have the PIFA files (AA*)');
    disp('See TOF_RECON_README for help with data setup.');
    return
end

%% Display code version information
if ~isempty(varargin) && ...
        (strcmpi(varargin{1}, 'version') || strcmpi(varargin{1}, '-version'))
    disp('Version: tofrecon version 1.45 - 15Apr2009'); % fix - add version number
    return
end

%%Load parameter file
if (isempty(varargin))
    disp(['Reading reconParams from' which('petrecon_tof_params')]);
    rehash
    petrecon_tof_params
else
    reconParams=varargin{1};
end

writeMatlabStructure([reconParams.dir 'reconParams'], reconParams);

% This is the old, concept car, version of data sorting.
%who
%if ~exist([reconParams.dir 'rawList' filesep],'dir')
%    fprintf('List data not found...reconstructing from RDFs\n');
%    fprintf(' ***Unlist duration information will be ignored***\n');
%
%    [dicomname,reconParams.nFrames,frameoffset,studyID]=...
%        sortRawDicom(reconParams.dir,'dicom/','*RPDC*',0);
%    useRDFRawData=true;    
%else
%    [dicomname,reconParams.nFrames,frameoffset,studyID] = ...
%        sortRawData_tof(reconParams.dir, 'dicom/', '*RPDC*', 0, ...
%        config_params.bin_count, useRDFRawData, ...
%        reconParams.unlistStartDuration_mSec,reconParams.unlistEndDuration_mSec,...
%        addedUnlistOptions);
%end

% If raw data is in the form of DICOM files, in the dicom directory, sort 
% DICOM files and write RDF's.  If other source, determine if 
% NOTE: If input data is coming from a nonDICOM source, it is the
% responsibility of the user to (1) provide reconParams fields nFrames,
% overlap and inputFilename, plus variable dicomrdfname (if DICOM output is 
% desired) and studyID for subsequent processing, (2) provide nFrames RDF files with 
% names inputFilename.0, inputFilename.1, etc., properly sequenced for 
% overlap, (3) provide a properly-named normalization RDF, and (4) provide a 
% properly-named well counter file (Nslices slice factors plus one global 
% scale factor). Also, note that DICOM output is not possible without DICOM input.
if exist([reconParams.dir 'dicom' filesep],'dir')
    fprintf('Dicom directory found...reconstructing from extracted RDFs\n');
    [dicomname,reconParams.nFrames,frameoffset,studyID]=...
        sortRawDicom(reconParams.dir,'dicom/','*RPDC*',0);
    useRDFRawData=true;
    if frameoffset
        % New 26 Feb 2010 CWS: Need to read, not assume, slice spacing & nZ
        rdf=readRDF([reconParams.inputFilename '.0']);
        nz=2*rdf.sharc_rdf_sys_geo_data.axialCrystalsPerBlock...
            *rdf.sharc_rdf_sys_geo_data.axialBlocksPerModule-1;
        sv = 0.5*(rdf.sharc_rdf_sys_geo_data.detectorAxialSize / ...
            (rdf.sharc_rdf_sys_geo_data.axialCrystalsPerBlock...
            *rdf.sharc_rdf_sys_geo_data.axialBlocksPerModule));
        reconParams.overlap = round(nz-abs(frameoffset)/sv);
        fprintf('Overlap of %d slices determined from data.\n',reconParams.overlap);
        clear rdf;
    else
        reconParams.overlap = 0;
    end
elseif exist([reconParams.inputFilename '.0'],'file')
    magicNumber=readRaw([reconParams.inputFilename '.0'],[1 4],'uint8','l',0);
    if norm(double(magicNumber)-[255 254 0 0])==0
        fprintf(['Raw data file(s) found...\n' ...
            '    assuming needed variables, cal files and data sequencing are provided.\n']);
        useRDFRawData=true;
    elseif norm(double(magicNumber)-[50 68 51 68])==0
        fprintf(['VPTOF file(s) found...\n' ...
            '    assuming needed variables, cal files and data sequencing are provided.\n']);
        useRDFRawData=false;
    else
        error('Input files not of appropriate format');
    end
    if ~isfield(reconParams,'nFrames')
        error('Required reconstruction parameter "nFrames" not specified');
    elseif reconParams.nFrames > 1 && ~isfield(reconParams,'overlap')
        error('Required reconstruction parameter "overlap" not specified');
    end
    if ~exist('studyID','var')
        studyID=101;
    end
else
    error('No appropriate input data found');
end

reconParams.emFilenameVPTOF=reconParams.inputFilename;


if(reconParams.useCorrFlag)

	%% Generate PIFA frames
	% generate CTAC/PIFA files only if we are doing scatter and/or attenuation correction
	% Note 20Oct09 CWS: ACQC CTAC shift in S-I direction information is
	%                     passed to petrecon_makePIFAs through reconParams.acqcS;
	if (reconParams.scatterFlag || reconParams.attenuationFlag)
        reconParams=petrecon_makePIFAs(reconParams);
	end % if (reconParams.scatterFlag || reconParams.attenuationFlag)

    scatterFraction = zeros(reconParams.nFrames, 1); % Initialize
    for frameNum=1:reconParams.nFrames
%% Start frame-by-frame correction processing
        fprintf('\nCorrection processing for frameNum %d of %d\n',frameNum,reconParams.nFrames);

        %READ EMISSION RDF
        fprintf('Reading emission RDF\n');
        rdf=readRDF([reconParams.inputFilename '.' num2str(frameNum-1)]); % Modified for v6/v7 support 28Mar2008
        if isfield(rdf,'seg2Data')                % Don't need the segment ever
            rdf = rmfield(rdf,'seg2Data');
        end
     
        if mod(rdf.nphi, reconParams.numSubsets)
            error('Highly recommend evenly divisible number of subsets.');
        end

        %Get the sinogram dimensions
        rdfSize = [rdf.nu rdf.nv rdf.nphi];

        %PARAM SETUP: set up imParams,scanner, and acqParams structures
        scanner=petrecon_scanner(rdf); % fix KH scale factors
        acqParams=petrecon_acqParams(rdf);

        % Note: to make a working entry point for simulated data not associated with
        % an RDF, the goal for reformatting this code is that there be no calls
        % to rdf fields below this point--everything should come from
        % scanner or acqParams parameters.
%% Decay and scan duration
        if (reconParams.decayFlag == 1)
            lambda = log( 2.0 ) / rdf.sharc_rdf_pet_exam_data.halfLife;
            durationFactor = lambda * ( rdf.sharc_rdf_acq_stats_data.frameDuration / 1000.0 );
            startFactor =  - ( lambda * ( rdf.sharc_rdf_acq_stats_data.frameStartTime - ...
                rdf.sharc_rdf_acq_stats_data.scanStartTime ) );
            decayFactor= (durationFactor * exp( -( startFactor ) ) ) / ( 1 - ( exp( -( durationFactor )) ) );
            fprintf('Decay Factor = %f\n',decayFactor);
        else
            decayFactor=1;
        end

        %DURATION
        durationMultFactor = rdf.sharc_rdf_acq_stats_data.frameDuration ./ 1000;
        % take binDuration into account for gated data
        durationMultFactor = durationMultFactor * petrecon_binDurationFraction(rdf);
        durationMultFactorArray(frameNum) = durationMultFactor;
        decayMultFactorArray(frameNum)=decayFactor;
        % Initialize DEADNORM (the product of deadtime and norm) to ones.
        deadnorm = ones(rdfSize, 'single');

%% Normalization (only run this on the first frame)
        if (reconParams.normalizationFlag && (frameNum == 1))
            % Norm calculation is the same for each frame. So we will just calculate
            % it for the first frame and then use that calculation each time through
            % the loop.

            fprintf('Norm Calculation\n');
            %Read crystal efficiencies (nPhi*4,numRings):
            % xtals=readRaw(reconParams.normRawFilename,[rdf.nz*4,scanner.numRings],'float','l',7168);
            %Read geometric cal (nU,xtalsperblock):
            %   integers plus one float scale factor
            normrdf=readRDF(reconParams.normRawFilename);
            xtals=normrdf.norm_3d.crystal_factors;
            %geoSegOffset=normrdf.sharc_rdf_sorter_data.sharc_rdf_acq_data_seg_parms(5).dataSegmentOffset;
            %geoScaleOffset= normrdf.sharc_rdf_sorter_data.sharc_rdf_acq_data_seg_parms(5).scaleFactorsOffset;
            %geoint=readRaw(reconParams.normRawFilename, ...
            %    [normrdf.nx normrdf.ny],'uint16','l',geoSegOffset);  % NOTE this read was using the data
            % dimensions, not the norm
            % dimensions.  This was OK
            % in v6 RDFs bun not v7.
            %geoscale=readRaw(reconParams.normRawFilename,[1,1],'float','l',geoScaleOffset);
            %geo=single(geoint).*geoscale;
            geo=normrdf.seg4FloatData;
            writeSavefile(geo, reconParams.geoCalFilename);
            deadnorm=Norm3D(deadnorm, geo, xtals);
            if reconParams.badSpotsCorrectionFlag
                % We have a bad detector
                badSpots=find((deadnorm > 10) | ~isfinite(deadnorm));
                deadnorm(badSpots)=1;
            else
                badSpots = [];
            end
            writevp(reconParams.normProcFilename,deadnorm,acqParams,scanner);
            clear geoSegoffset geoScaleOffset normrdf xtals geoint geoscale geo
        elseif (reconParams.normalizationFlag && (frameNum > 1))
            deadnorm = deadnorm .* readvp(reconParams.normProcFilename);
        elseif ~reconParams.normalizationFlag
            badSpots = [];
        end

%% Deadtime          
        % Get deadtime including crystal puc standard  for KH
		if ~exist([reconParams.normdeadFilename '.'  num2str(frameNum-1)],'file')
       		if (reconParams.deadtimeFlag == 1)
           	 	fprintf('Deadtime and crystal Pile up Calculation\n');
            	%crystal factors from rdf if present or default scanner
            	deadtime=petrecon3d_dtpuc(rdf);
            	deadnorm = deadnorm .* deadtime;
            	clear deadtime;
        	end
        	% OLD HL deadtime correction generation
        	if (reconParams.deadtimeFlag == 2)
            	fprintf('Deadtime Calculation\n');
            	deadtime=petrecon3d_dt(rdf);
            	deadnorm = deadnorm .* deadtime;
            	clear deadtime;
        	end      
        	rdf=rmfield(rdf,'unitMuxDeadTime');
			% rdf=rmfield(rdf,{'unitIntegDeadTime', 'unitMuxDeadTime'}); %
			% 29Jul08: need these later
        	%Create norm/deadtime multiplicative factors
        	writevp([reconParams.normdeadFilename '.'  num2str(frameNum-1)], deadnorm,acqParams,scanner);
        	clear deadnorm;
		end

%% Randoms
        if (reconParams.randomsFlag == 1) %RFS
            fprintf('RFS Calculation\n');
            % This is the nonTOF RFS calculation-need to scale down to TOF
            % bins later
            corr=petrecon3d_rfs(rdf,acqParams,scanner, reconParams);

			%By default we will always write the keyhole randoms file. 
			%This way it is available for other recons if needed.
            % Will need "full" randoms for the first pass image
            writevp([reconParams.randomsFilename '.nonTOF.' num2str(frameNum-1)],corr,acqParams,scanner);

            % Divide total randoms by the number of ticks. This gives a per-tick
            % randoms estimate.
            % New 28Jan2010: Need to scale up by the mashing factor, so
            % this is a per-bin estimate.
            corr = corr * (acqParams.timeMash/acqParams.coinWindowLSBs);
            writevp([reconParams.randomsFilename '.'  num2str(frameNum-1)],corr,acqParams,scanner);
            clear corr;
        end

        rdf=rmfield(rdf,'singles');
        if (isfield(rdf,'seg3Data'))
            rdf=rmfield(rdf,'seg3Data');
        end

%% Attenuation: PIFA --> ACF sinogram
        if (reconParams.attenuationFlag)
            fprintf('Generate CTAC\n');
            pifa=readPIFA([reconParams.pifaFilename '.' num2str(frameNum-1) '.pifa']);
            muImg=pifa.data;
            pifa=rmfield(pifa,'data');
            % New 2 Mar 2010 by CWS: Allow 0.05 mm tolerance on PIFA
            % location, and change to a "true" error message
            if ((pifa.tableLocation-rdf.sharc_rdf_acq_param_data.sharc_rdf_acq_scan_params.tableLocation)^2 > 0.05^2)
                error(['PIFA location (' num2str(pifa.tableLocation,5) ...
                    ') does not match emission location (' ...
                    num2str(rdf.sharc_rdf_acq_param_data.sharc_rdf_acq_scan_params.tableLocation,5)...
                    ')']);
            end
            %Flip PIFA image to be consistant with projector orientation
            for i=1:pifa.zm
                muImg(:,:,i)=flipud(muImg(:,:,i));
            end

            %Forward project mu image with VQC parameters applied
            ctac3d=muImg2ctac3d_ng(muImg,scanner,acqParams,pifa, ...
                +rdf.sharc_rdf_sys_geo_data.vqc_XaxisTranslation, ...
                +rdf.sharc_rdf_sys_geo_data.vqc_YaxisTranslation, ...
                rdf.sharc_rdf_sys_geo_data.transaxial_crystal_0_offset+...
                rdf.sharc_rdf_sys_geo_data.vqc_ZaxisRoll);
            writevp([reconParams.attenFilename '.' num2str(frameNum-1)],ctac3d,acqParams,scanner);

            clear muImg;
        else % No need for attenuation computation
            ctac3d = ones(rdfSize);
        end

        % Bad Spots Correction:
        % Set equal to zero to make up for bad spots that were set to 1 in norm.
        ctac3d(badSpots)=0;

        fprintf('Applying inverse corrections to CTAC sinogram\n');
        ctac3d=ctac3d./readvp([reconParams.normdeadFilename '.' num2str(frameNum-1)]);
        ctac3d=ctac3d./decayFactor;
        writevp([reconParams.multFilename '.' num2str(frameNum-1)],ctac3d,acqParams,scanner);
        clear ctac3d;

%% Scatter
		nonTOFscatfile=[reconParams.dir 'scatNonTOF.' num2str(frameNum-1)];
        if ((reconParams.scatterFlag) && (~exist(nonTOFscatfile,'file')))
            fprintf('Preparing scatter data \n');

            if useRDFRawData
                corr=readNonTOFfromRDFv7([reconParams.emFilenameVPTOF '.' num2str(frameNum-1)]);
            else
                corr=readvp([reconParams.emFilenameVPTOF '.' num2str(frameNum-1)]); % nonTOF
            end

            if reconParams.randomsFlag
                % The scatter file is the scatter per timing bins, which we need to
                % multiply by the number of timing bins for total scatter:
                % 28Jan2010 Changed to use the nonTOF estimate saved earlier 
                corr=corr- readvp([reconParams.randomsFilename '.nonTOF.' num2str(frameNum-1)]);
            end
            corr=corr.*readvp([reconParams.normdeadFilename '.',num2str(frameNum-1)]);
            corr=geoCorrection(corr,scanner,acqParams);
            ctac3d=readvp([reconParams.attenFilename '.' num2str(frameNum-1)]);
            ctac3d=geoCorrection(ctac3d,scanner,acqParams);
            geoCalFactors = readSavefile(reconParams.geoCalFilename);

            fprintf('Fully 3d Scatter \n');
            [dsTOFscatterUpPhi, mbscParams4recon, nontofScatter3d] = ...
                petrecon3d_tofScatter3d( corr, ctac3d, pifa, geoCalFactors, ...
                rdf, acqParams, scanner, reconParams.globalScatterCap);
            writeSavefile(dsTOFscatterUpPhi,[reconParams.dsScatterFilenameTOF '.' num2str(frameNum-1)]);
            % Write NON-TOF scatter to file
            nontofScatter3d = invGeoCorrection(nontofScatter3d,scanner,acqParams, 0);
            nontofScatter3d = nontofScatter3d./readvp([reconParams.normdeadFilename '.' num2str(frameNum-1)]);
            writevp([reconParams.dir 'scatNonTOF.' num2str(frameNum-1)], nontofScatter3d,acqParams,scanner);
            
            % Generate scatter norm for OSEM code:
            geoCalFactors = mean(geoCalFactors, 2);
            geoCalFactors = repmat(geoCalFactors, [1 acqParams.nV, acqParams.nPhi]);
            scatnorm = readvp([reconParams.normdeadFilename '.' num2str(frameNum-1)]);
            scatnorm = geoCalFactors./scatnorm;
            for k = 1:size(scatnorm,2)
                scatnorm(:,k,:) = mbscParams4recon.scatTailFactors(k, 1).*scatnorm(:,k,:);
            end
            writevp([reconParams.scatterNormFilename '.',num2str(frameNum-1)],scatnorm,acqParams,scanner);
            mbscParams4recon.geoCalFactors = geoCalFactors(:,1,1);
            clear corr ctac3d geoCalFactors nontofScatter3d scatnorm;

            % Write out the mbscParams4recon for current frame - to be read
            % before tofosem
            mbscParamsFname = [reconParams.dir filesep 'mbscParams4recon.' num2str(frameNum) '.mat'];
            save(mbscParamsFname, 'mbscParams4recon');
            
        end
    end  %END frameNum Loop
    % Write decay and duration files...these are used by osem3d_ng, which
    % keyhople recon calls
    writeRaw([reconParams.dir 'duration'],durationMultFactorArray,'float','l',0);
    writeRaw([reconParams.dir 'decay'],decayMultFactorArray,'float','l',0);
else
    %% If no corrections, just set up the raw data.
    rdf = readRDF([reconParams.inputFilename '.0']);
    acqParams=petrecon_acqParams(rdf);
    scanner=petrecon_scanner(rdf);

end %reconParams.useCorrFlag

%% Get WCC information
if exist(reconParams.wcc3dFilename,'file')
    fprintf('Reading well counter values\n');
     wccfileinfo=dir(reconParams.wcc3dFilename);
    wccsens=readRaw(reconParams.wcc3dFilename,[acqParams.nZ,1],'float','l',0); % fix - can we omit this?
	 wccsens=reshape(squeeze(wccsens),[1,1,acqParams.nZ]);
%	wccsensmat=repmat(wccsens,[reconParams.nx,reconParams.nx,1]);
    wccact=readRaw(reconParams.wcc3dFilename,[1,1],'float','l',wccfileinfo.bytes-4);
else
    wccact = 1; %wccact=readRaw(reconParams.wcc3dFilename,[1,1],'float','l',acqParams.nZ*4); % fix - replace when wcc is present
    disp('WARNING: No well-counter file found. This will affect quantitation.');
end

%% Set up targeting information - need this before keyhole reconstruction
% Added 17Apr08-correct orientation parsing for head first/feet first plus
% conventional representation of "y".
if (rdf.sharc_rdf_acq_param_data.sharc_rdf_acq_landmark_params.patientEntry == 0)
    reconParams.xOffset=reconParams.xTarget+rdf.sharc_rdf_sys_geo_data.vqc_XaxisTranslation;
else
    reconParams.xOffset=-reconParams.xTarget+rdf.sharc_rdf_sys_geo_data.vqc_XaxisTranslation;
end
reconParams.yOffset=-reconParams.yTarget+rdf.sharc_rdf_sys_geo_data.vqc_YaxisTranslation;
reconParams.rotate=rdf.sharc_rdf_sys_geo_data.transaxial_crystal_0_offset+ ...
    rdf.sharc_rdf_sys_geo_data.vqc_ZaxisRoll;

%DETERMINE TARGET PARAMATERS (KEYHOLE TARGET, NONKEYHOLE TARGET, FULL FOV)
nf=scanner.maxFOV/10.;
nt=reconParams.nx;
crossoverDFOV = ((nf*sqrt(1.0+(nf*nf)/(nt*nt))) - (2.0*sqrt(2.0)))/ ...
	(nf*(1.0 + (nf*nf)/(nt*nt)))* scanner.maxFOV/10.;

crossoverDFOV=floor(crossoverDFOV*10.0);
if (reconParams.FOV < crossoverDFOV)
   	reconParams.keyholeFlag = 1;
%   	nonkeyholeTarget =0;
elseif (reconParams.FOV >= crossoverDFOV && reconParams.FOV < scanner.maxFOV)
   	reconParams.keyholeFlag = 0;
%   	nonkeyholeTarget =1;
else
   	reconParams.keyholeFlag = 0;
%   	nonkeyholeTarget = 0;
end

%% Keyhole processing
if reconParams.keyholeFlag
    fprintf('Keyhole processing:\n');
    % osem3d_ng requires decay and deadtime files (each with one float per frame)
    % these are written above if corrections were done and keyhole was selected.
    % If you are doing a keyhole recon after a full FOV recon, you'd like to take
    % advantage of those corrections, but decay and deadtime files have not been
    % written.  Note that this requires opening and reading all the rdf's.
    % Note that decay factors are not used in the non-overalpped osem3d_ng
    % reconstruction, but the routine still reads the file, so something
    % must be there.
    if ~exist([reconParams.dir 'duration'],'file') || ...
            ~exist([reconParams.dir 'decay'],'file')
        fprintf('    Need to generate duration and/or decay files.');
        for frameNum=1:reconParams.nFrames
            rdf=readRDF([reconParams.inputFilename '.' num2str(frameNum-1)]);
            if (reconParams.decayFlag == 1)
                lambda = log( 2.0 ) / rdf.sharc_rdf_pet_exam_data.halfLife;
                durationFactor = lambda * ( rdf.sharc_rdf_acq_stats_data.frameDuration / 1000.0 );
                startFactor =  - ( lambda * ( rdf.sharc_rdf_acq_stats_data.frameStartTime - ...
                    rdf.sharc_rdf_acq_stats_data.scanStartTime ) );
                decayFactor= (durationFactor * exp( -( startFactor ) ) ) / ( 1 - ( exp( -( durationFactor )) ) );
                fprintf('        Decay Factor = %f\n',decayFactor);
            else
                decayFactor=1;
            end

            %DURATION
            durationMultFactor = rdf.sharc_rdf_acq_stats_data.frameDuration/1000;
            % take binDuration into account for gated data
            durationMultFactor = durationMultFactor * petrecon_binDurationFraction(rdf);
            durationMultFactorArray(frameNum) = durationMultFactor;
            decayMultFactorArray(frameNum)=decayFactor;
        end
        if ~exist([reconParams.dir 'duration'],'file')
            writeRaw([reconParams.dir 'duration'],durationMultFactorArray,'float','l',0);
        end
        if ~exist([reconParams.dir 'decay'],'file')
            writeRaw([reconParams.dir 'decay'],decayMultFactorArray,'float','l',0);
        end
    end

    % Set up keyhole params...start from reconParams, gets us nx, ny, nz,
    % numIterations, numSubsets,FOV, keyholeFlag, nFrames, overlap, dir
    keyholeParams=reconParams;
    % Modify some of those...
    keyholeParams.FOV=scanner.maxFOV;
    keyholeParams.nx=64;
    keyholeParams.ny=64;
    keyholeParams.overlap=0;
    keyholeParams.keyholeFlag = 0; %No keyhole for the keyhole!
    % Add other needed parameters
    keyholeParams.xOffset=0;
    keyholeParams.yOffset=0;
    keyholeParams.keepSubsetUpdates = 0;
    keyholeParams.keepIterationUpdates = 0;
    keyholeParams.startIteration=1;
    keyholeParams.startSubset=1;
    % Correction parameters - note that we want in-the-loop scatter and
    % randoms, which is "2", and we will force an acf correction in the loop, even if
    % there attenuation and norm and deadtime are all off (file of ones)
    keyholeParams.acfCorrFlag=2;
    keyholeParams.scatterCorrFlag=2*keyholeParams.scatterFlag;
    keyholeParams.randomsCorrFlag=2;
	keyholeParams.detectorResponseFlag=0;

    % set up keyhole input files:
    % Emission    - osem3d_ng needs a vp file.
    % Randoms     - took care of that in the randoms correction section,
    %                  but may need to replicate that if keyhole is "new"
    % Attenuation - This file already is built
    % Scatter     - need to build that here
    % So...convert the emission (just read it and write it...), then...
    %      if scatter correction, then read out a NonTOF scatter and recon
    %      else    go ahead and recon with what we have
    fprintf('    Converting TOF emission data into nonTOF vp files...');
    for frameNum=1:reconParams.nFrames
        writevp([reconParams.dir 'emisNonTOF.' num2str(frameNum-1)],...
            readNonTOFfromRDFv7([reconParams.inputFilename '.' num2str(frameNum-1)]),acqParams,scanner);
    end
    fprintf('done.\n');


	fprintf('    Reconstruction first-pass images...');
	keyholeImage = osem3d_ng(...
            'emFilename',[reconParams.dir 'emisNonTOF'], ...
            'scatterFilename',[reconParams.dir 'scatNonTOF'], ...
            'randomsFilename',[reconParams.randomsFilename '.nonTOF'], ...
            'multFilename',reconParams.multFilename, ...
            'acqParams',acqParams, ...
            'reconParams',keyholeParams, ...
            'scanner',scanner,...
            'durationMultFactorArray', durationMultFactorArray,...
            'decayMultFactorArray', decayMultFactorArray);
    fprintf('done.\n');

    %By default image is processed with wcc sensitivity and duration correction. We want to
    %remove this prior to forward projecting the keyhole frames
    wccsens=readRaw(reconParams.wcc3dFilename,[acqParams.nZ,1],'float','l',0);
    wccsens=reshape(squeeze(wccsens),[1,1,acqParams.nZ]);
    wccsensmat=repmat(wccsens,[keyholeParams.nx,keyholeParams.nx,1]);
    if ~exist('durationMultFactorArray', 'var')
        durationFile = [reconParams.dir 'duration'];
        durationMultFactorArray=readRaw(durationFile,[reconParams.nFrames,1],'float','l',0);
    end
    if ~exist('decayMultFactorArray', 'var')
        decayFile = [reconParams.dir 'decay'];
        decayMultFactorArray=readRaw(decayFile,[reconParams.nFrames,1],'float','l',0);
    end

    for frameNum=1:keyholeParams.nFrames
        keyholeImage(:,:,1+acqParams.nZ*(frameNum-1):acqParams.nZ*frameNum)=  ...
            keyholeImage(:,:,1+acqParams.nZ*(frameNum-1):acqParams.nZ*frameNum)*durationMultFactorArray(frameNum)./wccsensmat;

    end

    % Now: cut out the keyhole region
    %Create one side margin over the requested FOV, converted to unitos output pixels, rounded up
    fullpix=keyholeParams.FOV/keyholeParams.nx;
    finalpix=reconParams.FOV/reconParams.nx;
    margin=ceil(fullpix*sqrt(2)/finalpix);
    
    padImParams=reconParams;
    padImParams.nx=reconParams.nx+2*margin;
    padImParams.ny=padImParams.nx;
    padImParams.FOV=reconParams.FOV+2*margin*finalpix;

    endPos = fullpix * (keyholeParams.nx-1)/2.0;
    x2=(linspace(-endPos, endPos, keyholeParams.nx) - reconParams.xOffset).^2;
    y2=(linspace(-endPos, endPos, keyholeParams.nx) - reconParams.yOffset)'.^2;

    keymaskSingle=x2(ones(keyholeParams.nx,1),:)+y2(:,ones(keyholeParams.nx,1))...
        <= ((reconParams.FOV+fullpix*sqrt(2))/2)^2;

    keymaskSingle = keymaskSingle';
    nkh_slice=size(keyholeImage,3);
    keymask=repmat(keymaskSingle,[1 1 nkh_slice]);
    cutoutImage = keyholeImage.* (1-keymask);
    for frameNum=1:keyholeParams.nFrames
        writeSavefile(cutoutImage(:,:,1+acqParams.nZ*(frameNum-1):acqParams.nZ*frameNum),...
            [reconParams.dir 'keyholeImg.' num2str(frameNum-1)]);
    end
else
	keyholeParams=reconParams; %Pass in dummy copy of reconParams. keyholeParams not used if reconParams.keyholeFlag=0.
end



%% TOF ITERATIVE RECONSTRUCTION

save temp_tofosem_input.mat
if ~exist('durationMultFactorArray', 'var')
        durationFile = [reconParams.dir 'duration'];
        durationMultFactorArray=readRaw(durationFile,[reconParams.nFrames,1],'float','l',0);
end
if ~exist('decayMultFactorArray', 'var')
        decayFile = [reconParams.dir 'decay'];
        decayMultFactorArray=readRaw(decayFile,[reconParams.nFrames,1],'float','l',0);
end

% OSEM Processing loop
nslice=(reconParams.nFrames)*(acqParams.nZ-reconParams.overlap) ...
    + reconParams.overlap;
reconImg = zeros([reconParams.nx,reconParams.nx,nslice],'single');
for frameNum=1:reconParams.nFrames
    
	% Read in the mbscParams4recon for current frame
	mbscParamsFname = [reconParams.dir filesep 'mbscParams4recon.' num2str(frameNum) '.mat'];
	decayFactor=decayMultFactorArray(frameNum);
	load(mbscParamsFname);

	currentImg = tofosem('emissFile',[reconParams.emFilenameVPTOF '.' num2str(frameNum-1)], ... %vptofFile
 					'multFile',[reconParams.multFilename '.' num2str(frameNum-1)],...     % all mults
 					'acfFileName', [reconParams.attenFilename '.' num2str(frameNum-1)],...     % attenOnlyFile
 					'normdeadFileName', [reconParams.normdeadFilename '.' num2str(frameNum-1)],...     % norm*dead File
 					'scatEstimate',[reconParams.dsScatterFilenameTOF '.' num2str(frameNum-1)],[reconParams.scatterNormFilename '.' num2str(frameNum-1)], mbscParams4recon, ...
                 	'addFile',[reconParams.randomsFilename '.' num2str(frameNum-1)],...
 					'keyhole',[reconParams.dir 'keyholeImg.' num2str(frameNum-1)],keyholeParams,...	
 					'decayMultFactor',decayFactor, ...   
 					'terse',  ...
 					'saveIterations',[reconParams.imOutFilename '.iter.' num2str(frameNum-1)],...
 					'saveNorm',[reconParams.imOutFilename '.osemnorm.' num2str(frameNum-1)],...
 					'reconParams', reconParams,...						
 					'acqParams', acqParams, ...
 					'scanner', scanner);

	% Store current estimate of current frames while processing next
	% frames
        currentImgFrames(:,:,:,frameNum) = currentImg;
end
%End frame loop
save temp_tofosem_loop_output.mat % clear, load temp_tofosem_loop_output

if ~exist('durationMultFactorArray', 'var')
        durationFile = [reconParams.dir 'duration'];
        durationMultFactorArray=readRaw(durationFile,[reconParams.nFrames,1],'float','l',0);
end
if ~exist('decayMultFactorArray', 'var')
        decayFile = [reconParams.dir 'decay'];
        decayMultFactorArray=readRaw(decayFile,[reconParams.nFrames,1],'float','l',0);
end

%Read in wcc sensitivity values
wccsens=readRaw('wcc3d',[1,1,acqParams.nZ],'float','l',0);
wccsensmat=repmat(wccsens,[reconParams.nx,reconParams.nx,1]);

%Combined overlap slices
% Accumulate images from multiple frames, for the overlap slices
% perform a weighted addition dpending on slice sensitivity
for frameNum = 1:reconParams.nFrames

         if (frameNum > 1)
             overlapStart = (frameNum-1)*acqParams.nZ - (frameNum-1)*reconParams.overlap+1;
             overlapEnd = overlapStart + reconParams.overlap-1;
             reconImg(:,:,(overlapEnd+1):(overlapEnd + acqParams.nZ-reconParams.overlap)) ...
                 = currentImgFrames(:,:,reconParams.overlap+1:acqParams.nZ,frameNum).* ...
                            wccsensmat(:,:,reconParams.overlap+1:acqParams.nZ)/durationMultFactorArray(frameNum);


             for slice = 1:reconParams.overlap

            weightB = decayMultFactorArray(frameNum)*wccsens(slice); %Previous frames scale factor. Use current frame decay factor&wcc
            weightA = decayMultFactorArray(frameNum-1)*wccsens(acqParams.nZ-(reconParams.overlap-slice));  %Current frame scale factor. Use previous frame decay factor&wcc
            weightA=weightA.*slice;
            weightB=weightB.*(reconParams.overlap-slice+1);


                 reconImg(:,:,overlapStart+slice-1) = ...
                     (weightB*durationMultFactorArray(frameNum-1)*currentImgFrames(:,:,acqParams.nZ-reconParams.overlap+slice,frameNum-1).*wccsensmat(:,:,acqParams.nZ-reconParams.overlap+slice) ...
                     + weightA*durationMultFactorArray(frameNum-1)*currentImgFrames(:,:,slice,frameNum).*wccsensmat(:,:,slice))/ ...
                (weightB*durationMultFactorArray(frameNum-1)+weightA*durationMultFactorArray(frameNum))/ ...
                durationMultFactorArray(frameNum-1) ;
             end

         else
				 reconImg(:,:,1:acqParams.nZ) = currentImgFrames(:,:,:,frameNum).*wccsensmat/durationMultFactorArray(frameNum);
         end
 

    % Now, remove the VPTOF file to save disk space (this can always be
    % re-created from the rawList folder)
end % For each frame

save temp_recon_status.mat

clear currentImgFrames currentImg

%% Write un-postprocessed images to DICOM files, if desired (added MWD) to
% save iterations.
if (reconParams.keepIterationUpdates)
    writeIterDicom(studyID,'reconParams',reconParams);
end

%% X flip of image if patientEntry is Head First
% Image flip lr and image index z flip for head first. After this the fastest changing is to the
% patient left (new 1st index), 2nd index is patient posterior, 3rd index is inferior.
% This works because this is a PET first slice in front machine
tempImg=reconImg;
if (rdf.sharc_rdf_acq_param_data.sharc_rdf_acq_landmark_params.patientEntry == 0)
    for i=1:nslice
        reconImg(:,:,i)=flipud(tempImg(:,:,nslice-(i-1)));
    end
end

%% Pixel scaling into Bq/ml units
% (changed to be consisitent with NG method 24 April 2008)
pixelSizecm=(reconParams.FOV/10)/reconParams.nx;
nomPixelSize=(scanner.maxFOV/10)/128;
reconImg=1e6*reconImg*wccact*scanner.tofWccActScaleFactor*nomPixelSize*nomPixelSize/ ...
    (pixelSizecm*rdf.sharc_rdf_pet_exam_data.positronFraction);  % retain nomPixelSize for compatability

%%  In-plane Post-filtering
if reconParams.postFilterFWHM
    fprintf('\tBeginning post-filtering with %2.2f mm Gaussian filter... ',reconParams.postFilterFWHM);
    sigma = (reconParams.postFilterFWHM/2.35)/(reconParams.FOV/reconParams.nx);
    sigma4 = round(sigma*4);
    kernelSize = 2*sigma4 + 1;
    kernel = gaussianKernel2D([kernelSize,kernelSize],sigma);
    reconImg = convn(reconImg,kernel,'same');
    fprintf('done\n');
end

%% Z-Filter Post-filtering
if reconParams.zfilter
    fprintf('\tBeginning 1-%d-1 z-axis center weighted filtering  ... ',reconParams.zfilter);
    kernel = reshape([1 reconParams.zfilter 1]/(reconParams.zfilter+2),1,1,3);
    reconImg = convn(reconImg,kernel);
    reconImg(:,:,2) = sum(reconImg(:,:,1:2),3);
    reconImg(:,:,end-1) = sum(reconImg(:,:,end-1:end),3);
    reconImg = reconImg(:,:,2:end-1);
    fprintf('done\n');
end

%% Write-out reconstructed image as flat file
writeRaw(reconParams.imOutFilename,reconImg,'float','l',0);

%% Dicom write of final images
% Make a subfolder to save images
image_folder = ['TOF' ...
    '_ex' studyID ...
    '_se' num2str(reconParams.dicomImageSeriesNum) ...
    '_fov' num2str(reconParams.FOV) ...
    '_p' num2str(reconParams.postFilterFWHM) ...
    '_z' num2str(reconParams.zfilter) ...
    '_sub' num2str(reconParams.numSubsets) ...
    '_iter' num2str(reconParams.numIterations) ...
    '_sig' num2str(reconParams.reconSigmas) ...
    '_tr' num2str(reconParams.tRes)];
if exist([reconParams.dir filesep image_folder], 'dir')
    image_folder = sprintf('image_folder_%f',now);
end

image_dir = [reconParams.dir filesep image_folder];
mkdir(image_dir);

%
% Get dictionary name from path, else default to Linux convention
%                   (important for PC operation) CWS 2007-04-19
%
dictionaryName = which('pet-dicom-dict.txt');
if isempty(dictionaryName)
    dictionaryName = '~/pettoolbox/io_utils/matlab/pet-dicom-dict.txt';
end

if (reconParams.writeDicomImage == 1)
    rawDicomHdr=dicominfo(dicomname{1},'Dictionary',dictionaryName);
    if isfield(rawDicomHdr, 'NumberOfUnarchivedSeries')
        rawDicomHdr=rmfield(rawDicomHdr,'NumberOfUnarchivedSeries');
    end
    rawDicomHdr.SliceThickness = acqParams.sV;

    %Permute image prior to dicomwrite
    reconImg=permute(reconImg,[2,1,3]);

    if exist('scatterFraction', 'var')
        writeDicomImage(reconImg,[image_dir filesep 'tof_ex' studyID],rawDicomHdr,reconParams,scatterFraction);
    else
        writeDicomImage(reconImg,[image_dir filesep 'tof_ex' studyID],rawDicomHdr,reconParams);
    end
end

%% Save reconParams to a text file
print_reconParams_to_file_flag = true;
if print_reconParams_to_file_flag
    fid = fopen([reconParams.dir filesep 'reconParams'], 'w');
    reconFields = fieldnames(reconParams);
    for k = 1:length(reconFields)
        if ischar( reconParams.(reconFields{k}) )
            fprintf(fid, '%s  -  %s\n', reconFields{k}, ...
                reconParams.(reconFields{k}));
        elseif (isnumeric( reconParams.(reconFields{k})) || ...
                islogical( reconParams.(reconFields{k})))
            fprintf(fid, '%s  -  %s\n', reconFields{k}, ...
                num2str( reconParams.(reconFields{k})));
        end
    end
    fclose(fid);
    
    if exist(image_dir, 'dir')
        copyfile([reconParams.dir filesep 'reconParams'], image_dir);
    end
end   % End save reconParams to a text file

%% All done
disp('RECONSTRUCTION PROCEDURE COMPLETE');
disp(['Exam ID ' num2str(studyID) ':  RECONSTRUCTION PROCEDURE COMPLETE']);


if (deleteTemp)
    system(['rm ' reconParams.imOutFilename '* ' reconParams.emFilenameVPTOF '* '...
        reconParams.normdeadFilename '* ' reconParams.randomsFilename '* '...
        reconParams.dsScatterFilenameTOF '* ' reconParams.dsScatterFilenameTOF '* '...
        reconParams.attenFilename '* ' reconParams.normProcFilename '* '...
        reconParams.scatterNormFilename '* ' reconParams.multFilename '* '...
        reconParams.inputFilename '* ' reconParams.normRawFilename '* '...
        reconParams.wcc3dFilename '* ' reconParams.geoCalFilename '* ' '*.mat '...
        'decay ' 'duration ' 'geo* ' 'ir* ' '*.mat ' 'norm* ' '*.pifa ' '*.proc '...
        '.raw ' 'wcc3d ']);
end
toc
% % % % %                                                 end
