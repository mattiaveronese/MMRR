#!/usr/bin/perl
# ==================================================================%
# FILE NAME: install_update.pl
#
# PURPOSE:
# This script automatically updates the required TOF recon files. Four files
# are needed for complete update:
#	petrecon_tof
#       petrecon_tof.ctf
#       config_file.txt
#       pettoolbox.tar.gz
# For partial update, config_file.txt and pettoolbox.tar.gz might not be
# necessary. If they are not in the installation directory, a warning will
# be issued, but installation will continue.
# 
# Input:
#	The directory that contains these four files (defaults to /media/cdrom)
# 
# Example:
#	install_update.pl /media/cdrom
# where /media/cdrom is replaced with the actual directory containing the files.

# Copyright (c) 2007-2010 General Electric Company. All rights reserved.
# This code is only made available outside the General Electric Company
# pursuant to a signed agreement between the Company and the institution to
# which the code is made available.  This code and all derivative works
# thereof are subject to the non-disclosure terms of that agreement.

# History:
# DEVELOPER: Tim Deller
# DATE: Jan 22, 2007

if ( ($#ARGV > 0) || (lc($ARGV[0]) eq "help") || (lc($ARGV[0]) eq "-help") )
{
  print "\nThis script automatically updates the required TOF recon files. Four files\n";
  print "are needed for complete update:\n";
  print "      perecon_tof\n";
  print "      petrecon_tof.ctf\n";
  print "      config_file.txt\n";
  print "      pettoolbox.tar.gz\n";
  print "For partial update, config_file.txt and pettoolbox.tar.gz might not be\n";
  print "necessary. If they are not in the installation directory, a warning will\n";
  print "be issued, but installation will continue.\n";
  print "\n";
  print "Input:\n";
  print "      - The directory that contains these four files (defaults to /media/cdrom)\n";
  print "\n";
  print "Example:\n";
  print "      install_update.pl /media/cdrom\n";
  print "where /media/cdrom is replaced with the actual directory containing the files.\n";
  die "\n";
}

$username = `whoami`;
if ($username !~ m/^petdata/)
{
  print "\nERROR: This code must be run by user petdata.\n";
  print "   You are user $username\n";
  die;
}

if ($#ARGV >= 0)
{
  $source_directory = $ARGV[0];
}
else
{
  $source_directory = "/media/cdrom";
}

print "\nUsing source directory: $source_directory";

if ((-e "$source_directory/petrecon_tof") eq "1")
{
  print "\n\nCopying the new petrecon_tof file:\n    ";
  print $commandrun = "cp $source_directory/petrecon_tof ~petdata";
  if (system("$commandrun") != 0)
  {
    die "\n\nERROR: copy failed. Installation failed.\n";
  }
  system("chmod 755 ~petdata/petrecon_tof");
  system("chown petdata ~petdata/petrecon_tof");
}
else
{
  print "\n\nSERIOUS WARNING: petrecon_tof not found in source directory.\n";
}

if ((-e "$source_directory/petrecon_tof.ctf") eq "1")
{
  print "\n\nCopying the new petrecon_tof.ctf file:\n    ";
  print $commandrun = "cp $source_directory/petrecon_tof.ctf ~petdata";
  if (system("$commandrun") != 0)
  {
    die "\n\nERROR: copy failed. Installation failed.\n";
  }
  system("chmod 644 ~petdata/petrecon_tof.ctf");
  system("chown petdata ~petdata/petrecon_tof.ctf");
}
else
{
  print "\n\nSERIOUS WARNING: petrecon_tof.ctf not found in source directory.\n";
}

if ((-e "$source_directory/config_file.txt") eq "1")
{
  print "\n\nCopying the new config_file.txt file:\n    ";
  print $commandrun = "cp $source_directory/config_file.txt ~petdata";
  if (system("$commandrun") != 0)
  {
    die "\n\nERROR: copy failed. Installation failed.\n";
  }
  system("chmod 644 ~petdata/config_file.txt");
  system("chown petdata ~petdata/config_file.txt");
}
else
{
  print "\n\nWARNING: config_file.txt not found in source directory.\n";
}

if ((-e "$source_directory/pettoolbox.tar.gz") eq "1")
{
  print "\n\nCopying the new pettoolbox.tar.gz file:\n    ";
  print $commandrun = "cp $source_directory/pettoolbox.tar.gz ~petdata";
  if (system("$commandrun") != 0)
  {
    die "\n\nERROR: copy failed. Installation failed.\n";
  }

  print "\n\nExtracting pettoolbox.tar.gz file:\n    ";
  print $commandrun = "cd ~petdata; gunzip -c pettoolbox.tar.gz | tar -xf -";
  if (system("$commandrun") != 0)
  {
    die "\n\nERROR: Extraction failed. Installation failed.\n";
  }
  system("chmod 644 ~petdata/pettoolbox.tar.gz");
  system("chown petdata ~petdata/pettoolbox.tar.gz");
}
else
{
  print "\n\nWARNING: pettoolbox.tar.gz not found in source directory.\n";
}

print "\n\n";

