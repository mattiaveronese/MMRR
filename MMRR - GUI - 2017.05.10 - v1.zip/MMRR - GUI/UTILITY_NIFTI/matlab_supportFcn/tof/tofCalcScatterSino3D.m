% FILE NAME: tofCalcScatterSino3D.m
%
% THIS FILE HAS BEEN MADE OBSOLETE BY THE DEVELOPMENT OF tofCalcSingleScatter3D.m, WHICH
% CALLS C++ ROUTINES FOR SIDDON PROJECTORS AND THE TOF SCATTER ENGINE.  THIS CODE MATCHES
% THE OUTPUT OF tofCalcSingleScatter3D.m v1.1 ON 25 FEB 2011, BUT THERE IS NO GUARANTEE
% IT WILL BE MAINTAINED BEYOND THAT DATE.

% DEVELOPER: Maria Iatrou / Ravi Manjeshwar
%
% PURPOSE:  This function performs the TOF single scatter simulations and
% returns the down sampled TOF scatter sinogram and a non-tof scatter
% estimate

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%  2006 -3D scatter estimation
%  Feb 22, 2007 Initial release - called CalcScatterSino3D_TOF.m
%  Mar 27, 2007 RM Incorporated changes to scatter assignment to axial angles 
%               based on NON-TOF learnings 
%  Apr 5, 2007  MI Normalized timing resolution kernel to have unit gain
%  May 21, 2008 RMM  
%       (1) Change to include all non-zero scatter counts in building
%           scatter sinogram. Previously used only positive scatter counts
%       (2) changes to include solid angle from emission voxel to unscattered 
%           detector and beam divergence (fractional emission counts that are 
%           incident on scatter voxel and detected in the unscattered detector. 
%           Solid Angle and beam divergence added as R_square_scatter_d1
%       (3) Renamed R2_square to R_square_scatter_d2
%       (4) Cleaned up processing sequence to minimize the number of permute
%           operations
%   Jun 21 2008 RMM 
%       (1) changed input from emisImg (128,128,4) to dsEmisImg (32,32,4)
%       (2) moved upsampling of single scatter sinograms to petrecon3d_tofScatter3d
%       (3) accept dsAcqParams and dsImParams as input parameters instead
%           of building it
%   MAy 05 2010 CWS
%       Made changes for deadtime-dependent scatter correction.

