% FILE NAME: getGUIParams.m
%
% DEVELOPER: Tim Deller
%
% PURPOSE:  Initialize recon parameters structure for the elements that show up
%           on the GUI.
%
% INPUT:  a) useGuiFlag -
%               0: skip using the gui (just parameters from this file)
%               1: use the gui (default)
%         b) setIter
%               0: no number of iterations were specified
%         c) setFOV
%
% OUTPUT: reconParams - reconstruction parameters structure

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%     2007-Feb-27 Initial commit (not yet complete) (TD)

