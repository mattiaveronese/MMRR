
% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   2006 -3D scatter estimation
% New faster version 3
% Based on TOF_CalcScatterSino3D_play_copy.m --Convolution in time at the end
%

