% FILE NAME: dsTOFscatterPhiUpsample3d
%
% PURPOSE:  This function upsamples the TOF single scatter sinograms
% in the PHI (in-plane/trans-axial) angle dimension only. The output 
% continues to remain donw-sampled in r (radial) and z1,z2 (theta or axial
% angles)

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% DEVELOPER: Ravi Manjeshwar 
%  RMM  April 4, 2007   Extracted from petrecon3d_tofScatter3d.m and made a
%                       stand-alone function
%                       Made changes to wrap-around lines. Wrap around
%                       lines are borrowed from the opposite in-plane
%                       angles and opposite time bins

% Upsample in phi direction ONLY
