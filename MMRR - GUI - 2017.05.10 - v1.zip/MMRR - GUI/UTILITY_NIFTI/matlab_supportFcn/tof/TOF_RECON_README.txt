TOF_RECON_README
% FILE NAME: TOF_RECON_README.txt

% Copyright (c) 2009-2010 General Electric Company. All rights reserved.
%% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% DEVELOPER: Matt Dekow

Follow this process after acquiring a TOF scan to transfer DICOM files and RDFs:
Transferring Files:
1) Create a directory on the console with the scan name (Ex: ~ctuser/Exam#). Within this directory, create both a "dicom" and "CTAC" directory.
2) Change into the CTAC directory, highlight the CTAC series in ImageWorks, and in Unix shell type the command "dumpDB SERIES ." 
3) Change into the dicom directory, highlight series 901, and in Unix shell type the command "dumpDB SERIES ."
Note: At this point, both your dicom and CTAC directories will have their respective files. Since this is a TOF scan, some emission dicom files in the dicom directory will probably be 0KB in size. Continue with the next steps to acquire the proper sinograms.
4) Generate PIFA images by using the product PET Recon U/I. Select the scan of interest in PET Recon (on console) and submit the job. These PIFA images are placed in ~ctuser/PIFA/EXAM/SERIES/AAAAAA*. Copy these AAAAAA* files to the "~ctuser/Exam#" directory.
5) Change back into the "dicom" directory. Type "ls -l" and take note of the files that are 0 bytes in size.
6) Highlight anything from Series 901 in ImageWorks.
7) In a Unix command window, type the command "cat $SDC_SELECTION_FILE" This will display the paths for all the sets in Series 901.
8) Use these paths to copy these files (only the 0 byte files in Step 5) to your "dicom" directory. Note: Keep the files in the "dicom" directory that Step 2 created above.
9) Type the command dmfParseDicomFile -printit filename | grep "(   9,1062)"
Note: There are three spaces before the "9" in the previous command. Replace "filename" with the .RPDC.1, .RPDC.2, etc. filenames in the "dicom" directory (only need to do this for the 0 byte filenames from Step 5). Do not use the .img files in the command. For example, if you have three 0 byte files from Step 5, you will run this command three times.
10) Take the path from each command run above, and copy those SINO* files to the "dicom" directory.
11) Delete all the 0 byte .img files in the "dicom" directory.
12) Tar the "Exam#" directory and transfer to an offline computer using ftp.

TOF Reconstruction on Offline Computer (with Pet Toolbox):
1) Change into "Exam#" directory.
2) Copy petrecon_tof_params.m code to "Exam#" directory.
3) Modify petrecon_tof_params.m code to adjust the reconstruction using desired parameters. It is usually only necessary to change the parameters above the dashed line in that file.
4) Run petrecon_tof.m code.
