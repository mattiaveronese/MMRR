% FILE NAME: config_file_read.m
%
% PURPOSE:  Read from a configuration file. The config file is three columns:
%           Col 1: 
%
% INPUT:  a) Path and filename of the configuration file.
%
% OUTPUT: reconParams - reconstruction parameters structure

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%     DEVELOPER: Tim Deller
%     2007-Jan-22 Initial commit (not yet complete)

