%
% scatter=readScatterNonTOF(scatEstimateFile,scatNormFile,...
%                           scatMBSCxtals,radCoords,nz,sv,ringDiameter)
% Reads the TOF scatter data:
%           - a coarse-resolution 5-D array (Z1,Z2,phi,r,t)
%           - a normalization file (including the sinogram-specific scale factors)
% Sums over the timing dimension to make non-TOF data, and performs the upsampling
% and normalization needed to make a scatter estimate in (u,v-theta,phi) format.
% This is useful for non-TFO reconstruction of TOF data, for example in keyhole
% reconstruction.
%
% Other inputs:
%   scatMBSCxtals  Number of crystals in system model.
%   radCoords      Radial positions of projection data (something like a 9x381 array)
%   nz             Number of detector rings in the system.
%   sv             Ring spacing in the system
%   ringDiameter   Detector ring diameter.

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

