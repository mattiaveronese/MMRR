% FILE NAME: petrecon3d_tofScatter3d.m
%
% PURPOSE:  This function calls 3d Model Based Scatter routines to generate a 3d
%	TOF scatter estimates. The function initializes the structure mbscParams
%	based on settings consistant with the product implementation. Scanner
%	specific parameters are derived based on rdf.nx (nU). This code was
%	built off mbsc.m.
%
%	Inputs:
%     emis3drr          native geoemtry emission sinogram (typically corrected
%                       for randoms, dt, norm).
%     ctac3d            native geometry CTAC
%	  pifa              pifa structure generated from readPIFA.m (requires
%                       header only,not data).
%     geoCalFactors     geoCal correction factors
%	  rdf               rdf structure generated from readHLRDF
%     acqParams         acqParams structure generated from petrecon_acqParams
%     scanner           scanner structure genenerated from petrecon_scanner
%     globalScatterCap  Maximum value for scatter tail scaling (optional)
%
%	Outputs:
%     dsTOFscatterUpPhi down sampled TOF scatter sinograms. scatter sinograms
%                       are down sampled in all dimensions except time
%                       bins and inplane views.
%     mbscParams4recon  MBSC parameters required to upsample scatter during
%                       reconstruction.
%     nontofScatter3d   Fully upsampled non-TOF scatter estimate.
%

% Copyright (c) 2006-2011 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% DEVELOPER: Maria Iatrou and Ravi Manjeshwar
%   April 12, 2006  RMM  Modified call to tofCalscatterSino3D.m
%                        Moved phi upsampling to a function call
%                        tofCalscatterSino3D.m
%   April 25, 2006  RMM  Removed commented out code for phi upsampling
%   June 21 2008  RMM
%           (1) Added geoCalFactors as input parameter. The estimated
%               scatter sinograms are now multiplied by the mean, radially
%               repositioned geoCal correction factors prior to tail-scaling
%           (2) Added  mbscParams.fitType to allow for tail-scaling or
%               least-squares (LS) tail-fitting, set default to LS-tail-fitting
%           (3) Set mbscParams.isRb from rdf structure to handle
%               LS-tail-fitting for Rb studies
%               The scatterOffsetFactors are divided by the number of
%               timebins to distribute it evenly across the time bins
%           (4) Added mbscParams.emisImgFilterType = 'hanning'
%               and  mbscParams.emisImgFilterFWHM = 18.0
%               to smooth emission images for noise control
%           (5) Accept emisMask from calcSinoTail3d.m and multiply
%               emission image with emisMask (to zero activity outside the
%               body) prior to SSS
%           (6) Sub-sampling emission image in all 3 dimensions
%               128 x 128 x 47)--> (32 x 32 x 4) and passing dsEmisImg to
%               CalcScatterSino3D()
%           (7) Build dsAcqParams and dsImParams here and pass to
%               CalcScatterSino3D() changed call to CalcScatterSino3D()
%           (8) Accept downSampled Scatter sinogram from CalcScatterSino3D()
%               and upsample here
%           (9) create mbscParams4recon structure with mbscParams that are
%               needed inside tof_osem
%  July 30, 2008 MI
%           (1) Add a call to function to generate totalTOFscatter
%               (singles+multiples)
%               Multiples convolution is now done in the down-sampled
%               domain through a square matrix multiplication
%  Sept 11, 2008 RMM
%           (1) Force pifa.ctacDfov=scanner.maxFOV. There are instances
%               where pifa.ctacDfov is 500
%  Dec 2, 2009 TD:
%           (1) Updated dirty tracers list as in petrecon3d_scatter3d
%           (2) Updated DEdirectory to use "which" as in petrecon3d_scatter3d
%           (3) Added global scale factor calculation based on Hua's commits to
%               petrecon3d_scatter3d
%           (4) Added the passing of globalScatterCap
%           (5) Fixed indenting throughout function
%  Mar 3, 2010  CWS - Moved parameter setup to petrecon3d_scatterParams.m
%  25 Feb 2011  CWS - Incorporated accelerated C++ versions of Siddon
%                     projector and "core" scatter engine.
%
%% MBSC Parameters
