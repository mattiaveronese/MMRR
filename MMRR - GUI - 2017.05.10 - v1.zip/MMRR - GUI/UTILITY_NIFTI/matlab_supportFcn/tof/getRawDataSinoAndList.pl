#!/usr/bin/perl
# ==================================================================%
# FILE NAME: getRawDataSinoAndList.pl
#
# PURPOSE:  This perl script kicks off the process from the recon computer
#   to the host computer in order to obtain the necessary data files.
#   Before running this script, make sure that the CTAC series and the
#   emission data series are selected on the host. This script uses the
#   Net::Telnet module to connect to the console and determine the folder
#   names that contain the raw data. Then, the Net::FTP module is used to
#   get the files from the folders. 
#
# Inputs:
#   1st arg: Full path of the destination folder on the recon computer
#   2nd arg: Host name of the console computer (optional -
#              defaults to 10.44.22.20)\n";
#
# Example:
#   ./getRawDataSinoAndList.pl /localdata/recons bayiqpet

# Copyright (c) 2006-2010 General Electric Company. All rights reserved.
# This code is only made available outside the General Electric Company
# pursuant to a signed agreement between the Company and the institution to
# which the code is made available.  This code and all derivative works
# thereof are subject to the non-disclosure terms of that agreement.


if ( ($#ARGV < 0) || ($#ARGV > 1) || (lc($ARGV[0]) eq "help") || (lc($ARGV[0]) eq "-help") )
{
  print "\ngetRawDataSinoAndList.pl help:\n";
  print "  This perl script kicks off the process from the recon computer\n";
  print "  to the host computer in order to obtain the necessary data files.\n";
  print "  Before running this script, make sure that the CTAC series and the\n";
  print "  emission data series are selected on the host. This script uses the\n";
  print "  Net::Telnet module to connect to the console and determine the folder\n";
  print "  names that contain the raw data. Then, the Net::FTP module is used to\n";
  print "  get the files from the folders.\n";
  print "\n";
  print "  Inputs:\n";
  print "    1st arg: Full path of the destination folder on the recon computer\n";
  print "    2nd arg: Host name or IP address of the console computer\n";
  print "                (optional - defaults to 10.44.22.20)\n";
  print "\n";
  print "  Example:\n";
  print "    ./getRawDataSinoAndList.pl /localdata/recons bayiqpet\n";
  die "\n"; 
} 

$reconDataDirectory = $ARGV[0];
if ($#ARGV > 0)
{
  $host = $ARGV[1];
}
else
{
  $host = "10.44.22.20";
}
$login_name = "ctuser";
$p_word = "4\$apps";

use Net::Telnet;
$telnet = new Net::Telnet ( Timeout=>150,
                            Errmode=>'die',
                            Prompt => '/\{[a-z]+\@([a-z]|\d)+\}\[\d+] $/i');
$telnet->open($host);
$telnet->login($login_name, $p_word);

@selectionFileLines = $telnet->cmd("cat \$SDC_SELECTION_FILE");

# Check to make sure that we have two lines in the input file:
if ($#selectionFileLines != 1)
{
  die "ERROR: \$SDC_SELECTION_FILE is not working correctly.\n";
}

print "\n\n*** It is now OK to release the ImageWorks browser ***\n\n";

# The second line of the file contains the path information:
$pathline = $selectionFileLines[1];

# The two paths of interest are separated by spaces. This will divide them
# into separate array elements (one path per array element):
@paths = split(/ /, $pathline);

# Make sure that two series are selected:
if ($#paths != 1)
{
  die "ERROR: Have you selected exactly two series?\n";
}

# Find the files in each series's folder. This way we can find out which one
# is the CTAC folder and which is the emission header folder.
# Note that the back-slash on the ls command is to ensure no alias.
@firstFolderContents = $telnet->cmd("\\ls -1 $paths[0]");
@secondFolderContents = $telnet->cmd("\\ls -1 $paths[1]");

# Whichever folder has fewer files within it is declared the raw folder:
if ($#firstFolderContents > $#secondFolderContents)
{
  $ctacFolder = $paths[0];
  $headerFolder = $paths[1];
  @ctacDicoms = @firstFolderContents;
  @rawDicoms = @secondFolderContents;
}
else
{
  $ctacFolder = $paths[1];
  $headerFolder = $paths[0];
  @ctacDicoms = @secondFolderContents;
  @rawDicoms = @firstFolderContents;
}
print "CTAC folder info:\n  path: $ctacFolder\n  numfiles-1: $#ctacDicoms\n";
print "Raw folder info:\n  path: $headerFolder\n  numfiles-1: $#rawDicoms\n";

# Now, go thru each file in the raw series until one is found that points
# to the location of the raw data. When one of these is found, spit out of
# the loop with the location of that file.
foreach $tempfile (@rawDicoms) {
  $curfile = $tempfile;
  chop $curfile;

  @commandOutput = $telnet->cmd("dmfParseDicomFile -printit $headerFolder/$curfile | grep \"(   9,1062)\"");
  $commandOutput = $commandOutput[0];

  if (length ($commandOutput) > 3) # Check to make sure it's not empty
  {
    @commandOutput = split(/:/, $commandOutput);
    $commandOutput = $commandOutput[$#commandOutput];
    chop $commandOutput;
    $rawSinoFile = $commandOutput;

    # The "last" command is similar to a "break" command. After the first SINO
    # file is found, we spit out of the loop. Next we will extract the directory
    # from this SINO file path.
   last;
  }
}

# Now go from the SINO file to the actual path:
@parts = split(/\//, $rawSinoFile);
pop @parts;
$sinoFolder = join("/", @parts);

if (length ($sinoFolder) < 1)
{
  print "ERROR: Have you selected two folders, one of which is a raw emissions set?\n";
}

print("Raw Sinogram folder info:\n  path: $sinoFolder\n");


# Now, go thru each file in the raw series until one is found that points
# to the location of the list data. When one of these is found, spit out of
# the loop with the location of that file.
foreach $tempfile (@rawDicoms) {
  $curfile = $tempfile;
  chop $curfile;

  @commandOutput = $telnet->cmd("dmfParseDicomFile -printit $headerFolder/$curfile | grep \"(   9,10DA)\"");
  $commandOutput = $commandOutput[0];

  if (length ($commandOutput) > 3) # Check to make sure it's not empty
  {
    @commandOutput = split(/:/, $commandOutput);
    $commandOutput = $commandOutput[$#commandOutput];
    chop $commandOutput;
    $rawListFile = $commandOutput;

    # The "last" command is similar to a "break" command. After the first SINO
    # file is found, we spit out of the loop. Next we will extract the directory
    # from this LIST file path.
   last;
  }
}

# Now go from the LIST file to the actual path:
@parts = split(/\//, $rawListFile);
pop @parts;
$listFolder = join("/", @parts);

if (length ($listFolder) < 1)
{
  print "ERROR: Have you selected two folders, one of which is a raw emissions set with list data?\n";
}

print("List files folder info:\n  path: $listFolder\n");


# Now, go thru each file in the raw series to look for the paths of the
# correction files.
# When one is found, determine whether it is geo or cal, and save the
# filename accordingly.
foreach $tempfile (@rawDicoms) {
  $curfile = $tempfile;
  chop $curfile;

  @pathCommandOutput = $telnet->cmd("dmfParseDicomFile -printit $headerFolder/$curfile | grep \"(  17,1007)\"");
  $pathCommandOutput = $pathCommandOutput[0];

  if (length ($pathCommandOutput) > 3) # Check to make sure it's not empty
  {
    @pathCommandOutput = split(/:/, $pathCommandOutput);
    $pathCommandOutput = $pathCommandOutput[$#pathCommandOutput];
    chop $pathCommandOutput;
    $curFilePath = $pathCommandOutput;

    @typeCommandOutput = $telnet->cmd("dmfParseDicomFile -printit $headerFolder/$curfile | grep \"(  17,1006)\"");
    $typeCommandOutput = $typeCommandOutput[0];
    @typeCommandOutput = split(/:/, $typeCommandOutput);
    $typeInteger = $typeCommandOutput[1];

    if (($typeInteger == 2) || ($typeInteger == 0))
    {
      print "FILENAME: $curFilePath is type norm.\n";
      $normCalFilePath = $curFilePath;
    }
  }
}
$telnet->close;


#### NOW START FTP PORTION OF THE SCRIPT ####
# This portion of code will retrieve all the files within the four 
# directories: $ctacFolder, $headerFolder, $sinoFolder, & $listFolder.
# The files will be placed in subfolders within the folder names
# specified below.

use Net::FTP;

@console_folders = ( $sinoFolder, $listFolder, $ctacFolder, $headerFolder );
@recon_folders =   ( "rawSino",   "rawList",      "CTAC",      "dicom" );

@console_cal_files =   ( $normCalFilePath );
@recon_cal_filenames = ( "norm3d"         ); 
$calFolderName = "calFiles";

$ftpobj = Net::FTP->new($host,Timeout=>600)
  or die "ERROR: Cannot connect to FTP host: $host; $@";
$ftpobj->login($login_name, $p_word)
  or die "ERROR: Cannot login to ftp host: $host";
$ftpobj->binary();

if ((-e $reconDataDirectory) ne "1")
{
  $commandrun = "mkdir $reconDataDirectory";
  `$commandrun`;
}

for ($i = 0; $i <= $#console_folders; ++$i)
{
   
  if (length ($console_folders[$i]) > 1) # Check to make sure it's not empty
  { 
    $status = $ftpobj->cwd( $console_folders[$i] );
    if ($status ne "1")
    {
      $ftpobj->quit;
      die "ERROR: specified folder does not exist: $console_folders[$i]\n";
    }

    # Get the file listing:
    @curFileList = $ftpobj->ls;

    # Create the directory if necessary
    if ((-e "$reconDataDirectory/$recon_folders[$i]") ne "1")
    {
      $commandrun = "mkdir $reconDataDirectory/$recon_folders[$i]";
      `$commandrun`;
    }

    # Loop through each file in the current folder and "get" it
    for ($j = 0; $j <= $#curFileList; ++$j)
    {
      $ftpobj->get($curFileList[$j], "$reconDataDirectory/$recon_folders[$i]/$curFileList[$j]");
    }
  }
}

if ((-e "$reconDataDirectory/$calFolderName") ne "1")
{
  $commandrun = "mkdir $reconDataDirectory/$calFolderName";
  `$commandrun`;
}

for ($i = 0; $i <= $#recon_cal_filenames; ++$i)
{
  $ftpobj->get($console_cal_files[$i], "$reconDataDirectory/$calFolderName/$recon_cal_filenames[$i]");
}

# Close ftp object
$ftpobj->quit;

