% FILE NAME: sortRawData_tof.m
%
%  syntax:
%  [dicomrdfname,nframes,frameoffset]=sortRawData_tof(pwd(), 'rawDicom', filename,skipRDFWrite,addedUnlistOptions);
%
%
% Inputs
%     directory           The main working directory of the image set.
%     dicomdir            The subdirectory (within "directory" that contains
%                            the raw dicom headers
%     filename            The filenames of the dicom headers (such as *RPDC*)
%                            (non-TOF) volpet format.
%     skipRDFWrite        Set to 0 or 1:
%                           0 - This function will write RDF's (recommended)This
%                           1 - function will not write RDF's (special use)
%     bin_count           the number of timing bins (must be odd integer,
%                           and will likely be approximately 69)
%     useRDFRawData       Set to 1 for no-list-mode operation.
%     addedUnlistOptions  Additional options for kh2vptof.c (like gating support)
%
%   OUTPUT
%       dicomrdfname
%       nframes  :   number of raw data frames in dicom set
%	    frameoffset:  difference in start location between frames (used for overlap)
%       studyID : the study ID header parameter
%

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%  Mar 20,2007      RMM    Modified call to kh2vptof to include a start time 
%                           unlisting the event stream
%  2007-Apr-19      CWS    Changes for PC operation (file separators and dictionary name)
%                
% Changed many of these lines to use filesep instead of '/' for smoother PC operation
% 19Apr2007 CWS
%
%  2007-Sep-27      CWS    Added addedUnlistOptions for gating support
%
%  2008-Dec-01      TWD    Replaced several Private fields with their newly
%                          updated Dicom tag names in pet-dicom-dict.txt

