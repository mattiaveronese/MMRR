%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  image=tofosem(emissFile,multFile,addFile,...
%                 nx,nz,sx,...
%                 nBlocks,nXtals,blkSize,...
%                 varargin)
%
% Time-of-Flight OSEM recon with an additive randoms estimate
%
% Inputs:
%     emissFile           Emission TOF file, in volpet-TOF format.
%     multFile          	All multiplications for OSEM (ACF/(norm*dead*decay); 
%     acfFileName			ACF Only (used for detector response)	
%	  normdeadFilename		norm*dead (used for detector response)
%     scatEstimate        (3 arguments) Information necessary for scatter
%                           correction:
%                             scatEstimateFile: The file containing the
%                               mostly downsampled scatter array in savefile
%                               format
%                             scatNormFile: The file containing the norm
%                               and deadtime corrections to be applied
%                               (multiplicatively) to the scatter estimate.
%                               Note that this includes the scatter
%                               upsample factors.
%                             mbscParams4recon: structure with mbsc related
%                             parameters
%                               nXtals: The number of crystals in the
%                               model detector ring (needed to upsample).
%                               scatTailFactors: scatter tailscale factors
%                               (553, 1) or (553, 2)
%                               isRb : FDG or Rb - needed for scatter
%                               scaling
%   addFile             Additive correction file, in conventional
%                            (non-TOF) volpet format.
%   keyhole             (+ 2 arguments) Use a keyhole image for correction
%                           of out-of-DFOV activity.   Arguments are:
%                             keyholeFile: Filename containing keyhole image
%                             keyholeParams: Parameter structure with
%                               needed info
%	decayMultFactor			Array of decay values
%   terse               (no argument) Reduce printed messages.
%   saveIterations      Name of a file into which the result after
%                           each iteration is to be saved.
%                            (non-TOF) volpet format.
%   saveNorm            Name of the file into which the normalization
%                           images are to be saved.  Useful with useNorm
%                           to avoid re-calcualting the normalization
%                           images for mutliple reconstructions.
%	reconParams				reconParams structure. Values used are:
%
%     	numSubsets          Number of subsets.
%     	numIterations       Number of iterations.
%		FOV
%		timeMash
%     	tRes                Timing resolution, in ns (default is read from
%                           volpet-TOF file).
%     	nx                  Number of output pixels in x- and y-directions.
%		detectorResponseFlag	On/off for detector response
%		detectorResponseAxialFlag On/off for axial detector response
%		detectorResponseAxialFactor Amount of smoothing in axial direction (used 
%								in smoothAxialPlanes)
%		detectorResponseFile  	.mat file containing detResponseConvMtx
%     	xOffset             X-coordinate of image center in (x,y,z) space
%                           (default=0).
%     	yOffset             Y-coordinate of image center in (x,y,z) space
%                           (default=0).
%     	zRotation           Rotation of first sinogram row with respect to
%                           x-axis (default=0)
%
%	acqParams			acqParams structure. Values used are:
%		nZ				number of slices in frame
%     	tLSB                Timing LSB, in ns (default is read from
%                           volpet-TOF file).
%		dT
%		nU,nV,nPhi			sinogram size (radial, axial, phi angle around gantry)
%     	timeMashFirstBinDiscount   If time mashing did not evenly divide
%                               	original coincidence window, this is the
%                               	fraction of the frist and last bins that
%                               	are mising (default=0).
%
%	scanner				scanner structure
%     nBlocksPerRing             Number of blocks around the detector ring.
%     numBlocksPerRing           Number of creystals per block
%     radBlockSize             Transaxial dimension of block
%	  effectiveRingDiameter
%
%     initImage           A 3-D array representing the initial image
%                           to be used in reconstruction.  This is
%                           useful in restarting a reconstruction.
%     saveSubsets         Name of a file into which the result after
%                           each subset is to be saved.  Note that this
%                           file may be large, as it will contain
%                           numSubsets*numIterations*nx^2*nz floats.
%     sigmas              Size of TOF kernel, in units of FWHM (def: +/-3).
%     silent              (no argument) Supress all printed messages.
%     thetaLimit          Maximum axial angle to accept
%                             (0 = Hi-res only; 2 corresponds to dZ = +/-5).
%     timeMash            Timing mashing factor (default: no timing mashing).
%     useNorm             Name of file containing normalization images to
%                           be used in reconstruction (see saveNorm, above).
%     wtStep              Timing steps in TOF table, in distace units
%                           (default=0.1),

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%  History (see OpenGE for details)
%     v1.0   CWS    Initial release to pettoolbox
%     27Feb2007 cws Update with scatter correction, algorithm design per
%                         flowchart version 7.
%     04Sep2007 cws Added thetaLimit
%     04Apr2008 cws Added support for v7 RDF TOF
%     18Apr2008 cws added keyhole support
%     21Jun2008 RMM
%              (1) Accept mbscParams4recon strucutre instead of scatMBSCxtals
%                   mbscParams4recon contains the following fields
%                   nXtals:  Number of detectors in down-sampled geometry of SSS
%                   scatTailFactors: scatter scale (and offset factors)
%                   isRb: Flag to determine to determine of offset factors
%                           need be applied
%                   multFraction: Multiple scatter fractions
%                   multSigma: Multiple scatter kernel width
%               (2)Build the un-normalized scatter offset factors 
%                   Added capability to do Y = AX + B scatter model for  Rb
%    23Jul2008 RMM/CWS
%               mbscParams4recon brings the average geocalFactors with it
%               Since scatNormArray passed to tofosem has geoCalFactors, in
%               the construction of scatOffsetFactors geoCalFactors is
%               divided out (removed)
%    25Jul2008 CWS Reverted to LUT implementation of TOF weights, per
%               request by RreEcon software team.
%	  
%	 03Feb2010 SGR Change to API. Now pass reconParams, acqParams, and scanner 
%					structures. Added detector response support. 
%   02Sep2010 TWD Replace "triang" with "GEtriang"

