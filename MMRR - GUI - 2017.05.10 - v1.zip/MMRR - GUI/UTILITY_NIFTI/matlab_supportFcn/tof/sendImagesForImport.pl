#!/usr/bin/perl
# ==================================================================%
# FILE NAME: sendImagesForImport.pl
#
# PURPOSE:  This perl script uploads the specifed files to the host's
#   /usr/g/sdc_image_pool/import directory. This script uses the
#   Net::FTP module to perform the data transfer. This is used to add
#   dicom images to the host image viewer.
# 
# Inputs:
#   1st arg: Host name of the console computer
#   2nd arg: Images to upload to the recon computer (use wildcards)
# 
# Example:
#   ./sendImagesForImport.pl bayiqpet /localdata/recons/*sdcopen

# Copyright (c) 2006-2010 General Electric Company. All rights reserved.
# This code is only made available outside the General Electric Company
# pursuant to a signed agreement between the Company and the institution to
# which the code is made available.  This code and all derivative works
# thereof are subject to the non-disclosure terms of that agreement.

# History:
# DEVELOPER: Tim Deller
# DATE: Nov 27, 2006

if ( ($#ARGV < 1) || (lc($ARGV[0]) eq "help") || (lc($ARGV[0]) eq "-help") )
{
  print "\nsendImagesForImport.pl help:\n";
  print "  This perl script uploads the specifed files to the host's\n";
  print "  /usr/g/sdc_image_pool/import directory. This script uses the\n";
  print "  Net::FTP module to perform the data transfer. This is used to add\n";
  print "  dicom images to the host image viewer.\n";
  print "\n";
  print "  Inputs:\n";
  print "    1st arg: IP address or host name of the console computer\n";
  print "    2nd arg: Images to upload to the recon computer (use wildcards)\n";
  print "\n";
  print "  Example:\n";
  print "    ./sendImagesForImport.pl 3.87.140.215 /localdata/recons/*.sdcopen\n";
  die "\n";
}


$host = $ARGV[0];
@filesToUpload = @ARGV;
shift( @filesToUpload ); # Remove the first entry of this array, which is the host.
# print "\nFILES\n@filesToUpload\n\n";

$login_name = "ctuser";
$p_word = "4\$apps";

use File::Basename;
use Net::FTP;
$ftpobj = Net::FTP->new($host,Timeout=>300)
  or die "ERROR: Cannot connect to FTP host: $host; $@";
$ftpobj->login($login_name, $p_word)
  or die "ERROR: Cannot login to ftp host: $host";
$ftpobj->binary();

$status = $ftpobj->cwd( "/usr/g/sdc_image_pool/import" );
if ($status ne "1")
{
  $ftpobj->quit;
  die "ERROR: specified folder does not exist: $console_folders[$i]\n";
}

# Make sure that all inputs are files. This is a separate "for" loop from the
# uploading "for" loop to prevent a partial file transfer.
for ($i = 0; $i <= $#filesToUpload; ++$i)
{
  if ((-f $filesToUpload[$i]) ne "1")
  {
    die "ERROR: The input must be a file list (wildcards acceptible). No directories should be input.";
  }
}

srand();
my $range = 10000000;
my $random_number = int(rand($range));

# Now, upload all files. Do simple error checking to make sure that it works.
for ($i = 0; $i <= $#filesToUpload; ++$i)
{
  ($curName, $curPath, $curSuffix) = fileparse($filesToUpload[$i]);

  $status = $ftpobj->put($filesToUpload[$i], "$curName.$i.$random_number.sdcopen");
  if (length($status) <= 0)
  {
    die "ERROR: transfer not successfull for $filesToUpload[$i] : partial transfer possible.\n";
  }
}

printf("A total of %i files successfully uploaded to %s\n", $#filesToUpload+1, $host);

