%
% THIS FILE HAS BEEN MADE OBSOLETE BY THE DEVELOPMENT OF siddon3D.cpp, WHICH
% IMPLEMENTS THE SIDDON PROJECTORS FOR TOF AND NON-TOF SCATTER CORRECTION.  THIS CODE
% MATCHES THE OUTPUT OF siddon3D.cpp v1.7 ON 25 FEB 2011, BUT THERE IS NO GUARANTEE
% IT WILL BE MAINTAINED BEYOND THAT DATE.

%  [SiddonLineIntegrals, ptrMatrix, dlList] =
%           tofSiddon3D(intensity,scanner, mbscParams, acqParams)
%
% Generates Siddon Ray integrals and returns Matrix with distnces of
% emmiting points from Scatter and weighted intensity of incident voxels
% with length of intersection
%
% Inputs
%     intensity         3D image volume
%     scanner           Structure defining scanner parameters
%     mbscParams        Structure with mbsc parameters
%     acqParams         Structure with projection relate parameters
%
% Outputs
%   SiddonLineIntegrals Line integrals of intensity from each voxel in
%                       intensity volume to each detector. Typically has
%                       dimensions of nZ x nx x ny x nZ x nDets
%   ptrMatrix           dimensions of (nZ x nx x ny x nZ x nDets, 2)
%                       for each row, the first element contains the address
%                       in dlList and the second element contains the number of
%                       pixels intersected by the ray from the current
%                       voxel to current detector
%   dlList              List of intersection length of ray (from voxel to 
%                       detector) with pixels in its path.
%                       List of product of intersection lenght and pixel
%                       intensity

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%     v1.0      MI      Initial release to pettoolbox - was named
%                       New_all_Siddon_3D.
%     27Mar2007 RMM     Updated to correct for universal conventions and
%                       transpose referencing of matlab. 
%                       Renamed to tofSiddon3D.m
%     21Jun2008 RMM     Accepting dsAcqParams and dsImParams as input
%                       instead of building it

