% FILE NAME: buildMBSCparamsTOF.m
%
% DEVELOPER: Tim Deller / Chuck Stearns
%
% PURPOSE: This functions builds the model-based scatter corrections parameter
% structure.
%
% INPUTS:  None yet, but there probably should be.
%
% OUTPUT:  mbscParams

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%     2007-03-02 - initial creation

% IMPROVEMENT NEEDED: Un-hardcode some of the parameters that should come from
% the data.


% Scatter model parameters
