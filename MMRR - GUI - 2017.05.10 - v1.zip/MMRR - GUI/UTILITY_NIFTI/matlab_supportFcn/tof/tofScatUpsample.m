%  scatter=tofScatUpsample(dsScatter,nZ,nPhi,sV)
%
%  Performs scatter upsampling in u and v-theta
%  for scatter estimate at a particular value of
%  (already upsampled) phi.
%
%  Inputs: dsScatter         nZ*nU*nZ downsampled scatter array.
%          radialLocations   Target U positions in upsampled array.
%          nZ                Upsampled axial slice count.
%          sV                Plane spacing upsampled planes.
%          nPhiDS            Total number of phi (upsampled).
%          ringDiameter      Detector ring diameter.
%
%  Output      scatter    nVth*nU upsampled scatter array

% Copyright (c) 2008-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% Stolen liberally from dsSinoUpsample3d.m
% Aug 18, 2008  RMM     Removed the transpose after upsampling from 4x4 to
%                       24x24. Currently, TOF and NON-TOF are consistant.

%% Get downsampled data dimensions
% tic
