% Initialize recon parameters structure required for petrecon_tof functions.
%
% FILE NAME: petrecon_tof_params.m
%
% PURPOSE:  Initialize recon parameters structure required for  petrecon_tof functions.
%
% INPUT:  none

% Copyright (c) 2009-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% DEVELOPER: Tim Deller
%     2007-Jan-22 Initial commit (not yet complete)
%     2007-Feb-27 Major overhaul of code (TD)
%     2009-Apr-15 MWD Major overhaul of code, file changed to
%       script instead of function to allow one input method to
%       petrecon_tof.m
%     2009-Jul-30 MWD Added keepIterationUpdates parameter.
%     2010-Oct-05 SGR Added PIFA parameters to support petrecon_makePIFAs().

%INPUT FILENAMES

%Change the following parameters
reconParams.FOV=700;
reconParams.numSubsets = 24; 
reconParams.numIterations = 2;
reconParams.keepIterationUpdates = 0;
reconParams.zfilter = 0;  % Center weighted for 3-point center weighted averager.

reconParams.dicomImageSeriesNum = 501;
%reconParams.unlistStartDuration_mSec = 0; % Legacy from CC recon
%reconParams.unlistEndDuration_mSec = -1;  % Legacy from CC recon
reconParams.nx = 128;
reconParams.ny = 128;
%reconParams.nz = 47; %Never gets used?
reconParams.postFilterFWHM = 0;         % FWHM for gaussian post filter, Units: mm
reconParams.xTarget = 0;		%Units: mm
reconParams.yTarget = 0;		%Units: mm
reconParams.keyholeFlag = 0;
reconParams.useCorrFlag = true;
reconParams.attenuationFlag = true;
reconParams.scatterFlag = true;
reconParams.deadtimeFlag=true;
reconParams.decayFlag = true;
reconParams.badSpotsCorrectionFlag = false;
reconParams.randomsFlag = true;
reconParams.normalizationFlag = true;
reconParams.PIFAfromCTFlag         = 1; % Set to 1 to generate PIFAs from CT images (most common)
reconParams.PIFAfromProductFlag    = 0; % Not supported with TOF reconstruction
%reconParams.CTACconvFile           ='ctacConvScale.cfg' ;  % DST DSTE DRX DVCT
reconParams.CTACconvFile           ='ctacConvScale_rev5.cfg' ;  % D600 D690
reconParams.dicomImageSeriesDesc =['TOF' ...
        '_se' num2str(reconParams.dicomImageSeriesNum) ...
        '_fov' num2str(reconParams.FOV) ...
        '_p' num2str(reconParams.postFilterFWHM) ...
        '_z' num2str(reconParams.zfilter) ...
        '_sub' num2str(reconParams.numSubsets) ...
        '_iter' num2str(reconParams.numIterations)];

% CT/PET Motion compensation follows.
%    0: No scatter tail caps;
%    > 0: Global Scale Cap (eg, 1.5)
reconParams.globalScatterCap = 0;

%--------------------------------------------------------------------------
%The following parameters are rarely edited
reconParams.dir=[pwd() '/'];  % Must be in data directory to run code!
reconParams.writeDicomImage = true;  %Set to 1 if writing dicom files
reconParams.imOutFilename= [reconParams.dir 'ir_tof'];  %floating point output filename
reconParams.CTACSinoFlag = false;
reconParams.emFilenameVPTOF = [reconParams.dir 'vptof'];
reconParams.normdeadFilename = [reconParams.dir 'normdead'];
reconParams.randomsFilename = [reconParams.dir 'randoms'];
reconParams.dsScatterFilenameTOF = [reconParams.dir 'dsTOFscatterUpPhi.tof'];
reconParams.attenFilename     = [reconParams.dir 'attenOnly']; % Attenuation only
reconParams.normProcFilename=[reconParams.dir 'norm3d.proc'];
reconParams.scatterNormFilename=[reconParams.dir 'scatternorm'];
reconParams.multFilename     = [reconParams.dir 'multMatrix']; % entire Multiplicative matrix
reconParams.keyholeImgFilename  = [reconParams.dir 'keyholeImg'];  	
reconParams.inputFilename=[reconParams.dir 'rdf'];
reconParams.normRawFilename=[reconParams.dir 'norm3d'];
reconParams.wcc3dFilename=[reconParams.dir 'wcc3d'];
reconParams.geoCalFilename=[reconParams.dir 'geoCal3d'];

reconParams.tRes = 675;
reconParams.reconSigmas = 3;
reconParams.timeMash=1;

%Switch these values for gating
%useGating=false;
%gatingFile = [];
%gatingBinNumber = [];

deleteTemp = false;

%addedUnlistOptions=' ';

useRDFRawData=false;

%config_params.bin_count = 75;

if (~reconParams.attenuationFlag && reconParams.scatterFlag)
    error('Scatter cannot be chosen if attenuation is off.');
end

reconParams.detectorResponseFlag = 0;   %Set to 1 to invoke detector response in reconstruction
reconParams.detectorResponseAxialFlag = 1; %Only used if detectorResponseFlag = 1
reconParams.detectorResponseAxialFactor =[4]; 
reconParams.detectorResponseFile = 'detectorResponseMatrix.XR.mat';

