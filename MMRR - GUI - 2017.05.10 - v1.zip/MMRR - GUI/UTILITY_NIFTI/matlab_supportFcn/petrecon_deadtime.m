% Estimate deadtime from an RDF
% Usage:
% deadtime=petrecon_deadtime(rdf, reconParams);
% Currently, only deadtimeFlag is the only field used from reconParams
% TODO only 3D.

% Copyright (c) 2011 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

