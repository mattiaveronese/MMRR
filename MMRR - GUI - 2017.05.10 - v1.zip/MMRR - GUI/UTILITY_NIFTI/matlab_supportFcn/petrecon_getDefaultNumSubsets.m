% Return the default number of subsets for a particular scanner
% USAGE
%    numSubsets=petrecon_getDefaultNumSubsets(scanner);
% INPUT
%   scanner:    a structure as returned by petrecon_scanner
% OUTPUT
%   numSubsets: integer
%
% Note: defaults on the console could be protocol dependent. This function is just for convenience

% Copyright (c) 2010-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   May 2010 Kris Thielemans
%       Created
% CVS Version info: $Revision: 1.2 $, $Date: 2010/10/04 22:14:14 $


