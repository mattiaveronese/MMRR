% FILE NAME: readSingles.m
%% -----------------------------------------------------------------------%
% Inputs:
%	filename: binary file to be read
%   rawSingles: variable from header that has singles raw data 
%	type: data type of file
%		int8, uint8, int16, uint16, int32, uint32
%	int64, uint64, float, double 
%	endian: 'l', or 'b'
%	skip: offset in file
% singles: data array of imSize containing 
%
%	Example: read uint16  raw sinogram of size (249,210,47)
%		 little endian with an offset of 9084 bytes
%   
%   If reading data from file:
%	singles=readSingles('singles.dat',[],'uint32','l',0,'rw');
%
%   If reading data from header variable:
%	singles=readSingles([],singles,'uint32','l',0,'rw');
%
% Old Call:function  singles = readSingles(filename,imSize,type,endian,skip,configuration)

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

