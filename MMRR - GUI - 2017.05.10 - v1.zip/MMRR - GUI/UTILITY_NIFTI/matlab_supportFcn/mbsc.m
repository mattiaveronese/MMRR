% FILE NAME: mbsc.m
%
% mbsc.m
%   this is the main function that performs the model based scatter
%   estimation.
%
%   syntax
%       scatter3d = mbsc(emSinoFname, ctacFname, acqParams, imParams, mbscParams);
%  
%   Inputs
%       emSinoFname -   Randoms corrected prompts projection plane 
%       ctacFname   -   CTAC data 
%       acqParams   -   Structure defining sinogram dimensions and
%                       other acquisition parameters
%       imParams    -   Structre with image dimensions
%       mbscParams  -   Structre with parameters for MBSC 
%
%   Output
%       scatter3d   -   3D projection plane with scatter estimate

% Copyright (c) 2004-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   06/15/2004      -   written by Ravi Manjeshwar 
%   02/24/2005      -   Modified to make parallel to product implementation
%                       Changed recon from pre-computed projectors to DD based
%                       recon
%   04/25/2005      -   Moved parameter definitions to mbscBatch.m



% Memory allocation
