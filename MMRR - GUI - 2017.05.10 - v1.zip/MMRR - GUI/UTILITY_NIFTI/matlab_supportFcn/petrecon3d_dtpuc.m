% FILE NAME: petrecon3d_dtpuc.m
%
% DEVELOPER: Albert Lonn 
%
% PURPOSE:  This function returns an estimate of  deadtime and pile up
%           generated in deadtimePuc3d
%
% USAGE:     deadtime=petrecon3d_dtpuc(rdf)
%            rdf is the rdf structure 
%            if present,  xtal params are read from rdf file ( ver7.1) 
%          .. if not,  params are read from 
%          .. standard machine file such as puc_xfactors.DXA
% if you add ~/pettoolbox/recon/matlab/PUCconfig to the matlab PATH
%
%ALTERNATE USEAGE:deadtime=petrecon3d_dtpuc(rdf, pucfilename)
%  Optionally the xtal parameters can be read from a user defined file        
%          ..if present, pile up params are read from pucfilename

% Copyright (c) 2008-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% 17Nov 08    AL  changed nx ny nz to nu nv nphi in read from raw

%% SET UP and read optional arguments
