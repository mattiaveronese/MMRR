%  This function generates the 2D CTAC from a 3D image set 
%  by forward projection. 
%
%   Syntax:
%       ctac = muImg2ctac2d(muImg, acqParams, pifa);
%       ctac = muImg2ctac2d(muImg, acqParams, pifa, xOffset, yOffset, rotation);
%
%   Inputs:
%       muImg               -   3D image set of linear attenuation
%                               co-efficients at 511 KeV in units of 1/mm
%       acqParams           -   Structure defining projPlane dimension
%       pifa            -   	Structure defining pifa image dimension
%       xOffset             -   offset images along x-axis by xOffset, Units: mm
%       yOffset             -   offset images along y-axis by yOffset, Units: mm
%       rotation            -   The angle of the first projection. This is
%                               an optional parameter, if unspecified it is
%                               set to 0.
%
%   Outputs:
%       ctac                -   CTAC projection plane
%                               ctac = exp(-mu*x);

% Copyright (c) 2004-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   11/16/2004   Written by RMM
%   11/17/2004   Added the option for rotation


% If pifa is not passed, recon muImg on 700mm FOV
