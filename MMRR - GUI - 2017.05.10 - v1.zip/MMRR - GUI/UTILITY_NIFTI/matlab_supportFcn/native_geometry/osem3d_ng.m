%  3D-AW-OS-MLEM
%
%   Syntax:
%       reconImg = osem3d_ng('emFilename',emFilename, ...
%                   'scatterFilename',scatterFilename, ...
%                   'randomsFilename',randomsFilename, ...
%                   'keyholeFilename',keyholeFilename, ...
%					'multFilename',multFilename, ...
%					'acfFilename',acfFilename, ...
%					'normdeadtimeFilename',deadtimeFilename, ...
%                   'acqParams',acqParams, ...
%                   'reconParams',reconParams, ...
%                   'imOutFilename',imOutFilename, ...
%                   'scanner',scanner,...
%                   'durationMultFactorArray', durationMultFactorArray, ...
%                   'decayMultFactorArray', decayMultFactorArray);
%
%
%   Inputs:
%       emFilename          -   filename for prompts (T+S+R) projection planes
%       scatterFilename     -   filename for scatter  projection planes
%       randomsFilename     -   filename for randoms projection planes
%       keyholeFilename     -   filename for cutout keyhole projection planes
%		multFilename 		-	filename for multplicative correction factors (ctac/(norm*dead*decay))
%		acfFilename			-	filename for acfOnly projection plane (used for detector response)
%		normdeadFilename	-	filename for norm*dead projection plane (used for detector response)
%       acqParams           -   Structure defining projPlane dimension
%                               (See ir3d.m for definition)
%       reconParams         -   Structure defining reconstruction
%                               parameters (See ir3d.m for definition)
%       imOutFilename       -   Filename for output image (required to
%                               store intermediate results. Intermediate
%                               results stored with suffixes:
%                               filename.'N'i'n'.'K's'k'
%                               where
%                               N: number of iteration, n: current iteration
%                               K: number of subsets, k: current subset)
%       scanner             -   Structure that includes geometry information
%                               and other factors
%
%   Outputs:
%       currentImgFull      -   Reconstructed image volume

% Copyright (c) 2007-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   06/25/2004   Written by RMM
%   06/26/2004   ACFsubset images are generated prior to
%                entering the iterative loop
%                startAngle initialization
%   07/19/2004   Changed subsetAngles to subsetAngles+1
%                (genOsemIndex changed to give subset indices
%                from 0-20 instead of 1-21. rp.c and bp.c
%                like 0-20)
%   07/28/2004   Based on correction flags for scatter, randoms or
%                attenuation, perform these corrections prior to the
%                iterative loop, in the iterative loop or not at all.
%   08/03/2004   Function osem3d_no_overlap for optional
%                overlap correction. The sequence of loops with and without
%                overlap correction are different. Therefore two separate
%                functions.
%   11/15/2004   (1) Renamed osem3d_no_overlap to osem3d
%                    Overlap correction is performed in the image domain
%                (2) Works with distance_driven projector pair
%                (3) Reordering of images and projection data for distance
%                    driven projector is handled inside the projector function.
%                    It is removed from the m-file

% Parse optional parameters
