function reconImg=petrecon3d_ng(varargin)
% 3D reconstruction (native geometry)
% Usage:
%  reconImg=petrecon3d_ng
% or
%  reconImg=petrecon3d_ng(reconParams)
%
% FILE NAME: petrecon3d_ng.m
%
% PURPOSE:  This is the main wrapper program for 3D reconstruction.
%
% INPUTS:  Input files and reconstruction parameters are read from
% a reconParams structure. If no arguments are specified, this will
% be set by reading petrecon3d_params.m (found by using the matlab
% path).
% Warning: following doc is incomplete. It does not mention dicom for
% instance. See petrecon3d_params.m in the pettoolbox for more info.
%
%       inputfiles required are:        reconParams.inputFilename: emission 3d rdf
%                                       reconParams.normFilename: 3d crystal efficiency (norm)
%
%       reconParameters required are:   reconParams.randomsFlag
%                                       reconParams.deadtimeFlag
%                                       reconParams.normalizationFlag
%                                       reconParams.scatterFlag
%                                       reconParams.attenuationFlag
%
%                                       imParams.FOV  (reconstruction FOv)
%                                       imParams.nx   (reconstruction image x number of pixels)
%                                       imParams.ny   (reconstruction image y number of pixels)
% Optional parameters are used for filenames etc
% Use reconParams.cleanupIntermediateFiles to delete intermediate files
% (0 deletes nothing, 3 deletes most/all volpet files, 1,2 are in between these two extremes
%

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
% DEVELOPER: Steve Ross, Modified for native geometry by Tim Deller
%   06/19/08    RMM Storing geoCalFactors in a *.sav file and passing it to
%                   petrecon3d_scatter3d()
%   24Jun08    AL change to include optional crystal puc
%   11Dec08    TD - changed to double precision sums
%   23Feb09    TD - modified z-filtering to un-bias outside slice
%   Aug09      KT - moved x/yOffset code to petrecon_setXYOffset, 
%                 - call petrecon_postfilter
%                 - add optional field reconParams.cleanupIntermediateFiles
%                 - corrected bug in multi-bed case when reconFlag=0, but writeDicomImage was on. We were
%                 only writing 47 slices.
%   15Dec09    CWS - Added support for S/I ACQC
%   17Jun10     - Added support for geo correction
%   02Sep10    TWD - Replaced triang with GEtriang

%INITIALIZE RECONSTRUCTION PARAMETERS
if (isempty(varargin))
    disp(['Reading reconParams from' which('petrecon3d_params')]);
    rehash
    petrecon3d_params
else
    reconParams=varargin{1};
end

if ~isfield(reconParams,'acqcS')
    reconParams.acqcS=0.0;
end
if ~isfield(reconParams,'acqcL')
    reconParams.acqcL=0.0;
end
if ~isfield(reconParams,'acqcP')
    reconParams.acqcP=0.0;
end

if (~isfield(reconParams,'normdeadFilename'))
  reconParams.normdeadFilename=fullfile(reconParams.dir,'normdead.vp');
end
if (~isfield(reconParams,'normProcFilename'))
  reconParams.normProcFilename=fullfile(reconParams.dir,'norm3d.proc.vp');
end
if (~isfield(reconParams,'multFilename'))
  reconParams.multFilename=fullfile(reconParams.dir,'multMatrix.vp');
end

if (~isfield(reconParams,'scatterFractionFilename'))
  % set scatterFractionFilename
  % note: use full filename (including .mat) to let
  %    exist(scatterFractionFilename,'file') work
  if (reconParams.scatterFlag == 1)
    reconParams.scatterFractionFilename=fullfile(reconParams.dir,'scatterFraction.mat');
  elseif (reconParams.scatterFlag == 2)
    reconParams.scatterFractionFilename=fullfile(reconParams.dir,'scatterFraction3d.mat');
  end
end

if (~isfield(reconParams, 'globalScatterCap'))
  reconParams.globalScatterCap=0;
end

if (~isfield(reconParams, 'cleanupIntermediateFiles'))
  reconParams.cleanupIntermediateFiles=0;
end

% first set preprocess flags to 0 if we don't need the correction at all
if (reconParams.scatterCorrFlag == 0)
    reconParams.scatterFlag=0;
end
if (reconParams.acfCorrFlag == 0)
    reconParams.attenuationFlag=0;
end

% If raw data is in the form of DICOM files, sort DICOM files and write 
% RDF's, if desired.
% NOTE: If input data is coming from a nonDICOM source, it is the
% responsibility of the user to (1) provide reconParams fields nFrames,
% overlap and inputFilename, plus variable dicomrdfname (if DICOM output is 
% desired) for subsequent processing, (2) provide nFrames RDF files with 
% names inputFilename.0, inputFilename.1, etc., properly sequenced for 
% overlap, (3) provide a properly-named normalization RDF, and (4) provide a 
% properly-named well counter file (Nslices slice factors plus one global 
% scale factor). Also, note that DICOM output is not possible without DICOM input.
% (New comment 25 Feb 2010 by CWS)
if (reconParams.rawFromDicom == 1)

    [dicomrdfname,reconParams.nFrames,frameoffset]=sortRawDicom([reconParams.dir], 'dicom/','*RPDC*',0);

    if (reconParams.nFrames==0)
        error('Number of frames is zero');
    end
    reconParams.inputFilename=fullfile(reconParams.dir,'rdf');


    if frameoffset
        % New 26 Feb 2010 CWS: Need to read, not assume, slice spacing & nZ
        rdf=readRDF([reconParams.inputFilename '.0']);
        nz=2*rdf.sharc_rdf_sys_geo_data.axialCrystalsPerBlock...
            *rdf.sharc_rdf_sys_geo_data.axialBlocksPerModule-1;
        sv = 0.5*(rdf.sharc_rdf_sys_geo_data.detectorAxialSize / ...
                (rdf.sharc_rdf_sys_geo_data.axialCrystalsPerBlock...
                   *rdf.sharc_rdf_sys_geo_data.axialBlocksPerModule));
        reconParams.overlap = round(nz-abs(frameoffset)/sv);
        fprintf('Overlap of %d slices determined from data.\n',reconParams.overlap);
        clear rdf;
    else
        reconParams.overlap = 0;
    end
end

if (~isfield(reconParams,'normFilename'))
  reconParams.normFilename=fullfile(reconParams.dir, 'norm3d');
end
if (~isfield(reconParams,'wcc3dFilename'))
  reconParams.wcc3dFilename=fullfile(reconParams.dir, 'wcc3d');
end
if (~isfield(reconParams,'geoCalFilename'))
  reconParams.geoCalFilename=fullfile(reconParams.dir, 'geoCalFactors.sav');
end

% generate CTAC/PIFA files only if we are doing scatter and/or attenuation correction
% Note 20Oct09 CWS: ACQC CTAC shift in S-I direction information is
%                     passed to petrecon_makePIFAs through reconParams.acqcS;
if (reconParams.scatterFlag || reconParams.attenuationFlag)
    if reconParams.CTACSinoFlag
        sortCTACSino(reconParams.dir,'CTACSino/','*RPDC*',0);
    else
        reconParams=petrecon_makePIFAs(reconParams);
    end
end % if (reconParams.scatterFlag || reconParams.attenuationFlag)

% CORRECTIONS PROCESSING
for frameNum=1:reconParams.nFrames
    fprintf('\nCorrection processing for Frame %d of %d\n',frameNum,reconParams.nFrames);

    %  READ EMISSION RDF
    fprintf('Reading emission RDF\n');
    rdf=readRDF([reconParams.inputFilename '.' num2str(frameNum-1)]);
    % Note that if this is a v7 or greater file, readRDF didn't read the segment data
    if rdf.sharc_rdf_config.fileVersion.majorVersion >=7
        rdf.seg2Data = readNonTOFfromRDFv7([reconParams.inputFilename '.' num2str(frameNum-1)]);
    end

    % PARAM SETUP: First time through, set up scanner, and acqParams structures
    %   (previously built in DST(E/RX)scanner.m) and check subset choice.
    if (frameNum==1)
        scanner=petrecon_scanner(rdf);
        acqParams=petrecon_acqParams(rdf);
        if mod(rdf.nphi, reconParams.numSubsets),
            error('Reconstruction requires number of subsets evenly divide sinogram height.');
        end
        reconParams = petrecon_detectorResponseParams(reconParams, scanner);
    end

    %  Assign sino to rdf.seg2Data and clear the segment from the structure
    writevp([reconParams.emFilename '.ng3d.' num2str(frameNum-1)],single(rdf.seg2Data),acqParams,scanner);
    rdf = rmfield(rdf,'seg2Data');
    fprintf('Finished reading emission RDF and writing segment data to flat file.\n');

    % DECAY
    if (reconParams.decayFlag == 1)
        decayFactor=petrecon_decayFactor(rdf);
        fprintf('Decay Factor = %f\n',decayFactor);
    else
        decayFactor=1;
    end

    % DURATION
    durationMultFactor = rdf.sharc_rdf_acq_stats_data.frameDuration/1000;
    % take binDuration into account for gated data
    durationMultFactor = durationMultFactor * petrecon_binDurationFraction(rdf);
    durationMultFactorArray(frameNum) = durationMultFactor;
    decayMultFactorArray(frameNum)=decayFactor;

    % Initialize DEADNORM (the product of deadtime and norm) to ones.
    deadnorm=ones(rdf.nu,rdf.nv,rdf.nphi,'single');

    % NORMALIZATION (only need to compute once)
    if ((reconParams.normalizationFlag) == 1 && (frameNum == 1))
        if ~exist(reconParams.normProcFilename, 'file')
            fprintf('Norm Calculation\n');
            normrdf=readRDF(reconParams.normFilename);
            xtals=normrdf.norm_3d.crystal_factors;
            geoCalFactors = normrdf.seg4FloatData;
            writeSavefile(geoCalFactors, reconParams.geoCalFilename);
            deadnorm = Norm3D(deadnorm, geoCalFactors, xtals);
            writevp(reconParams.normProcFilename,deadnorm,acqParams,scanner);
            clear normrdf;
            clear xtals;
            clear corr;
            clear geoCalFactors;
        else
            fprintf('Using existing normProc file %s.\n',reconParams.normProcFilename);
            deadnorm = readvp(reconParams.normProcFilename);
        end
    else
        fprintf('Reading %s from first frame\n',reconParams.normProcFilename);
        deadnorm = readvp(reconParams.normProcFilename);
    end

    % DEADTIME
    if (reconParams.deadtimeFlag)
        if ~exist([reconParams.normdeadFilename,'.',num2str(frameNum-1)], 'file')
            deadnorm = deadnorm .* petrecon_deadtime(rdf, reconParams);
            writevp([reconParams.normdeadFilename,'.',num2str(frameNum-1)], ...
                deadnorm,acqParams,scanner);
        else
            fprintf('Using existing deadnorm file %s.\n',...
                [reconParams.normdeadFilename,'.',num2str(frameNum-1)]);
        end
    end
    clear deadnorm;

    % RANDOMS
    if (reconParams.randomsFlag == 1) %RFS
        if exist([ reconParams.randomsFilename '.ng3d.'  num2str(frameNum-1)], 'file')
            fprintf('Using existing RFS file: %s\n', ...
                [reconParams.randomsFilename '.ng3d.'  num2str(frameNum-1)]);
        else
            fprintf('RFS Calculation\n');
            corr=petrecon3d_rfs(rdf,acqParams,scanner, reconParams);
            writevp([reconParams.randomsFilename '.ng3d.'  num2str(frameNum-1)],corr,acqParams,scanner);
            %fprintf('Applying norm, deadtime, and geometric to randoms estimate\n');
            %corr=corr.*readvp([reconParams.deadtimeFilename,'.',num2str(frameNum-1)]);
            %corr=corr.*readvp([reconParams.normVPFilename, '.' num2str(frameNum-1)]);
            %writevp([reconParams.randomsFilename '.'  num2str(frameNum-1)], ...
            %       geoCorrection(corr,scanner,acqParams).*decayFactor);
            clear corr;
        end
    elseif (reconParams.randomsFlag == 2) %DES
        corr=single(rdf.seg3Data);
        writevp([reconParams.randomsFilename '.ng3d.'  num2str(frameNum-1)],corr,acqParams,scanner);
    end
    if (isfield(rdf,'seg3Data'))
        rdf=rmfield(rdf,'seg3Data');
    end

    %GENERATE CTAC SINOGRAM FROM PIFA
    if exist([reconParams.acfFilename '.ng3d.' num2str(frameNum-1)], 'file')
        fprintf('Using existing CTAC file: %s\n', [reconParams.acfFilename '.ng3d.' num2str(frameNum-1)]);
        pifa.xm = 128;
        pifa.ym = pifa.xm;
        pifa.zm = acqParams.nZ;
        pifa.ctacDfov = 700;
    else
        if ((reconParams.scatterFlag || reconParams.attenuationFlag) && (~reconParams.CTACSinoFlag))
            fprintf('Generate CTAC\n');
            pifa=readPIFA([reconParams.pifaFilename '.' num2str(frameNum-1) '.pifa']);
            muImg=pifa.data;
            pifa=rmfield(pifa,'data');
            % New 25 Feb 2010 by CWS: Allow 0.05 mm tolerance on PIFA
            % location, and change to a "true" error message
            if ((pifa.tableLocation-rdf.sharc_rdf_acq_param_data.sharc_rdf_acq_scan_params.tableLocation)^2 > 0.05^2)
                error(['PIFA location (' num2str(pifa.tableLocation,5) ...
                    ') does not match emission location (' ...
                    num2str(rdf.sharc_rdf_acq_param_data.sharc_rdf_acq_scan_params.tableLocation,5)...
                    ')']);
            end

            %Flip PIFA image to be consistant with projector orientation
            % 20Oct09 CWS This is because PIFA images are defined as
            %   viewed from table-side of CT, while PET recon, in our
            %   slice-1-in-front systems, is defined from the other side
            %   of the gantry
            muImg = flipdim(muImg, 1);

            %Forward project mu image with VQC parameters applied
            if (reconParams.attenuationFlag || reconParams.scatterFlag)
                ctac3d=muImg2ctac3d_ng(muImg,scanner,acqParams,pifa, ...
                    +rdf.sharc_rdf_sys_geo_data.vqc_XaxisTranslation, ...
                    +rdf.sharc_rdf_sys_geo_data.vqc_YaxisTranslation, ...
                    rdf.sharc_rdf_sys_geo_data.transaxial_crystal_0_offset+...
                    rdf.sharc_rdf_sys_geo_data.vqc_ZaxisRoll);
                clear muImg;
                writevp([reconParams.acfFilename '.ctacSino_ng3d.vp.',num2str(frameNum-1)],ctac3d,acqParams,scanner);
                fprintf('Applying inverse norm, deadtime, and decay to CTAC sinogram\n');
                corr=ctac3d./readvp([reconParams.normdeadFilename, '.' num2str(frameNum-1)]);
                corr=corr/(decayFactor);
                writevp([reconParams.multFilename '.ng3d.' num2str(frameNum-1)],corr,acqParams,scanner);
                clear ctac3d;
                clear corr;
            end


        elseif reconParams.CTACSinoFlag % This can only happen with old (v6) data
            ctachdr=readHLRDF(fullfile(reconParams.dir,[ 'ctac2d.'  num2str(frameNum-1)]));
            ctac3d = convSino2ProjPlanes((1./ctachdr.seg0FloatData), acqParams);
            writevp([reconParams.acfFilename '.ctacSino_rr3d.vp.' num2str(frameNum-1)],ctac3d,acqParams,scanner);
            pifa.xm=128;
            pifa.ym=pifa.xm;
            pifa.zm=acqParams.nZ;
            pifa.ctacDfov=500;

            fprintf('Applying inverse norm, deadtime, and decay to CTAC sinogram\n');
            ctac3d= invGeoCorrection(ctac3d, scanner, acqParams, 1.0);
            corr=ctac3d./readvp([reconParams.normdeadFilename, '.' num2str(frameNum-1)]);
            corr=corr/(decayFactor);
            writevp([reconParams.multFilename '.ng3d.' num2str(frameNum-1)],corr,acqParams,scanner);

            clear ctachdr;
            clear ctac3d;
            clear corr;
        end
    end

    %3D SCATTER
    if (reconParams.scatterFlag)
        %RADIAL REPOSITIONING
        %set up acqParams structure (previously built in DST(E/RX)scanner.m)

        if ~exist([ reconParams.scatterFilename3D '.ng3d.' num2str(frameNum-1)], 'file')
            if ~exist([reconParams.scatterFilename3D '.' num2str(frameNum-1)], 'file')
                fprintf('Preparing scatter data \n');

                prompts=readvp([reconParams.emFilename '.ng3d.' num2str(frameNum-1)]);

                corr=prompts-readvp([reconParams.randomsFilename '.ng3d.' num2str(frameNum-1)]);
                clear prompts
                corr=corr.*readvp([reconParams.normdeadFilename,'.', num2str(frameNum-1)]);
                fprintf('Radial Repositioning of Trues+Scatter Sino\n');
                corr=geoCorrection(corr,scanner,acqParams);
                writevp([reconParams.scatterFilename '.prescat.' num2str(frameNum-1)],corr,acqParams,scanner);
                fprintf('Scatter Calculation\n');
                if reconParams.CTACSinoFlag
                    ctac3d=readvp([reconParams.acfFilename '.ctacSino_rr3d.vp.' num2str(frameNum-1)]);
                else
                    ctac3d=geoCorrection( ...
                        readvp([reconParams.acfFilename '.ctacSino_ng3d.vp.' num2str(frameNum-1)]), ...
                        scanner, acqParams); % fix : should we just project in rr for this?
                end
                totalPrompts=sum(corr(:),'double');
                geoCalFactors = readSavefile(reconParams.geoCalFilename);
                if (reconParams.scatterFlag == 1)
                    %error('2d scatter implementation not yet supported by NG offline code.')
                    corr=petrecon3d_scatter(corr,ctac3d,pifa,rdf,acqParams,scanner);
                    writevp([reconParams.scatterFilename '.' num2str(frameNum-1)],corr,acqParams,scanner);
                elseif (reconParams.scatterFlag == 2)
                    fprintf('Fully 3d Scatter \n');
                    corr=petrecon3d_scatter3d(corr, ctac3d, pifa, ...
                        geoCalFactors, rdf, acqParams, scanner, ...
                        reconParams.globalScatterCap);
                    writevp([reconParams.scatterFilename3D '.' num2str(frameNum-1)],corr,acqParams,scanner);
                elseif (reconParams.scatterFlag == 3)
                  fprintf('Fully 3d Scatter Hua\n');
                  if (reconParams.scatterConvergence.osem == 1)
                    randomscorr=readvp([reconParams.randomsFilename '.ng3d.' num2str(frameNum-1)]);
                    randomscorr=randomscorr.*readvp([reconParams.normdeadFilename,'.', num2str(frameNum-1)]);
                    fprintf('Radial Repositioning of randoms Sino\n');
                    randomscorr=geoCorrection(randomscorr,scanner,acqParams);
                  else
                      randomscorr=zeros(size(corr),'single');
                  end
                  corr=petrecon3d_scatter3d_mixFit(corr+ randomscorr, randomscorr, ctac3d, pifa, geoCalFactors, rdf, acqParams, scanner, [reconParams.scatterOutFilename '.' num2str(frameNum-1) '.'], reconParams.scatterConvergence);
                  writevp([reconParams.scatterFilename3D '.' num2str(frameNum-1)],corr,acqParams,scanner);
                end
                totalScatter=sum(corr(:),'double');
                scatterFraction(frameNum)=totalScatter/totalPrompts;
            else
                fprintf(['Using existing scatter file: ' ...
                    [reconParams.scatterFilename3D '.' num2str(frameNum-1)] '\n']);
                corr=readvp([reconParams.scatterFilename3D '.' num2str(frameNum-1)]);
            end

            corr = invGeoCorrection(corr,scanner,acqParams, 0);
            corr = corr./readvp([reconParams.normdeadFilename, '.' num2str(frameNum-1)]);
            writevp([reconParams.scatterFilename3D '.ng3d.' num2str(frameNum-1)], ...
                corr,acqParams,scanner);
        else
            fprintf('Using existing scatter file: %s\n', ...
                [reconParams.scatterFilename3D '.ng3d.' num2str(frameNum-1)]);
        end

        clear ctac3d
        clear corr
    end

    %GENERATE fake acf file
    if (~reconParams.acfCorrFlag)
        fprintf('Generate acf file with only norm and deadtime and decay\n');
        ctac3d= ones(acqParams.nU,acqParams.nV,acqParams.nPhi,'single');
        corr=ctac3d./readvp([reconParams.normdeadFilename, '.' num2str(frameNum-1)]);
        corr=corr/(decayFactor);
        writevp([reconParams.multFilename '.ng3d.' num2str(frameNum-1)],corr,acqParams,scanner);
        clear ctac3d;
        clear corr;
    end

end  %END frameNum Loop

if exist('scatterFraction', 'var') && reconParams.scatterFlag>0
    %Write Scatter Fraction log file
    save(reconParams.scatterFractionFilename, 'scatterFraction');
end


% BEGIN RECONSTRUCTION SECTION
% Get WCC values.  If they don't exist, use all ones and warn the user
if exist(reconParams.wcc3dFilename,'file')
    fprintf('Reading well counter values\n');
    wccfileinfo=dir(reconParams.wcc3dFilename);
    wccsens=readRaw(reconParams.wcc3dFilename,[acqParams.nZ,1],'float','l',0);
    wccact=readRaw(reconParams.wcc3dFilename,[1,1],'float','l',wccfileinfo.bytes-4);
else
    warning('WCC file %s not found.  Using all ones for WCC.',reconParams.wcc3dFilename);
    wccsens=ones(acqParams.nZ,1);
    wccact=1.0;
end

if (reconParams.scatterFlag == 2) %KT will fail if set to 0
    reconParams.scatterFilename=reconParams.scatterFilename3D;
end

reconParams=petrecon_setXYOffset(reconParams, rdf);

%DETERMINE TARGET PARAMATERS (KEYHOLE TARGET, NONKEYHOLE TARGET, FULL FOV)
nf=scanner.maxFOV/10.;
nt=reconParams.nx;
crossoverDFOV = ((nf*sqrt(1.0+(nf*nf)/(nt*nt))) - (2.0*sqrt(2.0)))/ ...
    (nf*(1.0 + (nf*nf)/(nt*nt)))* scanner.maxFOV/10.;

crossoverDFOV=floor(crossoverDFOV*10.0);
if (reconParams.FOV < crossoverDFOV)
    reconParams.keyholeFlag = 1;
elseif (reconParams.FOV >= crossoverDFOV && reconParams.FOV < scanner.maxFOV)
    reconParams.keyholeFlag = 0;
else
    reconParams.keyholeFlag = 0;
end

saved_reconParams_acfCorrFlag=reconParams.acfCorrFlag;
if (~reconParams.acfCorrFlag)
    fprintf('\nStarting osem with acf file with only norm and deadtime used in the loop\n');
    reconParams.acfCorrFlag=2;
end


%KEYHOLE TARGETED RECONSTRUCTION
if (reconParams.keyholeFlag)
    %Set up keyhole recon parameters for first pass image of 64x64 by 70cm
    keyholeParams=reconParams;
    keyholeParams.FOV=scanner.maxFOV;
    keyholeParams.nx=64;
    keyholeParams.ny=64;
    keyholeParams.overlap=0;
    keyholeParams.keyholeFlag = 0;
    keyholeParams.xOffset=0;
    keyholeParams.yOffset=0;
    keyholeParams.keepIterationUpdates = 0;
    keyholeParams.detectorResponseFlag = 0; %do not use detector resone for keyhole


    %First pass nonkeyhole
    keyholeImage = osem3d_ng('emFilename',[reconParams.emFilename '.ng3d'], ...
        'scatterFilename',[reconParams.scatterFilename3D '.ng3d'], ...
        'randomsFilename',[reconParams.randomsFilename '.ng3d'], ...
        'multFilename',[reconParams.multFilename '.ng3d'], ...
        'acqParams',acqParams, ...
        'reconParams',keyholeParams, ...
        'imOutFilename',reconParams.imOutFilename, ...
        'scanner',scanner,...
        'durationMultFactorArray', durationMultFactorArray, ...
        'decayMultFactorArray', decayMultFactorArray);
    %By default image is processed with wcc sensitivity and duration correction. We want to
    %remove this prior to forward projecting the keyhole frames
    wccsens=reshape(squeeze(wccsens),[1,1,acqParams.nZ]);
    wccsensmat=repmat(wccsens,[keyholeParams.nx,keyholeParams.nx,1]);
    for frame=1:keyholeParams.nFrames
        keyholeImage(:,:,1+acqParams.nZ*(frame-1):acqParams.nZ*frame)=  ...
            keyholeImage(:,:,1+acqParams.nZ*(frame-1):acqParams.nZ*frame)*durationMultFactorArray(frame)./wccsensmat;

    end

    %Create one side margin over the requested FOV, converted to unitos output pixels, rounded up
    fullpix=keyholeParams.FOV/keyholeParams.nx;
    finalpix=reconParams.FOV/reconParams.nx;
    margin=ceil(fullpix*sqrt(2)/finalpix);
    cropX = margin;
    cropY = margin;

    padImParams=reconParams;
    padImParams.nx=reconParams.nx+2*margin;
    padImParams.ny=padImParams.nx;
    padImParams.FOV=reconParams.FOV+2*margin*finalpix;

    endPos = fullpix * (keyholeParams.nx-1)/2.0;
    x2=(linspace(-endPos, endPos, keyholeParams.nx) - reconParams.xOffset).^2;
    y2=(linspace(-endPos, endPos, keyholeParams.nx) - reconParams.yOffset)'.^2;

    keymaskSingle=x2(ones(keyholeParams.nx,1),:)+y2(:,ones(keyholeParams.nx,1))...
        <= ((reconParams.FOV+fullpix*sqrt(2))/2)^2;

    keymaskSingle = keymaskSingle';
    nkh_slice=size(keyholeImage,3);
    keymask=repmat(keymaskSingle,[1 1 nkh_slice]);
    cutoutImage = keyholeImage.* (1-keymask);


    %Forward project keyhole image to create keyhole sino
    for frameNum=1:reconParams.nFrames

        cutoutImageFrame=cutoutImage(:,:,1+acqParams.nZ*(frameNum-1):acqParams.nZ*frameNum);
        cutoutSino = FDD3D_ng(cutoutImageFrame,...
            acqParams.nU, ...
            acqParams.nV, ...
            acqParams.nPhi, ...
            acqParams.sU, ...
            acqParams.sV, ...
            keyholeParams.nx, ...
            acqParams.nZ, ...
            keyholeParams.FOV/keyholeParams.nx, ...
            acqParams.sV, ...
            scanner.numBlocksPerRing, ...
            scanner.radialCrystalsPerBlock, ...
            scanner.radBlockSize, ...
            1, ...
            1, ...
            0, ...
            0, ...
            keyholeParams.rotate, ...
            scanner.effectiveRingDiameter);

        %Smooth output sino
        triWidth=2*ceil(fullpix/(2*acqParams.sU))+1;
        triFilt=GEtriang(triWidth);
        cutoutSino=imfilter(cutoutSino,triFilt/sum(triFilt));

        %Apply ac,norm,dt to forward projected image
        cutoutSino = cutoutSino.*readvp([reconParams.multFilename '.ng3d.' num2str(frameNum-1)]);

        %Write keyhole sino for use in 2nd recon
        writevp([reconParams.keyholeFilename '.' num2str(frameNum-1)],cutoutSino,acqParams,scanner);
    end
    %  clear some space for next recon
    clear cutoutSino cutoutImage cutoutImageFrame;
    clear keyholeImage keymask keymaskSingle ;
    clear wccsensmat;

    %Generate "padded" keyhole image.
    reconImg = osem3d_ng('emFilename',[reconParams.emFilename '.ng3d'], ...
        'scatterFilename',[reconParams.scatterFilename3D '.ng3d'], ...
        'randomsFilename',[reconParams.randomsFilename '.ng3d'], ...
        'keyholeFilename',[reconParams.keyholeFilename], ...
        'multFilename',[reconParams.multFilename '.ng3d'], ...
        'acfFilename',[reconParams.acfFilename,'.ctacSino_ng3d.vp'], ...  %ACF sino used for detector response
        'normdeadFilename',[reconParams.normdeadFilename], ...		%normdead file used for detector response
        'acqParams',acqParams, ...
        'reconParams',padImParams, ...
        'imOutFilename',reconParams.imOutFilename, ...
        'scanner',scanner,...
        'durationMultFactorArray', durationMultFactorArray, ...
        'decayMultFactorArray', decayMultFactorArray);

    nslice=size(reconImg,3);

    %Extract image
    x2=linspace(-(reconParams.nx-1)/2.0,...
        (reconParams.nx-1)/2.0,reconParams.nx).^2;
    y2=linspace(-(reconParams.nx-1)/2.0,...
        (reconParams.nx-1)/2.0,reconParams.nx)' .^2;
    targetMask=x2(ones(reconParams.nx,1),:)+y2(:,ones(reconParams.nx,1))...
        <= (reconParams.nx/2)^2;

    reconImg=reconImg(cropX+1:cropX+reconParams.nx,...
        cropY+1:cropY+reconParams.nx,:)...
        .* repmat(targetMask,[1 1 nslice]);
else
    % Non-keyhole (maybe with cropping) reconstruction
    padImParams=reconParams;
    pixelSize = reconParams.FOV/reconParams.nx;
    padImParams.nx= 2*floor(scanner.maxFOV/(2.0*pixelSize));
    padImParams.ny=padImParams.nx;
    padImParams.FOV = pixelSize * padImParams.nx;

    cropX = floor((reconParams.xOffset + padImParams.FOV)/pixelSize +0.5) - padImParams.nx;
    cropY = floor((reconParams.yOffset + padImParams.FOV)/pixelSize +0.5) - padImParams.ny;

    padImParams.xOffset = reconParams.xOffset - (pixelSize*cropX);
    padImParams.yOffset = reconParams.yOffset - (pixelSize*cropY);


    cropX = cropX + (padImParams.nx - reconParams.nx)/2;
    cropY = cropY + (padImParams.ny - reconParams.ny)/2;

    %Standard nonkeyhole reconstruction
    reconImg = osem3d_ng('emFilename',[reconParams.emFilename '.ng3d'], ...
        'scatterFilename',[reconParams.scatterFilename3D '.ng3d'], ...
        'randomsFilename',[reconParams.randomsFilename '.ng3d'], ...
        'multFilename',[reconParams.multFilename '.ng3d'], ...
        'acfFilename',[reconParams.acfFilename,'.ctacSino_ng3d.vp'], ...  %ACF only sino used for detector response
        'normdeadFilename',[reconParams.normdeadFilename], ...		%normdead file used for detector response
        'acqParams',acqParams, ...
        'reconParams',padImParams, ...
        'imOutFilename',reconParams.imOutFilename, ...
        'scanner',scanner,...
        'durationMultFactorArray', durationMultFactorArray, ...
        'decayMultFactorArray', decayMultFactorArray);

    reconParams.acfCorrFlag=saved_reconParams_acfCorrFlag;

    nslice=size(reconImg,3);
    x2=linspace(-(reconParams.nx-1)/2.0,...
        (reconParams.nx-1)/2.0,reconParams.nx).^2;
    y2=linspace(-(reconParams.nx-1)/2.0,...
        (reconParams.nx-1)/2.0,reconParams.nx)' .^2;

    targetMask=x2(ones(reconParams.nx,1),:)+y2(:,ones(reconParams.nx,1))...
        <= (reconParams.nx/2)^2;
    tempImg=zeros(reconParams.nx,reconParams.ny,nslice);

    cropXmin=max(cropX,0);
    cropYmin=max(cropY,0);
    cropXmax=min(cropX+reconParams.nx,padImParams.nx);
    cropYmax=min(cropY+reconParams.ny,padImParams.ny);

    tempImg(cropXmin-cropX+1:cropXmax-cropX,cropYmin-cropY+1:cropYmax-cropY,:)=reconImg(cropXmin+1:cropXmax,...
        cropYmin+1:cropYmax,:);
    reconImg=tempImg .* repmat(targetMask,[1 1 nslice]);

end

%% X flip of image if patientEntry is Head First
% Image flip lr and image index z flip for head first. After this the fastest changing is to the
% patient left (new 1st index), 2nd index is patient posterior, 3rd index is inferior.
% This works because this is a PET first slice in front machine
tempImg=reconImg;
if (rdf.sharc_rdf_acq_param_data.sharc_rdf_acq_landmark_params.patientEntry == 0)
    for i=1:nslice
        reconImg(:,:,i)=flipud(tempImg(:,:,nslice-(i-1)));
    end
end

pixelSizecm=(reconParams.FOV/10)/reconParams.nx;
nomPixelSize=(scanner.maxFOV/10)/128;
reconImg=1e6*reconImg*wccact*scanner.ir3dWccActScaleFactor_ng*nomPixelSize*nomPixelSize/ ...
    (pixelSizecm*rdf.sharc_rdf_pet_exam_data.positronFraction);

% Optionally delete intermediate files (using an internal function defined below)
cleanupIntermediateFiles(reconParams);

% Post-filtering
reconImg=petrecon_postfilter(reconImg, reconParams);

% Write-out reconstructed image
writeRaw(reconParams.imOutFilename,reconImg,'float','l',0);


%% write to dicom
if (reconParams.writeDicomImage == 1)
    % If scatter correction on but scatter fractions not in MATLAB now (i.e., 
    % recon is re-using a previously computed scatter estimate), read them
    % from MATLAB save file
    if (reconParams.scatterCorrFlag~=0 && ~exist('scatterFraction', 'var'))
        if (isfield(reconParams,'scatterFractionFilename') ...
                && exist(reconParams.scatterFractionFilename,'file'))
            fprintf('Reading scatter fraction data from %s.\n', ...
                reconParams.scatterFractionFilename);
            load(reconParams.scatterFractionFilename);
        end
    end
    
%%    if (reconParams.reconFlag == 0)
%        % Calculate number of slices in entire image volume
%        nslices = acqParams.nZ*reconParams.nFrames-reconParams.overlap*(reconParams.nFrames-1);
%        imSize=[reconParams.nx, reconParams.ny, nslices];
%        reconImg=readRaw(reconParams.imOutFilename,imSize, 'float','l',0);
%    end

    % Pick up a template DICOM header
    rawDicomHdr=dicominfo(dicomrdfname{1},'Dictionary','pet-dicom-dict.txt');
    if isfield(rawDicomHdr,'NumberOfUnarchivedSeries')
        rawDicomHdr=rmfield(rawDicomHdr,'NumberOfUnarchivedSeries');
    end

    % 20Oct09 CWS Add ACQC shift of output PET images
    if reconParams.acqcS ~= 0.0
        fprintf('   ACQC shift of %.1f added to PET image locations.\n',reconParams.acqcS);
    end
    rawDicomHdr.image_one_loc = rawDicomHdr.image_one_loc + reconParams.acqcS;

    rawDicomHdr.SliceThickness = acqParams.sV;
    %Permute image prior to dicomwrite
    reconImgTmp=permute(reconImg,[2,1,3]);

    dicomFname=fullfile(reconParams.dir, reconParams.dicomImageSeriesDesc);
    mkdir(dicomFname);
    dicomFname=[ dicomFname filesep ];
    if exist('scatterFraction', 'var')
        writeDicomImage(reconImgTmp,dicomFname,rawDicomHdr,reconParams,scatterFraction);
    else
        writeDicomImage(reconImgTmp,dicomFname,rawDicomHdr,reconParams);
    end

end % end writing DICOM



%% internal functions
function cleanupIntermediateFiles(reconParams)
  if reconParams.cleanupIntermediateFiles
    for frameNum=1:reconParams.nFrames
      frame=['.' num2str(frameNum-1)];
      deleteIfExist([reconParams.emFilename '.ng3d' frame]);
      deleteIfExist([reconParams.scatterFilename3D  frame]);
      deleteIfExist([reconParams.scatterFilename3D '.prescat' frame]);
      deleteIfExist([reconParams.acfFilename '.ctacSino_ng3d.vp'  frame]);
      deleteIfExist([reconParams.acfFilename '.ctacSino_rr3d.vp'  frame]);
      deleteIfExist([reconParams.keyholeFilename frame]);
      deleteIfExist([reconParams.multFilename '.ng3d' frame]);
      if reconParams.cleanupIntermediateFiles>1
        deleteIfExist([reconParams.randomsFilename '.ng3d' frame]);
        deleteIfExist([reconParams.multFilename '.ng3d' frame]);
        if reconParams.cleanupIntermediateFiles>2
          deleteIfExist([reconParams.scatterFilename3D '.ng3d' frame]);
          if reconParams.cleanupIntermediateFiles >3
            deleteIfExist([reconParams.normdeadFilename frame]);
            deleteIfExist(reconParams.normProcFilename);
            deleteIfExist(reconParams.geoCalFilename);
          end
        end
      end
    end
  end
