function reconImg=petrecon2d_ng(varargin)
% 2d reconstruction (native geometry)
% Usage:
%  reconImg=petrecon2d_ng
% or
%  reconImg=petrecon2d_ng(reconParams)
%
% FILE NAME: petrecon2d_ng.m
%
%
% PURPOSE:  This is the main wrapper program for 2D reconstruction.
%
% INPUTS:  Input files and reconstruction parameters are read from
% a reconParams structure. If no arguments are specified, this will
% be set by reading petrecon2d_params.m (found by using the matlab
% path).
% Warning: following doc is incomplete. It does not mention dicom for
% instance. See petrecon2d_params.m in the pettoolbox for more info.
%
%       inputfiles required are:        reconParams.inputFilename: emission 2d rdf
%                                       reconParams.normFilename: 2d norm
%
%       reconParameters required are:   reconParams.randomsFlag
%                                       reconParams.deadtimeFlag
%                                       reconParams.normalizationFlag
%                                       reconParams.radialRepositionFlag
%                                       reconParams.scatterFlag
%                                       reconParams.attenuationFlag
%
%                                       reconParams.FOV  (reconstruction FOv)
%                                       reconParams.nx   (reconstruction image x number of pixels)
%                                       reconParams.ny   (reconstruction image y number of pixels)
%
%

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   DEVELOPER: Tim Deller / Steve Ross

if (length(varargin)==0)
  disp(['Reading reconParams from' which('petrecon2d_params')]);
  rehash
  petrecon2d_params
else
  reconParams=varargin{1};
end
% first set preprocess flags to 0 if we don't need the correction at all
if (reconParams.scatterCorrFlag == 0)
  reconParams.scatterFlag=0;
end
if (reconParams.acfCorrFlag == 0)
  reconParams.attenuationFlag=0;
end

if (reconParams.rawFromDicom == 1)
    [dicomrdfname,reconParams.nFrames,frameoffset]=sortRawDicom([reconParams.dir], ['dicom/'],'*RPDC*',0);
    if (reconParams.nFrames==0)
      error('Number of frames is zero');
    end
    reconParams.overlap = round(47-abs(frameoffset)/3.27);
    reconParams.inputFilename=fullfile(reconParams.dir,'rdf');
end % rawFromDicom

if (~isfield(reconParams,'deadtimeFilename'))
  reconParams.deadtimeFilename=fullfile(reconParams.dir,'deadtime2d.vp');
end
if (~isfield(reconParams,'normFilename'))
  reconParams.normFilename=fullfile(reconParams.dir, 'norm2d');
end
if (~isfield(reconParams,'normVPFilename'))
  reconParams.normVPFilename=fullfile(reconParams.dir, 'norm2d.vp');
end
if (~isfield(reconParams,'wcc2dFilename'))
  reconParams.wcc2dFilename=fullfile(reconParams.dir, 'wcc2d');
end

% generate CTAC/PIFA files only if we are doing scatter and/or attenuation correction
if (reconParams.scatterFlag || reconParams.attenuationFlag)
  if reconParams.CTACSinoFlag
    sortCTACSino(reconParams.dir, 'CTACSino/','*RPDC*',0);
  else  
    reconParams=petrecon_makePIFAs(reconParams);
  end
end % if (reconParams.scatterFlag || reconParams.attenuationFlag)


for frameNum=1:reconParams.nFrames
    fprintf('\nCorrection processing for frameNum %d of %d\n',frameNum,reconParams.nFrames);
    % READ PET RDF-> raw, singles, deadtime
    fprintf('Reading emission RDF\n');
    rdf=readHLRDF([reconParams.inputFilename '.' num2str(frameNum-1)]);
    %     rdf=readHLRDF_uint8([reconParams.inputFilename '.' num2str(frameNum-1)]);
    if mod(rdf.ny, reconParams.numSubsets)
        error('Highly recommend evenly divisible number of subsets.');
    end

    if (frameNum == 1)
        reconParams.startLocation=rdf.sharc_rdf_acq_param_data.sharc_rdf_acq_scan_params.tableLocation;
    end
    %Assign sino to rdf.seg2Data and clear the segment from the structure
    prompts=single(rdf.seg2Data);
    rdf = rmfield(rdf,'seg2Data');
    writevp([reconParams.emFilename '.' num2str(frameNum-1)],permute(prompts, [1 3 2]));

    %PARAM SETUP: set up acqParams,scanner, and acqParams structures (previously built in DST(E/RX)scanner.m)
    acqParams=petrecon_acqParams(rdf);
    scanner=petrecon_scanner(rdf);
    % 	scanner.ringDia = scanner.effectiveRingDiameter; scanner.nBlocks = scanner.numBlocksPerRing;
    % 	scanner.nXtals = scanner.numRawarning('is this correct (petrecon2d_ng)');

    % COMPUTE RANDOMS ESTIMATE
    if (reconParams.randomsFlag == 1) %RFS
        fprintf('Computing RFS estimate\n');
        corr=petrecon2d_rfs(rdf,acqParams,scanner,reconParams);
        corr=permute(corr,[1 3 2]);
        writevp([reconParams.randomsFilename '.' num2str(frameNum-1)],corr);
        clear corr;

    elseif (reconParams.randomsFlag == 2)  %DES
        corr=single(rdf.seg3Data);
	corr=permute(corr,[1 3 2]);
        writevp([reconParams.randomsFilename '.' num2str(frameNum-1)],corr);
    end

    rdf=rmfield(rdf,'singles');
    if (isfield(rdf,'seg3Data'))
        rdf=rmfield(rdf,'seg3Data');
    end

    %DEADTIME
    if (reconParams.deadtimeFlag)
        fprintf('Deadtime Calculation\n');
        corr=petrecon2d_dt(rdf);
        corr=permute(corr,[1 3 2]);
        writevp([reconParams.deadtimeFilename,'.' num2str(frameNum-1)],corr);
        clear corr;
    end

    rdf=rmfield(rdf,'unitIntegDeadTime');
    rdf=rmfield(rdf,'unitMuxDeadTime');

    %NORMALIZATION
    fprintf('Generating normalization estimate\n');
    if (reconParams.normalizationFlag == 1)
        normrdf=readHLRDF(reconParams.normFilename);

        norm2d=normrdf.seg1FloatData;
        clear normrdf
        norm2d=permute(norm2d,[1 3 2]);
        writevp([reconParams.normVPFilename,'.' num2str(frameNum-1)],norm2d);
        clear norm2d
    end

    %WCC
    fprintf('Reading well counter values\n');
    wccSens=readRaw(reconParams.wcc2dFilename,[acqParams.nZ,1],'float','l',0);
    wccAct=readRaw(reconParams.wcc2dFilename,[1,1],'float','l',acqParams.nZ*4);

    %DECAY
    if (reconParams.decayFlag == 1)
	      decayFactor=petrecon_decayFactor(rdf);
        fprintf('Decay Factor = %f\n',decayFactor);
    else
        decayFactor=1;
    end

    %DURATION (varying frame duration)
    durationMultFactor = 1000 / rdf.sharc_rdf_acq_stats_data.frameDuration;
    % take binDuration into account for gated data
    durationMultFactor = durationMultFactor / petrecon_binDurationFraction(rdf);
    durationMultFactorArray(frameNum) = durationMultFactor;


    %GENERATE CTAC SINOGRAM FROM PIFA
    if ((reconParams.scatterFlag || reconParams.attenuationFlag) && (~reconParams.CTACSinoFlag))
        fprintf('Generate CTAC\n');
        pifa=readPIFA([reconParams.pifaFilename '.' num2str(frameNum-1) '.pifa']);
        muImg=pifa.data;
        pifa=rmfield(pifa,'data');
        %Flip PIFA image to be consistant with projector orientation
        for i=1:pifa.zm
            muImg(:,:,i)=flipud(muImg(:,:,i));
        end

        %Forward project mu image with VQC parameters applied
        ctac2d=muImg2ctac2d_ng(muImg,scanner,acqParams,pifa, ...
            +rdf.sharc_rdf_sys_geo_data.vqc_XaxisTranslation, ...
            +rdf.sharc_rdf_sys_geo_data.vqc_YaxisTranslation, ...
            rdf.sharc_rdf_sys_geo_data.transaxial_crystal_0_offset+...
            rdf.sharc_rdf_sys_geo_data.vqc_ZaxisRoll);
        ctac2d=permute(ctac2d,[1 3 2]);
        writevp(fullfile(reconParams.dir, ['ctacSino_ng.' num2str(frameNum-1)]),ctac2d);
        clear ctac2d;
        clear muImg;
    elseif reconParams.CTACSinoFlag
        ctachdr=readHLRDF(fullfile(reconParams.dir, ['ctac2d.'  num2str(frameNum-1)]));
        ctac2d = 1./ctachdr.seg0FloatData;
        ctac2d = permute(ctac2d, [1 3 2]);
        writevp(fullfile(reconParams.dir, ['ctacSino_rr.' num2str(frameNum-1)]),ctac2d);
        pifa.xm=128;
        pifa.ym=pifa.xm;
        pifa.zm=47;
        pifa.ctacDfov=500;
        clear ctachdr;
        clear ctac2d;
    end


    %2D SCATTER
    if (reconParams.scatterFlag)

        %set up acqParams structure (previously built in DST(E/RX)scanner.m)
        fprintf('Applying norm, deadtime, wcc, and geometric to prompts for scatter estimate\n');
        corr=readvp([reconParams.randomsFilename '.' num2str(frameNum-1)] ,1);
        sino=prompts-corr;
        corr=readvp([reconParams.deadtimeFilename,'.' num2str(frameNum-1)],1);
        sino=sino.*corr;
        corr=readvp([reconParams.normVPFilename,'.' num2str(frameNum-1)],1);
        sino=sino.*corr;
        clear corr
        sinorr=geoCorrection(sino,scanner,acqParams);
        clear sino
        fprintf('Scatter Calculation\n');
        if reconParams.CTACSinoFlag
            ctac2drr=readvp(fullfile(reconParams.dir, ['ctacSino_rr.' num2str(frameNum-1)]),1);
        else
            ctac2drr=geoCorrection( ...
                readvp(fullfile(reconParams.dir, ['ctacSino_ng.' num2str(frameNum-1)]),1), ...
                scanner, acqParams); % fix : should we just project in rr for this?
        end
        fprintf('Generating scatter estimate\n');
        scatter_rr=petrecon2d_scatter(sinorr,ctac2drr,pifa,rdf,acqParams,scanner);
        writevp(fullfile(reconParams.dir, ['scatter_rr.vp.' num2str(frameNum-1)]),permute(scatter_rr,[1 3 2]));
        clear ctac2drr sinorr
        scatter_ng=invGeoCorrection(scatter_rr,scanner,acqParams, 0);
        clear scatter_rr
        scatter_ng = scatter_ng ./ ...
            readvp([reconParams.normVPFilename,'.' num2str(frameNum-1)],1);
        scatter_ng = scatter_ng ./ ...
            readvp([reconParams.deadtimeFilename,'.' num2str(frameNum-1)],1);
        scatter_ng=permute(scatter_ng, [1 3 2]);
        writevp([reconParams.scatterFilename '.' num2str(frameNum-1)],scatter_ng);
        clear scatter_ng
        clear scatter
        clear sinorr
    end

    %PREPROCESS CORRECTIONS
    if (reconParams.irReconPreprocessFlag == 1)
        %2D ITERATIVE RECONSTRUCTION PREPROCESS
        fprintf('Preprocess for ir2d\n');

        %Generate norm deadtime sinogram
        nd=readvp([reconParams.deadtimeFilename,'.' num2str(frameNum-1)],1).*  ...
            readvp([reconParams.normVPFilename,'.' num2str(frameNum-1)],1);

        %Apply inverse norm and inverse deadtime to CTAC sinogram
        fprintf('Applying inverse norm & deadtime to CTAC sinogram\n');
	if (reconParams.acfCorrFlag == 0)
		ctac2d=ones(acqParams.nU,acqParams.nPhi,acqParams.nZ);	
	else
	  if reconParams.CTACSinoFlag
            ctac2d=invGeoCorrection( ...
                readvp(fullfile(reconParams.dir, ['ctacSino_rr.' num2str(frameNum-1)]),1), ...
                scanner, acqParams, 1.0);
	  else
            ctac2d = readvp(fullfile(reconParams.dir, ['ctacSino_ng.' num2str(frameNum-1)]),1);
	  end

	end

        for i=1:rdf.nz
            ctac2d(:,:,i)=ctac2d(:,:,i)*(1/(wccSens(i)*decayFactor*durationMultFactor));
        end
        ctac2dInvND = ctac2d ./ nd;
        clear ctac2d
        ctac2dInvND = permute(ctac2dInvND, [1 3 2]);
        writevp([reconParams.acfFilename  '.' num2str(frameNum-1)],ctac2dInvND);
        clear ctac2dInvND nd
    end
end  %END Preprocess correction generation loop

if (reconParams.reconFlag == 1)
        reconParams=petrecon_setXYOffset(reconParams, rdf);

	%DETERMINE TARGET PARAMATERS (KEYHOLE TARGET, NONKEYHOLE TARGET, FULL FOV) 
	nf=scanner.maxFOV/10.;
	nt=reconParams.nx;
	crossoverDFOV = ((nf*sqrt(1.0+(nf*nf)/(nt*nt))) - (2.0*sqrt(2.0)))/ ...
			(nf*(1.0 + (nf*nf)/(nt*nt)))* scanner.maxFOV/10.;
	 
	crossoverDFOV=floor(crossoverDFOV*10.0);
	if (reconParams.FOV < crossoverDFOV)
		reconParams.keyholeFlag = 1;
		nonkeyholeTarget =0;
	elseif (reconParams.FOV >= crossoverDFOV && reconParams.FOV < scanner.maxFOV)
		reconParams.keyholeFlag = 0;
		nonkeyholeTarget =1;
	else
		reconParams.keyholeFlag = 0;
		nonkeyholeTarget = 0;
	end


	%KEYHOLE TARGETED RECONSTRUCTION
	if (reconParams.keyholeFlag)
		%Set up keyhole recon parameters for first pass image of 64x64 by 70cm
		keyholeParams=reconParams;
		keyholeParams.FOV=scanner.maxFOV;
		keyholeParams.nx=64;
		keyholeParams.ny=64;
		keyholeParams.overlap=0;
		keyholeParams.keyholeFlag = 0;
    	keyholeParams.xOffset=0;
    	keyholeParams.yOffset=0;

		%First pass nonkeyhole
    	keyholeImage = osem2d_ng('emFilename',[reconParams.emFilename], ...
        	'scatterFilename',[reconParams.scatterFilename], ...
        	'randomsFilename',[reconParams.randomsFilename], ...
        	'acfFilename',[reconParams.acfFilename], ...
        	'wccFactors',wccSens, ...
        	'acqParams',acqParams, ...
        	'reconParams',keyholeParams, ...
        	'imOutFilename',[reconParams.imOutFilename '.keyhole'], ...
        	'scanner',scanner);


		%Create one side margin over the requested FOV, converted to unitos output pixels, rounded up
		fullpix=keyholeParams.FOV/keyholeParams.nx;
		finalpix=reconParams.FOV/reconParams.nx;
		margin=ceil(fullpix*sqrt(2)/finalpix);   
		cropX = margin;
		cropY = margin; 

		padImParams=reconParams;
		padImParams.nx=reconParams.nx+2*margin;
		padImParams.ny=padImParams.nx;
		padImParams.FOV=reconParams.FOV+2*margin*finalpix;

		endPos = fullpix * (keyholeParams.nx-1)/2.0;
		keymaskOffsetX=  reconParams.xOffset;
		keymaskOffsetY=  reconParams.yOffset;
		x2=(linspace(-endPos, endPos, keyholeParams.nx) - keymaskOffsetX).^2;
		y2=(linspace(-endPos, endPos, keyholeParams.nx) - keymaskOffsetY)'.^2;

		keymaskSingle=x2(ones(keyholeParams.nx,1),:)+y2(:,ones(keyholeParams.nx,1))...
              <= ((reconParams.FOV+fullpix*sqrt(2))/2)^2;

		keymaskSingle = keymaskSingle';
    		nkh_slice=size(keyholeImage,3);
		keymask=repmat(keymaskSingle,[1 1 nkh_slice]);
		cutoutImage = keyholeImage.* (1-keymask);

		%Forward project keyhole image to create keyhole sino
		for frameNum=1:reconParams.nFrames

			cutoutImageFrame=cutoutImage(:,:,1+acqParams.nZ*(frameNum-1):acqParams.nZ*frameNum);
		
			cutoutSino = FDD2D_ng(cutoutImageFrame,...
                acqParams.nU, ...
                acqParams.nPhi, ...
                keyholeParams.nx, ...
                acqParams.nZ, ...
                acqParams.sU, ...
                keyholeParams.FOV/keyholeParams.nx, ...
                acqParams.sV, ...
				scanner.numBlocksPerRing, ...
                scanner.radialCrystalsPerBlock, ...
                scanner.radBlockSize, ...
                1, ...
                1, ...
                0, ...
                0, ...
                keyholeParams.rotate, ...
                scanner.effectiveRingDiameter);

			%Smooth output sino
 			triWidth=2*ceil(fullpix/(2*acqParams.sU))+1;
    		triFilt=GEtriang(triWidth);
    		cutoutSino=imfilter(cutoutSino,triFilt/sum(triFilt));
			%Apply ac,norm,dt to forward projected image
			acfSino = readvp([reconParams.acfFilename '.' num2str(frameNum-1)],1);
			cutoutSino = cutoutSino.*acfSino;
			
			cutoutSino=permute(cutoutSino,[1,3,2]);
			%Write keyhole sino for use in 2nd recon
    		writevp([reconParams.keyholeFilename '.' num2str(frameNum-1)],cutoutSino);
		end		

		%Generate "padded" keyhole image. 
    	reconImg = osem2d_ng('emFilename',[reconParams.emFilename], ...
        		'scatterFilename',[reconParams.scatterFilename], ...
        		'randomsFilename',[reconParams.randomsFilename], ...
        		'acfFilename',[reconParams.acfFilename], ...
				'keyholeFilename',[reconParams.keyholeFilename], ...
        		'wccFactors',wccSens, ...
        		'acqParams',acqParams, ...
        		'reconParams',padImParams, ...
        		'imOutFilename',reconParams.imOutFilename, ...
        		'scanner',scanner);
    	nslice=size(reconImg,3);

		%Extract image 
		x2=linspace(-(reconParams.nx-1)/2.0,...
              (reconParams.nx-1)/2.0,reconParams.nx).^2;
		y2=linspace(-(reconParams.nx-1)/2.0,...
              (reconParams.nx-1)/2.0,reconParams.nx)' .^2;
		targetMask=x2(ones(reconParams.nx,1),:)+y2(:,ones(reconParams.nx,1))...
                                       <= (reconParams.nx/2)^2;

    	reconImg=reconImg(cropX+1:cropX+reconParams.nx,...
                		cropY+1:cropY+reconParams.nx,:)...
           			  .* repmat(targetMask,[1 1 nslice]);

	 end  %END KEYHOLE TARGETED RECONSTRUCTION 


	%SETUP PARAMETERS FOR NONKEYHOLE TARGET or FULL FOV RECON
	if (reconParams.keyholeFlag == 0)

		padImParams=reconParams;
		pixelSize = reconParams.FOV/reconParams.nx;	
		padImParams.nx= 2*floor(scanner.maxFOV/(2.0*pixelSize));
		padImParams.ny=padImParams.nx;
		padImParams.FOV = pixelSize * padImParams.nx;

		cropX = floor((reconParams.xOffset + padImParams.FOV)/pixelSize +0.5) - padImParams.nx;
		cropY = floor((reconParams.yOffset + padImParams.FOV)/pixelSize +0.5) - padImParams.ny;

		padImParams.xOffset = reconParams.xOffset - (pixelSize*cropX);
		padImParams.yOffset = reconParams.yOffset - (pixelSize*cropY);


		cropX = cropX + (padImParams.nx - reconParams.nx)/2;
		cropY = cropY + (padImParams.ny - reconParams.ny)/2;

		%Generate "padded" keyhole image. Extract image below
    	reconImg = osem2d_ng('emFilename',[reconParams.emFilename], ...
        		'scatterFilename',[reconParams.scatterFilename], ...
        		'randomsFilename',[reconParams.randomsFilename], ...
        		'acfFilename',[reconParams.acfFilename], ...
        		'wccFactors',wccSens, ...
        		'acqParams',acqParams, ...
        		'reconParams',padImParams, ...
        		'imOutFilename',reconParams.imOutFilename, ...
        		'scanner',scanner);
    	nslice=size(reconImg,3);
		x2=linspace(-(reconParams.nx-1)/2.0,...
              (reconParams.nx-1)/2.0,reconParams.nx).^2;
		y2=linspace(-(reconParams.nx-1)/2.0,...
              (reconParams.nx-1)/2.0,reconParams.nx)' .^2;

		targetMask=x2(ones(reconParams.nx,1),:)+y2(:,ones(reconParams.nx,1))...
                                       <= (reconParams.nx/2)^2;
		tempImg=zeros(reconParams.nx,reconParams.ny,nslice);
		
		cropXmin=max(cropX,0);
		cropYmin=max(cropY,0);
		cropXmax=min(cropX+reconParams.nx,padImParams.nx);
		cropYmax=min(cropY+reconParams.ny,padImParams.ny);

    	tempImg(cropXmin-cropX+1:cropXmax-cropX,cropYmin-cropY+1:cropYmax-cropY,:)=reconImg(cropXmin+1:cropXmax,...
                		cropYmin+1:cropYmax,:);
        reconImg=tempImg .* repmat(targetMask,[1 1 nslice]);

	end


	%% X flip of image if patientEntry is Head First 
	% Image flip lr and image index z flip for head first. After this the fastest changing is to the
	% patient left (new 1st index), 2nd index is patient posterior, 3rd index is inferior.
	% This works because this is a PET first slice in front machine
	tempImg=reconImg;
	if (rdf.sharc_rdf_acq_param_data.sharc_rdf_acq_landmark_params.patientEntry == 0)
   		for i=1:nslice
       	 reconImg(:,:,i)=flipud(tempImg(:,:,nslice-(i-1)));
    	end
	end



	pixelSizecm=(reconParams.FOV/10)/reconParams.nx; 
	nomPixSize=(scanner.maxFOV/10)/128;  
	reconImg=1e6*reconImg*wccAct*scanner.osem2dWccActScaleFactor_ng*nomPixSize*nomPixSize/ ...
        (pixelSizecm*rdf.sharc_rdf_pet_exam_data.postInjectionFraction);

       %                                                     save pre_postfilter_2d_ng.mat
        %                                                     pfilt_values = [0 6];
        %                                                     zfilt_values = [0 4];
        %                                                     for filter_index = 1:length(pfilt_values)
        %                                                         load pre_postfilter_2d_ng.mat
        %                                                         reconParams.postFilterFWHM = pfilt_values(filter_index);
        %                                                         reconParams.zfilter = zfilt_values(filter_index);
        %                                                         reconParams.dicomImageSeriesNum = 650 + round(reconParams.postFilterFWHM);
        %                                                         reconParams.dicomImageSeriesDesc = ['se' num2str(reconParams.dicomImageSeriesNum) '_fov' num2str(reconParams.FOV) ...
        %                                                               '_ng_l' num2str(reconParams.loopFilterFWHM) '_p' num2str(reconParams.postFilterFWHM) '_z' num2str(reconParams.zfilter)];




    % Post-filtering
    reconImg=petrecon_postfilter(reconImg, reconParams);

    % Write-out reconstructed image
    writeRaw(reconParams.imOutFilename,reconImg,'float','l',0);

    if (reconParams.writeDicomImage == 1)
        numslices=size(reconImg,3);
        rawDicomHdr=dicominfo(dicomrdfname{1},'Dictionary','pet-dicom-dict.txt');
        rawDicomHdr=rmfield(rawDicomHdr,'NumberOfUnarchivedSeries');
        rawDicomHdr.SliceThickness = acqParams.sV;

        dicomFname=fullfile(reconParams.dir, reconParams.dicomImageSeriesDesc);
	mkdir(dicomFname);
	dicomFname=[ dicomFname filesep ];
	%Permute image prior to dicomwrite
    	reconImg=permute(reconImg,[2,1,3]);


        writeDicomImage(reconImg,dicomFname,rawDicomHdr,reconParams);
    end

end
