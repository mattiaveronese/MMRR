% FILE NAME: smoothAxialPlanes.m
%
% DEVELOPER: TWD, based on previous functions
%
% PURPOSE:  This function filters the sinogram projections axially.
%
% INPUTS:
%     proj:   		3D sinogram
%		acqParams:  acqParams structure generated from petrecon_acqParams
%     kernel:     Three options:
%                 Option 1: (If scalar) central weight of a center-weighted
%                 3 point averager. (For example 4 would provide a
%                 [1/6, 4/6, 1/6] kernel)
%                 Option 2: (If vector) Full convolution by a kernel of any
%                 odd length. For example: [1/14, 3/14, 6/14, 3/14, 1/14]
%                 Option 3: (Not passed) This will default to [1/6, 4/6, 1/6]
%
% OUTPUTS:
%     proj:       3D filtered sinogram
%

% Copyright (c) 2009-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   09/25/2009   TWD   Written - loosely based on calcEmisTailCounts and
%                      filterScatterTailFactors
%   11/12/2009   TWD   Modified to accept a kernel longer than 3-point. (We
%                      might end up needing this functionality for the Mayo
%                      brain scanner.)

