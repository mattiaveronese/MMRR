% filter projections for Filtered Back-projection Reconstruction
% FILE NAME: filterProjections.m
%
%  Written by:
%		Ravindra Manjeshwar
%		GE Corporate Research and Development
%

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%		03/20/2001  RMM     Implemented FBP
%       05/15/2008  RMM     Hanning window implementation changed from
%                           MATLAB hanning to CWS formulation
%       Aug/2009   RMM and KT
%                           Fix ramp filter
%

% Default parameters
