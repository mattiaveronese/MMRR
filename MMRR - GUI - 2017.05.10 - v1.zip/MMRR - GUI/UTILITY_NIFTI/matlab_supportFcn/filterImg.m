% FILE NAME: filterImg.m
%
% DEVELOPER: Steve Ross
%
% PURPOSE:  This function filters a dicom imageset and creates a new dicom imageset. 
%	
% INPUTS:  Input files 
%	inputfiles required are: 	fname 
%					postFiltFWHM: Gaussian FWHM of transaxial convolution post filter
%					zfilter:	center weighting of [1,zfilter,1] axial convolution kernel
%					petrecon3d_params is called to setup Series and filter info 

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:


%INITIALIZE RECONSTRUCTION PARAMETERS
