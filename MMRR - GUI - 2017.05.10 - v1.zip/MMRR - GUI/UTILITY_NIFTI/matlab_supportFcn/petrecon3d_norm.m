% Execute 3D norm correction on 3D raw data.
% USAGE:
%  outBuff = petrecon3d_norm(inBuff, normrdfFilename, clipvalue);
% INPUT:
%   inBuff :
%       input 3d sinogram to be normalized
%   normrdfFilename : 
%       filename with norm data (in RDF format)
%   clipvalue : (optional argument)
%       crystal efficiencies larger than this value will be set to
%       clipvalue
% OUTPUT:
%   outBuff :
%       normalized 3d sinogram
% CALLS:
%   readHLRDF, readRaw, Norm3D
% TODO:
%   still uses hard-coded offset for efficiency information
%
%DEVELOPER: Steve Ross, Kris Thielemans

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%       v0 (Steve Ross) 
%          Code in petrecon3d.m
%       v1 (Kris Thielemans)
%          Moved to separate function


