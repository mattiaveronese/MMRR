%FILE NAME: ringSort.m
%
%ORIGINAL C CODE: Pete Crandall & Scott Schubert
%DEVELOPER: Luis E. Jimenez
%
%PURPOSE: This function was extracted from livetimeFactors.c and is re-used
%   by the 3D deadtime correction.
%
%--------------------------------------------------------------------------
% PURPOSE: This function was extracted from livetimeFactors.c and is
%   re-used by the 3D deadtime correction.
%
%   Sorts (module,unit) data to (ring,unit) data.
%   For ADVANCE:
%   Current numbering scheme for the 6 units within the modules:
%   Ring 0 ( back of gantry, starting with slice one ) is unit 2 and 3
%   Ring 1 is unit 1 and 4
%   Ring 2 is unit 0 and 5
%
%   For ROADWARRIOR:
%   Ring 0 ( front of gantry, starting with slice one ) is unit 0 and 1
%   Ring 1 is unit 2 and 3
%   Ring 2 is unit 4 and 5
%   Ring 3 is unit 6 and 7
%
%   LIMITATION: radialUnitsPerModule must be 2 ( due to PET unit numbering)
%               Limitation is hardcoded into the following code segment
%
% Params:   moduleData              Input, modile data
%           axialUnitsPerModule     Input, axial units per module
%           axialModulesPerSystem   Input, axial modules per system
%           radialModulesPerSystem  Input, radial modules per system
%           ringData                Input, ring data
%           outData                 Output,
%--------------------------------------------------------------------------

% Copyright (c) 2006-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:

