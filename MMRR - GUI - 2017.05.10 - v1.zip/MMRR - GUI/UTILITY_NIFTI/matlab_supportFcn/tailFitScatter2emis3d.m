% FILE NAME: tailFitScatter2emis3d.m
%
% DEVELOPER: Ravi Manjeshwar
%
% PURPOSE:  This function scales estimated scatter sinogram to have the
% same number of total counts in the tails of the emission data
%
% INPUTS: 
%       scatter3d:      Estimated scatter sinogram
%		emisTailCounts: Total emission tails counts for each plane of the 
%                       3D emission sinograms
%       sinoTails:      Left and right indices of sinogram tails for each
%                       projection 
%                       Dimensions: (2 acqParams.nV acqParams.nPhi)
%       skipSupport:    Number of first and last radial bins to ignore from
%                       the tails. 
%       total_slices:	Number of slices to perform the tail-fit on.
%                       Typically only 2D tail fit is performed on all but 
%                       the last iteration of MBSC
%
% OUTPUTS: 
%       scatter3d:          Tail-scaled scatter sinogram
%       scatterTailCounts:  Counts in the scatter tails before tail scaling

% Copyright (c) 2005-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%  2005         RMM First written
%  06/23/2008   Added documentation

% FILE NAME: tailFitScatter2emis3d.m
% one more parameter - total_slices

