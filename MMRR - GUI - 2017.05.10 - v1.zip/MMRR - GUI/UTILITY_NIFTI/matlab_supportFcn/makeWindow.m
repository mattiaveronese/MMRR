%  makeWindow
%
%  Make a one-dimensional apodizing window in frequency space, for use in
%  image reconstruction
%
%  Usage:
%    window = makeWindow(nu,su,windowType,windowParam,windowParam2);
%
%   Inputs (all required):
%      nu           scalar   Projection plane width
%      su           scalar   Spacing along projection plane width
%      windowType   string   Apodizing window type
%      windowParam  scalar   Apodizing window parameter
%      windowParam2 scalar   Second apodizing window parameter
%                              
%   Output:
%      window       Resulting window
%
%   Supported window types are "Gaussian", "Rectangle", "Hanning",
%   "Sinc", and "Butterworth".  The parameter is the FWHM of the Gaussian
%   window, the zero point of the Rectangle, Hanning and Sinc windows, and
%   the 3dB point of the Butterworth.  "Param2" is meaningful only for
%   Butterworth, and is the order of the window.

% Copyright (c) 2009-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%    14Oct09  CWS    First commit of code

