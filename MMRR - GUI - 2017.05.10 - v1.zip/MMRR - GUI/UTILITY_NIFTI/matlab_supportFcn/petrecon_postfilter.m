% post-filter a reconstructed PET image
% Usage:
%  reconImg=petrecon_postfilter(reconImg, reconParams);
%
% DEVELOPER: Steve Ross
%
% INPUTS: 
% reconImg: 3d array
% reconParams: structure with parameter settings. This function only uses the following fields:
%   reconParams.postFilterFWHM, reconParams.zfilter,
%   reconParams.FOV, reconParams.nx (for image characteristics)
%   Optional field: 
%      reconParams.zfilterVersion
%      If set to 1, we will use the pre-June-2009 (pettoolbox) version of the zfilter.
%      Current version is 2.
% OUTPUTS:
%  reconImg:
%    filtered image using a 2D Gaussian x-y filter with postFilterFWHM and an axial filter 
%    with a three point convolution of [1, zfilter,1]. Product zfilter parameters are 
%      Heavy: zfilter=2, Standard: zfilter=4, Lite: zfilter=6

% Copyright (c) 2008-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%  Kris Thielemans 16 June 2008
%  Moved code from petrecon2d.m etc into separate function
% Modifications:
%  TD - 15 June 2009: Modified z-filtering to un-bias outside the outside
%  slice on each side of the frame. (Note: This might differ from product
%  implementation.)
%  KT - Aug 2009: add zfilterVersion to be able to reproduce the old version

