% construct dicom RadiopharmaceuticalInformationSequence from an RDF header
% Usage:
%   dicomHdr=petrecon_setDicomRadiopharmaceuticalInformationFromRDF(dicomHdr, rdfHdr);
% Uses information from rdf.sharc_rdf_pet_exam_data to fill in most fields in
% dicomHdr.RadiopharmaceuticalInformationSequence.
% The input dicomHdr is used to get the local timezone (for RDF 7.1 or later)
% WARNING: only checked this on a few patients with F-18. Decay corrections might be incorrect
%
% CALLS: trimCString, dicomDT2DateArray, GEgetTimeDifferenceWithUTCFromRDFAndDicom
%  GEconvertDicomDTToSecsSinceEpoch, GEconvertSecsSinceEpochToDicomDT


% Copyright (c) 2008-2010 General Electric Company. All rights reserved.
% This code is only made available outside the General Electric Company
% pursuant to a signed agreement between the Company and the institution to
% which the code is made available.  This code and all derivative works
% thereof are subject to the non-disclosure terms of that agreement.
%
% History:
%   3Jul2008 Kris Thielemans
%     First version
%   Jan 2010 Kris Thielemans
%     Don't fill in RadionuclideTotalDose when some timing fields are not set in the RDF
%     Take time zone into account for RDF 7.1 or later
%     Pass original dicomHdr as input to be able to infer time zone
%     Added nuclides and tracers


